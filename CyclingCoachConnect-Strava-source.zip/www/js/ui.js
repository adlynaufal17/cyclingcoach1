/* Cycling Coach — UI */
'use strict';

// ============ BASIC UI ============
let toastT;
function toast(msg) { const t = $('#toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), 2800); }
function openSheet(html, onMount) {
  $('#sheetBody').innerHTML = html; $('#sheet').scrollTop = 0;
  $('#backdrop').classList.add('show'); $('#sheet').classList.add('show');
  onMount && onMount($('#sheetBody'));
}
function closeSheet() { $('#backdrop').classList.remove('show'); $('#sheet').classList.remove('show'); }
$('#backdrop').onclick = closeSheet;

const TITLES = { home: 'Beranda', program: 'Program', checkin: 'Kondisi', record: 'Rekam', progress: 'Progres', you: 'Profil' };
let VIEW = 'home';
function go(v) {
  if (VIEW === 'record' && v !== 'record') { destroyMap(); if (!R) gpsStop(); }
  VIEW = v;
  $$('.view').forEach((el) => el.classList.toggle('active', el.id === `view-${v}`));
  $$('.tabbar button').forEach((b) => b.classList.toggle('active', b.dataset.go === v));
  $('#pageTitle').textContent = TITLES[v];
  window.scrollTo(0, 0);
  render();
  updateRecPill();
}
$$('.tabbar button').forEach((b) => (b.onclick = () => go(b.dataset.go)));
$('#settingsTop').onclick = () => openSettings();
$('#syncTop').onclick = () => (S.auth ? syncStrava(false) : (toast('Hubungkan Strava dulu'), openSettings()));

function avatarHtml(size) {
  const p = S.profile, img = p.photo || (S.athlete?.profile && !/avatar\/athlete/.test(S.athlete.profile) ? S.athlete.profile : '');
  const init = (p.name || 'C').trim().split(/\s+/).map((w) => w[0]).slice(0, 2).join('').toUpperCase();
  return `<div class="avatar" ${size ? `style="width:${size}px;height:${size}px"` : ''}>${img ? `<img src="${esc(img)}" alt="">` : esc(init)}</div>`;
}
const statHtml = (lbl, val, unit, cls = '') => `<div class="stat ${cls}"><div class="lbl">${lbl}</div><div class="val">${val}${unit ? `<small>${unit}</small>` : ''}</div></div>`;
const kv = (k, v) => `<div class="kv"><span>${k}</span><b>${v}</b></div>`;

// ============ CHARTS ============
function lineChart({ series, w = 340, h = 170, xLabels = [], yFmt = (v) => fmtNum(v), markX = null, goalY = null }) {
  const all = series.flatMap((s) => s.pts.map((p) => p[1])).concat(goalY != null ? [goalY] : []);
  if (!all.length) return '';
  let lo = Math.min(...all), hi = Math.max(...all); if (hi === lo) { hi += 1; lo -= 1; }
  const padv = (hi - lo) * 0.12; lo -= padv; hi += padv;
  const xs = series.flatMap((s) => s.pts.map((p) => p[0])); const x0 = Math.min(...xs), x1 = Math.max(...xs) || 1;
  const L = 38, R = 10, T = 12, B = 22;
  const X = (x) => L + ((x - x0) / (x1 - x0 || 1)) * (w - L - R), Y = (y) => T + (1 - (y - lo) / (hi - lo)) * (h - T - B);
  let g = '';
  for (let i = 0; i <= 3; i++) { const v = lo + ((hi - lo) * i) / 3; g += `<line x1="${L}" x2="${w - R}" y1="${Y(v)}" y2="${Y(v)}" stroke="var(--line)"/><text x="${L - 6}" y="${Y(v) + 3}" text-anchor="end">${yFmt(v)}</text>`; }
  xLabels.forEach(([x, t]) => (g += `<text x="${X(x)}" y="${h - 6}" text-anchor="middle">${t}</text>`));
  if (goalY != null) g += `<line x1="${L}" x2="${w - R}" y1="${Y(goalY)}" y2="${Y(goalY)}" stroke="var(--red)" stroke-dasharray="4 4"/><text x="${w - R}" y="${Y(goalY) - 4}" text-anchor="end" style="fill:var(--red)">GOAL</text>`;
  if (markX != null) g += `<line x1="${X(markX)}" x2="${X(markX)}" y1="${T}" y2="${h - B}" stroke="var(--yellowD)" stroke-width="1.5"/>`;
  series.forEach((s) => {
    const d = s.pts.map((p, i) => `${i ? 'L' : 'M'}${X(p[0]).toFixed(1)},${Y(p[1]).toFixed(1)}`).join('');
    if (s.area) g += `<path d="${d}L${X(s.pts[s.pts.length - 1][0])},${h - B}L${X(s.pts[0][0])},${h - B}Z" fill="${s.color}" opacity=".12"/>`;
    g += `<path d="${d}" fill="none" stroke="${s.color}" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" ${s.dash ? 'stroke-dasharray="5 5"' : ''}/>`;
    if (s.dots) s.pts.forEach((p) => (g += `<circle cx="${X(p[0])}" cy="${Y(p[1])}" r="3.5" fill="${s.color}"/>`));
  });
  return `<svg class="chart" viewBox="0 0 ${w} ${h}">${g}</svg>`;
}
function barChart(vals, labels, { w = 340, h = 150, color = 'var(--teal)', hiLast = true, fmt = (v) => fmtNum(v) } = {}) {
  const max = Math.max(...vals, 1), n = vals.length, L = 6, B = 22, T = 16, bw = (w - L * 2) / n;
  let g = '';
  vals.forEach((v, i) => {
    const bh = (v / max) * (h - B - T), x = L + i * bw + bw * 0.18, y = h - B - bh;
    const c = hiLast && i === n - 1 ? 'var(--yellowD)' : color;
    g += `<rect x="${x}" y="${y}" width="${bw * 0.64}" height="${Math.max(bh, v ? 2 : 0)}" rx="3" fill="${c}"/>`;
    if (labels[i]) g += `<text x="${x + bw * 0.32}" y="${h - 6}" text-anchor="middle">${labels[i]}</text>`;
    if (v && (i === n - 1 || v === max)) g += `<text x="${x + bw * 0.32}" y="${y - 4}" text-anchor="middle" style="fill:var(--navy);font-weight:600">${fmt(v)}</text>`;
  });
  return `<svg class="chart" viewBox="0 0 ${w} ${h}">${g}</svg>`;
}
function gaugeSvg(score, color) {
  const r = 62, c = 2 * Math.PI * r, off = c * (1 - score / 100);
  return `<svg viewBox="0 0 150 150" width="150" height="150"><circle cx="75" cy="75" r="${r}" fill="none" stroke="var(--cream)" stroke-width="12"/><circle cx="75" cy="75" r="${r}" fill="none" stroke="${color}" stroke-width="12" stroke-linecap="round" stroke-dasharray="${c}" stroke-dashoffset="${off}" transform="rotate(-90 75 75)"/></svg>`;
}

// ============ ONBOARDING ============
const GOAL_PRESETS = [
  { id: 'fondo', t: 'Gran Fondo', s: '160 km · 28 km/j · 2.000 m', dist: 160, speed: 28, elev: 2000 },
  { id: 'century', t: 'Century 200', s: '200 km · 27 km/j · 2.500 m', dist: 200, speed: 27, elev: 2500 },
  { id: 'ultra', t: 'Ultra (Bentang Jawa)', s: '1.500 km · 16.000 m total', dist: 400, speed: 24, elev: 4000, title: 'Finish Bentang Jawa' },
  { id: 'speed', t: 'Speedster', s: '100 km · 32 km/j · 1.000 m', dist: 100, speed: 32, elev: 1000 },
];
let ob = { step: 0, d: null };
function startOnboarding() {
  ob = { step: 0, d: {
    name: S.profile.name, age: S.profile.age, sex: S.profile.sex, weight: S.profile.weight, height: S.profile.height,
    dist: S.baseline?.dist || 30, speed: S.baseline?.speed || 22, elev: S.baseline?.elev || 200,
    gTitle: S.goal?.title || '', gYear: S.goal ? +S.goal.date.slice(0, 4) : new Date().getFullYear() + 4, gMonth: S.goal ? +S.goal.date.slice(5, 7) : 8,
    gDist: S.goal?.dist || 160, gSpeed: S.goal?.speed || 28, gElev: S.goal?.elev || 2000, gWeight: S.goal?.weight || '', preset: '',
    restDays: S.settings.restDays, longDay: S.settings.longDay, trainTime: S.settings.trainTime,
  } };
  $('#app').classList.add('hidden'); $('#onboarding').classList.remove('hidden');
  renderOb();
}
function renderOb() {
  const d = ob.d, st = ob.step, N = 5;
  const dots = `<div class="dots">${Array.from({ length: N }, (_, i) => `<i class="${i <= st ? 'on' : ''}"></i>`).join('')}</div>`;
  const num = (id, label, val, unit, step = 1) => `<label class="f">${label}${label.length < 12 ? ` (${unit})` : ''}<div class="unit"><input id="${id}" type="number" inputmode="decimal" step="${step}" value="${val}"><em>${unit}</em></div></label>`;
  let body = '';
  if (st === 0) body = `<div class="mono">Cycling Coach · Program latihan adaptif</div>
    <h1>Gowes lebih jauh, lebih cepat, lebih tinggi.</h1>
    <p>Set goal jangka panjang lo, jawab 3 pertanyaan kemampuan, dan dapatkan program harian yang menyesuaikan kondisi tubuh & progres lo tiap bulan.</p>
    <div class="ob-card"><div class="win"><div class="b">🎯</div><div><b>Goal multi-tahun</b><div class="small muted">Roadmap bulanan sampai tahun target</div></div></div>
    <div class="win"><div class="b">❤️</div><div><b>Check-in harian</b><div class="small muted">Porsi latihan berubah sesuai kondisi tubuh</div></div></div>
    <div class="win"><div class="b">🔗</div><div><b>Terhubung Strava</b><div class="small muted">Aktivitas Strava otomatis jadi data & statistik</div></div></div></div>`;
  if (st === 1) body = `<div class="mono">Langkah 1 · Profil tubuh</div><h1>Kenalan dulu.</h1><p>Dipakai untuk hitung kalori, lemak terbakar & zona detak jantung.</p>
    <div class="ob-card"><label class="f">Nama<input id="o_name" value="${esc(d.name)}" placeholder="Nama lo"></label>
    <div class="grid2">${num('o_age', 'Umur', d.age, 'th')}<label class="f">Jenis kelamin<select id="o_sex"><option value="M" ${d.sex === 'M' ? 'selected' : ''}>Laki-laki</option><option value="F" ${d.sex === 'F' ? 'selected' : ''}>Perempuan</option></select></label></div>
    <div class="grid2">${num('o_weight', 'Berat badan', d.weight, 'kg', 0.1)}${num('o_height', 'Tinggi badan', d.height, 'cm')}</div></div>`;
  if (st === 2) body = `<div class="mono">Langkah 2 · Kemampuan saat ini</div><h1>Seberapa kuat lo sekarang?</h1><p>Jadi patokan program 1 bulan pertama. Jujur aja — nanti dievaluasi tiap bulan.</p>
    <div class="ob-card">${num('o_dist', 'Rata-rata jarak sekali gowes', d.dist, 'km')}
    ${num('o_speed', 'Avg speed yang paling sering dicapai', d.speed, 'km/j', 0.5)}
    ${num('o_elev', 'Elevasi yang sudah dikuasai (sekali ride)', d.elev, 'm', 10)}
    ${S.auth && recordedBaselineSuggestion() ? `<button class="btn small ghost" id="o_fromRec" style="margin-top:12px">Isi dari Strava (28 hari terakhir)</button>` : ''}</div>`;
  if (st === 3) body = `<div class="mono">Langkah 3 · Goal</div><h1>Mau sampai mana?</h1><p>Pilih template atau atur sendiri. Program dibuat sampai bulan target.</p>
    <div class="ob-card"><div class="preset">${GOAL_PRESETS.map((p) => `<button data-p="${p.id}" class="${d.preset === p.id ? 'on' : ''}"><b>${p.t}</b>${p.s}</button>`).join('')}</div>
    <label class="f">Nama goal<input id="o_gTitle" value="${esc(d.gTitle)}" placeholder="Contoh: Finish Gran Fondo 2030"></label>
    <div class="grid2"><label class="f">Bulan<select id="o_gMonth">${MONL.map((m, i) => `<option value="${i + 1}" ${d.gMonth === i + 1 ? 'selected' : ''}>${m}</option>`).join('')}</select></label>
    <label class="f">Tahun<select id="o_gYear">${Array.from({ length: 10 }, (_, i) => new Date().getFullYear() + i).map((y) => `<option ${d.gYear === y ? 'selected' : ''}>${y}</option>`).join('')}</select></label></div>
    <div class="grid3">${num('o_gDist', 'Jarak', d.gDist, 'km')}${num('o_gSpeed', 'Avg speed', d.gSpeed, 'km/j', 0.5)}${num('o_gElev', 'Elevasi', d.gElev, 'm', 50)}</div>
    ${num('o_gWeight', 'Target berat badan (opsional)', d.gWeight, 'kg', 0.5)}</div>`;
  if (st === 4) body = `<div class="mono">Langkah 4 · Jadwal</div><h1>Atur minggu lo.</h1><p>Program 7 hari berbeda: interval, endurance, tanjakan, tempo, long ride + rest day.</p>
    <div class="ob-card"><label class="f">Jumlah rest day per minggu<select id="o_rest"><option value="1" ${d.restDays == 1 ? 'selected' : ''}>1 hari (Senin) + 1 recovery spin</option><option value="2" ${d.restDays == 2 ? 'selected' : ''}>2 hari (Senin & Jumat)</option></select></label>
    <label class="f">Hari long ride<select id="o_long"><option value="6" ${d.longDay == 6 ? 'selected' : ''}>Sabtu</option><option value="0" ${d.longDay == 0 ? 'selected' : ''}>Minggu</option></select></label>
    <label class="f">Jam latihan biasanya<input id="o_time" type="time" value="${d.trainTime}"></label></div>`;
  $('#onboarding').innerHTML = `${dots}<div>${body}</div><div class="ob-foot">
    ${st > 0 ? '<button class="btn on-dark" id="obBack">Kembali</button>' : '<button class="btn on-dark" id="obDemo">Coba demo</button>'}
    <button class="btn primary" id="obNext">${st === N - 1 ? 'Buat program 🚴' : st === 0 ? 'Mulai' : 'Lanjut'}</button></div>`;
  const back = $('#obBack'); if (back) back.onclick = () => { collectOb(); ob.step--; renderOb(); };
  const demo = $('#obDemo'); if (demo) demo.onclick = startDemo;
  $('#obNext').onclick = () => { if (!collectOb(true)) return; if (ob.step === N - 1) finishOnboarding(); else { ob.step++; renderOb(); } };
  $$('.preset button').forEach((b) => (b.onclick = () => {
    const p = GOAL_PRESETS.find((x) => x.id === b.dataset.p); collectOb();
    Object.assign(ob.d, { preset: p.id, gDist: p.dist, gSpeed: p.speed, gElev: p.elev, gTitle: p.title || `${p.t} ${ob.d.gYear}` }); renderOb();
  }));
  const fs = $('#o_fromRec'); if (fs) fs.onclick = () => { const s = recordedBaselineSuggestion(); Object.assign(ob.d, { dist: s.dist, speed: s.speed, elev: s.elev }); renderOb(); };
  window.scrollTo(0, 0);
}
function collectOb(validate) {
  const d = ob.d, v = (id) => { const el = $('#' + id); return el ? el.value : undefined; }, n = (id) => parseFloat(v(id));
  if (ob.step === 1) {
    Object.assign(d, { name: v('o_name').trim(), age: n('o_age'), sex: v('o_sex'), weight: n('o_weight'), height: n('o_height') });
    if (validate && (!(d.age > 10 && d.age < 90) || !(d.weight > 30) || !(d.height > 120))) { toast('Cek lagi umur, berat & tinggi'); return false; }
  }
  if (ob.step === 2) {
    Object.assign(d, { dist: n('o_dist'), speed: n('o_speed'), elev: n('o_elev') });
    if (validate && (!(d.dist > 0) || !(d.speed > 5) || !(d.elev >= 0))) { toast('Isi jarak, speed & elevasi'); return false; }
  }
  if (ob.step === 3) {
    Object.assign(d, { gTitle: v('o_gTitle').trim(), gMonth: +v('o_gMonth'), gYear: +v('o_gYear'), gDist: n('o_gDist'), gSpeed: n('o_gSpeed'), gElev: n('o_gElev'), gWeight: n('o_gWeight') || '' });
    const gd = `${d.gYear}-${pad(d.gMonth)}`;
    if (validate && gd <= today().slice(0, 7)) { toast('Tanggal goal harus di masa depan'); return false; }
    if (validate && (!(d.gDist > 0) || !(d.gSpeed > 5))) { toast('Isi target goal'); return false; }
  }
  if (ob.step === 4) Object.assign(d, { restDays: +v('o_rest'), longDay: +v('o_long'), trainTime: v('o_time') || '06:00' });
  return true;
}
function finishOnboarding() {
  const d = ob.d;
  const reset = !S.onboarded || !S.cycles.length;
  Object.assign(S.profile, { name: d.name, age: d.age, sex: d.sex, weight: d.weight, height: d.height });
  if (!S.weights.length || S.weights[S.weights.length - 1].kg !== d.weight) logWeight(d.weight);
  S.baseline = { dist: d.dist, speed: d.speed, elev: d.elev, d: today() };
  S.goal = { title: d.gTitle || `Goal ${d.gYear}`, date: `${d.gYear}-${pad(d.gMonth)}`, dist: d.gDist, speed: d.gSpeed, elev: d.gElev, weight: d.gWeight || null };
  Object.assign(S.settings, { restDays: d.restDays, longDay: d.longDay, trainTime: d.trainTime });
  if (reset) S.cycles = []; else S.cycles = S.cycles.filter((c) => c.start < today());
  newCycle(S.baseline, 1);
  S.onboarded = true; save();
  $('#onboarding').classList.add('hidden'); $('#app').classList.remove('hidden');
  go('home'); scheduleNotifications();
  toast('Program latihan lo sudah siap! 🚴'); setTimeout(() => maybeTour(), 700);
}
function logWeight(kg) {
  const d = today();
  S.weights = S.weights.filter((w) => w.d !== d); S.weights.push({ d, kg: +kg }); S.weights.sort((a, b) => a.d.localeCompare(b.d));
  S.profile.weight = +kg;
}

// ============ DEMO ============
function startDemo() {
  const rnd = (a, b) => a + Math.random() * (b - a);
  S.demo = true;
  Object.assign(S.profile, { name: 'Pesepeda Demo', age: 28, sex: 'M', weight: 74, height: 172 });
  S.weights = [];
  for (let i = 90; i >= 0; i -= 7) S.weights.push({ d: ymd(addDays(new Date(), -i)), kg: +(76.5 - (90 - i) * 0.028 + rnd(-0.3, 0.3)).toFixed(1) });
  S.profile.weight = S.weights[S.weights.length - 1].kg;
  S.baseline = { dist: 45, speed: 24, elev: 400, d: ymd(addDays(new Date(), -30)) };
  S.goal = { title: 'Finish Bentang Jawa 2030', date: '2030-08', dist: 400, speed: 25, elev: 4000, weight: 68 };
  const acts = []; let id = 1;
  for (let i = 180; i >= 1; i--) {
    const d = addDays(new Date(), -i), wd = d.getDay();
    if (wd === 1 || Math.random() < 0.25) continue;
    const prog = 1 + (180 - i) / 400;
    const long = wd === 6 || wd === 0;
    const km = (long ? rnd(70, 110) : rnd(25, 50)) * prog, spd = rnd(22.5, 26.5) * (1 + (180 - i) / 1800), el = km * rnd(5, 14);
    acts.push({ id: id++, name: long ? ['Long ride Puncak', 'Gowes Sentul', 'Loop Bogor', 'Jakarta–Karawang'][id % 4] : ['Morning Ride', 'Interval Senayan', 'Tanjakan Gunung Pancar', 'Easy spin'][id % 4],
      sport_type: 'Ride', start_date_local: `${ymd(d)}T0${long ? 5 : 6}:${pad(Math.floor(rnd(0, 59)))}:00Z`, distance: km * 1000, moving_time: (km / spd) * 3600, elapsed_time: (km / spd) * 3900,
      elev: el, avg_speed: spd / 3.6, max_speed: spd * 1.9 / 3.6, avg_hr: rnd(135, 158), kilojoules: 0, poly: '', city: 'Bogor' });
  }
  S.activities = acts.reverse();
  Object.assign(S.settings, { restDays: 1, longDay: 6 });
  S.cycles = [];
  const c = newCycle(S.baseline, 1); c.start = ymd(addDays(new Date(), -9));
  S.checkins = {}; S.onboarded = true; save();
  $('#onboarding').classList.add('hidden'); $('#app').classList.remove('hidden');
  go('home'); toast('Mode demo — data contoh. Reset di Setelan.'); setTimeout(() => maybeTour(), 700);
}

// ============ HOME ============
function sessionTargetsHtml(p, cls = '') {
  if (p.type === 'REST') return '';
  return `<div class="stats ${cls}">${statHtml('Target jarak', fmtNum(p.dist, 1), 'km')}${statHtml('Avg speed', fmtNum(p.speed, 1), 'km/j')}${statHtml('Elevasi', fmtNum(p.elev), 'm')}</div>`;
}
function actStatsHtml(a, b) {
  const sp = sportOf(a), km = a.distance / 1000, mv = a.moving_time || a.elapsed_time;
  if (!sp.gps && !km) return `<div class="stats">${statHtml('Waktu', fmtDurSec(mv))}${statHtml('Kalori', fmtNum(b.kcal), 'kcal', 'hi')}${statHtml('Lemak', fmtNum(b.fatG), 'g', 'hi')}</div>`;
  if (sp.pace) return `<div class="stats">${statHtml('Jarak', fmtNum(km, 2), 'km')}${statHtml('Pace', fmtPace(km ? mv / km : 0), '/km')}${statHtml('Waktu', fmtDurSec(mv))}</div>
    <div class="stats">${statHtml('Elev. Gain', fmtNum(a.elev), 'm')}${statHtml('Kalori', fmtNum(b.kcal), 'kcal', 'hi')}${statHtml('Lemak', fmtNum(b.fatG), 'g', 'hi')}</div>`;
  return `<div class="stats">${statHtml('Jarak', fmtNum(km, 2), 'km')}${statHtml('Elev. Gain', fmtNum(a.elev), 'm')}${statHtml('Waktu', fmtDurSec(mv))}</div>
    <div class="stats">${statHtml('Avg speed', fmtNum(a.avg_speed * 3.6, 1), 'km/j')}${statHtml('Kalori', fmtNum(b.kcal), 'kcal', 'hi')}${statHtml('Lemak', fmtNum(b.fatG), 'g', 'hi')}</div>`;
}
const srcChip = (a) => (a.source === 'strava' ? '<span class="chip strava-chip">Strava</span>' : a.manual ? '<span class="chip">✎ Manual</span>' : S.demo ? '<span class="chip">Demo</span>' : '');
function feedCard(a) {
  const b = burnOfActivity(a), d = actDate(a), t = (a.start_date_local || '').slice(11, 16), sp = sportOf(a);
  const p = adjustedFor(d), cm = completionFor(d);
  const match = isRide(a) && p && p.type !== 'REST' && cm && cm.acts?.[0]?.id === a.id ? `<span class="chip ok">✓ ${esc(p.short)} · ${cm.score}% target</span>` : '';
  return `<div class="card" data-act="${a.id}">
    <div class="feed-head">${avatarHtml()}<div><div class="feed-name">${esc(S.profile.name || 'Anda')}</div><div class="feed-meta">${sp.ico} ${fmtDate(d)} pukul ${t}${a.city ? ' · ' + esc(a.city) : ''}</div></div></div>
    <div class="feed-title">${esc(a.name)}</div>
    ${actStatsHtml(a, b)}
    ${polylineSvg(a.poly)}
    <div class="chips">${match}${srcChip(a)}</div></div>`;
}

let homeSel = null;
function renderHome() {
  const el = $('#view-home'), t = today();
  if (!homeSel) homeSel = t;
  const r = readiness(S.checkins[t]);
  const p = adjustedFor(homeSel), isToday = homeSel === t;
  const c = currentCycle();
  let h = '';

  if (cycleDue()) h += `<div class="card" style="background:var(--yellow);border:0;color:#111318"><div class="mono">Evaluasi bulanan</div>
    <h2 style="margin-top:4px">Sudah 1 bulan latihan! 🎉</h2><div class="small">Ceritain peningkatan lo supaya program bulan depan disesuaikan.</div>
    <button class="btn teal block" id="evalBtn" style="margin-top:10px">Mulai evaluasi</button></div>`;

  if (!r) h += `<div class="card"><div class="card-head"><div><div class="mono muted">Check-in harian</div><h2>Gimana kondisi tubuh lo hari ini?</h2></div><div style="font-size:30px">❤️</div></div>
    <div class="small muted">Jawab 5 pertanyaan singkat — porsi latihan hari ini langsung disesuaikan.</div>
    <button class="btn primary block" style="margin-top:10px" data-go2="checkin">Check-in sekarang</button></div>`;

  // week strip
  const mon = addDays(parseYmd(t), -((parseYmd(t).getDay() + 6) % 7));
  let strip = '';
  for (let i = 0; i < 7; i++) {
    const d = ymd(addDays(mon, i)), pp = planFor(d), cm = completionFor(d);
    const dot = cm && (cm.acts?.length || cm.manual) && !cm.rest ? 'ok' : pp && pp.type !== 'REST' && d < t ? 'miss' : '';
    strip += `<button class="wd ${d === t ? 'today' : ''} ${d === homeSel ? 'sel' : ''}" data-d="${d}">${DAY3[parseYmd(d).getDay()]}<b>${parseYmd(d).getDate()}</b><div class="ico">${pp ? pp.ico : ''}</div><div class="dot ${dot}"></div></button>`;
  }
  h += `<div class="card" style="padding:10px 8px"><div class="week">${strip}</div></div>`;

  if (p) {
    const cm = completionFor(homeSel);
    h += `<div class="card hero"><div class="mono">${isToday ? 'Latihan hari ini' : fmtDateShort(homeSel)} · Minggu ${p.week} ${p.weekName}</div>
      <div class="ttl">${p.ico} ${esc(p.name)}</div>
      <div style="color:#CFE3DB;font-size:14px">${p.type === 'REST' ? 'Istirahat & pemulihan' : `${fmtDur(p.dur)} · ${p.zone} · RPE ${p.rpe}`}</div>
      ${sessionTargetsHtml(p)}
      ${p.adjust ? `<div class="adjust">⚙️ ${esc(p.adjust)}</div>` : ''}
      ${p.type !== 'REST' ? `<div class="hero-fuel">${fuelShort(fuelPlan(p))}</div>` : ''}
      ${cm && cm.acts?.length ? `<div class="adjust" style="border-color:var(--sage);background:rgba(156,195,182,.2)">✓ Selesai: ${fmtNum(cm.km, 1)} km · ${fmtNum(cm.spd, 1)} km/j · ${fmtNum(cm.elev)} m — ${cm.score}% dari target</div>` : cm?.manual ? `<div class="adjust">✓ Ditandai selesai manual</div>` : ''}
      <div class="btn-row"><button class="btn primary" id="detailBtn">Lihat detail</button>${p.type !== 'REST' && !(cm && (cm.acts?.length || cm.manual)) && homeSel <= t ? '<button class="btn on-dark" id="doneBtn">✓ Selesai</button>' : ''}</div></div>`;
  }

  h += homeExtrasHtml();
  h += weatherCardHtml(homeSel);
  if (r) h += `<div class="card"><div class="card-head"><div><div class="mono muted">Readiness hari ini</div><h2 style="color:${r.color}">${r.score}/100 · ${r.label}</h2></div><button class="link" data-go2="checkin">Ubah</button></div>
    <div class="progress"><div style="width:${r.score}%;background:${r.color}"></div></div></div>`;

  // goal mini
  if (S.goal && c) {
    const rm = buildRoadmap(capFromBaseline(c.base), c.start, c.mult);
    h += `<div class="card"><div class="card-head"><div><div class="mono muted">Goal · ${monthsToGoal()} bulan lagi</div><h2>${esc(S.goal.title)}</h2></div><button class="link" data-go2="program">Roadmap</button></div>
      <div class="stats">${statHtml('Long ride', `${fmtNum(c.cap.long)}→${fmtNum(goalCap().long)}`, 'km')}${statHtml('Speed', `${fmtNum(c.cap.speed, 1)}→${fmtNum(S.goal.speed)}`, '')}${statHtml('Elevasi', `${fmtNum(c.cap.elev)}→${fmtNum(S.goal.elev)}`, '')}</div>
      <div class="small muted" style="margin-top:8px">Proyeksi pencapaian goal: <b style="color:var(--teal)">${rm.reachPct}%</b> ${rm.reachPct < 100 ? '— goal cukup agresif, konsistensi kunci!' : '— on track 🎯'}</div></div>`;
  }

  // feed
  h += `<div class="section-title">Aktivitas terbaru <span><button class="link" id="manualHome" style="margin-right:14px">+ Manual</button><button class="link" data-go2="you">Lihat semua</button></span></div>`;
  if (!S.auth && !S.demo) h += `<div class="card"><h2>Hubungkan Strava</h2><div class="small muted">Aktivitas dari Strava otomatis masuk, dicocokkan dengan program, dan dihitung kalorinya.</div><button class="btn primary block" style="margin-top:12px" id="connectHome">Connect with Strava</button></div>`;
  else if (!S.activities.length) h += `<div class="empty">Belum ada aktivitas. Gowes dulu yuk! 🚴</div>`;
  const acts = S.activities.slice(0, 8);
  h += acts.map(feedCard).join('');
  el.innerHTML = h;

  $$('.wd', el).forEach((b) => (b.onclick = () => { homeSel = b.dataset.d; renderHome(); }));
  const db = $('#detailBtn', el); if (db) db.onclick = () => openSessionSheet(homeSel);
  const dn = $('#doneBtn', el); if (dn) dn.onclick = () => { S.manualDone[homeSel] = true; save(); toast('Mantap! Sesi ditandai selesai 💪'); render(); };
  const eb = $('#evalBtn', el); if (eb) eb.onclick = openMonthlyEval;
  const ch = $('#connectHome', el); if (ch) ch.onclick = stravaConnect;
  const mn = $('#manualHome', el); if (mn) mn.onclick = openManualSheet;
  $$('[data-go2]', el).forEach((b) => (b.onclick = () => go(b.dataset.go2)));
  $$('[data-act]', el).forEach((b) => (b.onclick = () => openActivitySheet(b.dataset.act)));
  bindWeatherCard(el);
  ensureWeather().then((ch) => { if (ch && VIEW === 'home') renderHome(); });
}

// ============ SESSION DETAIL ============
function openSessionSheet(d) {
  const p = adjustedFor(d); if (!p) return;
  const cm = completionFor(d);
  const burn = p.type !== 'REST' ? calcBurn({ distKm: p.dist, speed: p.speed, elev: p.elev }) : null;
  let h = `<div class="sheet-pad"><div class="mono muted">${fmtDateShort(d)} · Minggu ${p.week} (${p.weekName})</div>
    <h2 class="st">${p.ico} ${esc(p.name)}</h2>
    ${p.adjust ? `<div class="note y">⚙️ ${esc(p.adjust)}</div>` : ''}</div>`;
  if (p.type !== 'REST') {
    h += `<div class="card" style="margin-top:12px">${sessionTargetsHtml(p)}<div class="stats">${statHtml('Durasi', fmtDur(p.dur))}${statHtml('Zona', esc(p.zone.split(' ')[0]))}${statHtml('RPE', esc(p.rpe))}</div></div>
      <div class="card"><h2>Intensitas</h2>${kv('Zona', esc(p.zone))}${kv('Detak jantung', esc(p.hr))}${p.intervalSpeed ? kv('Speed interval', `${fmtNum(p.intervalSpeed, 1)} km/j`) : ''}${kv('Target avg speed', `${fmtNum(p.speed, 1)} km/j`)}${kv('Target elevasi', `${fmtNum(p.elev)} m`)}</div>
      <div class="card"><h2>Estimasi pembakaran</h2><div class="stats">${statHtml('Kalori', fmtNum(burn.kcal), 'kcal', 'hi')}${statHtml('Lemak', fmtNum(burn.fatG), 'g', 'hi')}${statHtml('Setara BB', fmtNum(burn.weightLossG), 'g')}</div><div class="small muted" style="margin-top:8px">Berdasar berat ${fmtNum(S.profile.weight, 1)} kg. Penurunan BB terjadi jika total asupan harian lebih kecil dari pengeluaran.</div></div>`;
  }
  h += `<div class="card"><h2>Tujuan</h2><div class="small">${esc(p.purpose)}</div></div>
    <div class="card"><h2>Struktur sesi</h2><ol class="steps">${p.steps.map((s) => `<li>${esc(s)}</li>`).join('')}</ol></div>
    ${strengthCardHtml(p)}${fuelCardHtml(p)}${p.type !== 'REST' && wxHasDay(d) ? weatherCardHtml(d).replace('id="wxSet"', 'id="wxSet2"') : ''}
    ${p.type !== 'REST' && d >= today() ? `<div class="pad"><a class="btn ghost block center" style="text-decoration:none" target="_blank" rel="noopener" href="${gcalLink(p)}">📅 Tambah ke Google Calendar</a></div>` : ''}`;
  if (cm && cm.acts?.length) {
    h += `<div class="card"><h2>Hasil vs target</h2>
      ${[['Jarak', cm.km, p.dist, 'km', 1, cm.pDist], ['Avg speed', cm.spd, p.speed, 'km/j', 1, cm.pSpd], ['Elevasi', cm.elev, p.elev, 'm', 0, cm.pElev]].map(([l, a, tg, u, dc, pc]) =>
        `<div style="margin:10px 0"><div class="kv" style="border:0;padding:0 0 4px"><span>${l}</span><b>${fmtNum(a, dc)} / ${fmtNum(tg, dc)} ${u}</b></div><div class="progress"><div style="width:${Math.min(pc, 1) * 100}%"></div></div></div>`).join('')}
      <div class="chip ok">Skor ${cm.score}%</div></div>`;
  }
  openSheet(h);
}

// ============ PROGRAM ============
let progWeek = null, roadKey = 'long';
function renderProgram() {
  const el = $('#view-program'), c = currentCycle();
  if (!c) { el.innerHTML = '<div class="empty">Belum ada program.</div>'; return; }
  const t = today(), dayIdx = clamp(daysBetween(c.start, t), 0, 27);
  if (progWeek == null) progWeek = Math.floor(dayIdx / 7);
  const gy = S.goal ? +S.goal.date.slice(0, 4) : new Date().getFullYear() + 1;
  const y0 = parseYmd(S.cycles[0].start).getFullYear(), ym = Math.round((y0 + gy) / 2);
  const t0 = parseYmd(S.cycles[0].start).getTime(), t1 = parseYmd(goalDate() || today()).getTime();
  const prog = clamp((Date.now() - t0) / Math.max(1, t1 - t0), 0, 1);
  const seg = (i) => `${clamp(prog * 3 - i, 0, 1) * 100}%`;
  const ph = phaseLabel();
  let h = `<div class="card rm-card"><div class="card-head" style="align-items:flex-start"><div><div class="mono rm-eyebrow">Roadmap jangka panjang</div><h2 class="rm-title">Program Latihan Menuju ${gy}</h2></div>
      <button class="btn ghost small rm-edit" id="editBase">✎ Edit Baseline</button></div>
    <div class="small muted">Program otomatis dikalkulasi dari kondisi terkini, kenaikan beban mingguan, serta fase spesifik menuju ${esc(S.goal?.title || 'goal')}. Fase sekarang: <b>${ph.name}</b>.</div>
    <div class="phase-labels"><span>Fase Awal<br>(${y0})</span><span>Fase Intermediet<br>(${ym})</span><span class="goal">Goal Peak<br>(${gy})</span></div>
    <div class="phase-bar"><i><b style="width:${seg(0)};background:var(--teal)"></b></i><i><b style="width:${seg(1)};background:#D69E2E"></b></i><i><b style="width:${seg(2)};background:#22C55E"></b></i></div>
    <div class="sbox-row" style="margin-top:14px"><div class="sbox"><div class="l">Long ride</div><div class="v">${fmtNum(c.cap.long)} km</div></div><div class="sbox spd"><div class="l">Avg speed</div><div class="v">${fmtNum(c.cap.speed, 1)} km/j</div></div><div class="sbox elv"><div class="l">Elevasi</div><div class="v">${fmtNum(c.cap.elev)} m</div></div></div>
    <div class="small muted" style="margin-top:6px">Kapasitas target bulan ini · ${fmtDate(c.start)} – ${fmtDate(cycleEnd(c))}</div></div>`;
  h += programExtrasHtml();
  const curWeek = Math.floor(dayIdx / 7);
  h += `<div class="week-head"><div><h2>${progWeek === curWeek ? 'Jadwal Minggu Ini' : `Jadwal Minggu ke-${progWeek + 1}`} (Bulan Ke-${S.cycles.length})</h2><div class="small muted">Program berubah menyesuaikan check-in kondisi tubuh & kemajuan bulanan.</div></div>
    <button class="eval-btn" id="evalProg">Evaluasi<br>Akhir Bulan</button></div>
    <div class="pad" style="margin:2px 0 12px"><div class="seg">${WEEK_NAME.map((n, i) => `<button data-w="${i}" class="${progWeek === i ? 'on' : ''}">M${i + 1} · ${n}</button>`).join('')}</div></div>`;
  let tot = { dist: 0, elev: 0, dur: 0 };
  for (let i = 0; i < 7; i++) {
    const d = ymd(addDays(parseYmd(c.start), progWeek * 7 + i));
    const p = d === t ? adjustedFor(d) : planFor(d), cm = completionFor(d);
    tot.dist += p.dist; tot.elev += p.elev; tot.dur += p.dur;
    const st = cm && (cm.acts?.length || cm.manual) && !cm.rest ? '<span class="chip ok">✓ Selesai</span>' : p.type !== 'REST' && d < t ? '<span class="chip bad">Terlewat</span>' : d === t ? '<span class="chip y">Hari ini</span>' : '';
    const dd = parseYmd(d);
    h += `<div class="day-card ${d === t ? 'today' : ''} ${p.type === 'REST' ? 'rest' : ''}" data-d="${d}">
      <div class="dc-head"><div><span class="dc-day">${DAY[dd.getDay()]}</span> <span class="small muted">${dd.getDate()} ${MON[dd.getMonth()]}</span> ${st}</div><span class="sbadge" style="color:${p.color}">${esc(p.name)}</span></div>
      <div class="dc-desc">${esc(p.desc || '')}${p.adjust && d === t ? `<div style="color:var(--orange);margin-top:4px">⚙️ ${esc(p.adjust)}</div>` : ''}</div>
      ${p.type === 'REST' ? '<div class="rest-note">Rest Day (Istirahat Tubuh)</div>' : `<div class="sbox-row"><div class="sbox"><div class="l">Jarak</div><div class="v">${fmtNum(p.dist)} km</div></div><div class="sbox spd"><div class="l">Avg Speed</div><div class="v">${fmtNum(p.speed, 1)} km/j</div></div><div class="sbox elv"><div class="l">Elevasi</div><div class="v">${fmtNum(p.elev)} m</div></div></div>`}
    </div>`;
  }
  h += `<div class="small muted center" style="padding:2px 16px 14px">Total minggu ${progWeek + 1}: <b>${fmtNum(tot.dist)} km · ${fmtNum(tot.elev)} m · ${fmtDur(tot.dur)}</b></div>`;

  // roadmap
  if (S.goal) {
    const rm = buildRoadmap(capFromBaseline(S.cycles[0].base), S.cycles[0].start, 1);
    const cur = buildRoadmap(capFromBaseline(c.base), c.start, c.mult);
    const g = goalCap();
    const x0 = parseYmd(S.cycles[0].start).getTime();
    const toX = (d) => (parseYmd(d).getTime() - x0) / (86400000 * 30.4);
    const planned = rm.points.map((p) => [toX(p.d), p[roadKey]]);
    const replanned = cur.points.map((p) => [toX(p.d), p[roadKey]]);
    const actual = S.cycles.map((cy) => [toX(cy.start), capFromBaseline(cy.base)[roadKey]]);
    const years = []; const gy = +S.goal.date.slice(0, 4);
    for (let y = parseYmd(S.cycles[0].start).getFullYear() + 1; y <= gy; y++) years.push([toX(`${y}-01-01`), String(y)]);
    const unit = { long: 'km', speed: 'km/j', elev: 'm' }[roadKey];
    h += `<div class="card"><div class="card-head"><div><div class="mono muted">Grafik roadmap · ${esc(S.goal.date.slice(0, 4))}</div><h2>${esc(S.goal.title)}</h2></div></div>
      <div class="seg" style="margin-bottom:10px">${[['long', 'Long ride'], ['speed', 'Avg speed'], ['elev', 'Elevasi']].map(([k, l]) => `<button data-rk="${k}" class="${roadKey === k ? 'on' : ''}">${l}</button>`).join('')}</div>
      ${lineChart({ series: [{ pts: planned, color: 'var(--lav)', dash: true }, { pts: replanned, color: 'var(--teal)', area: true }, { pts: actual, color: 'var(--red)', dots: true }], xLabels: years, goalY: g[roadKey], markX: toX(t), yFmt: (v) => fmtNum(v, roadKey === 'speed' ? 1 : 0) })}
      <div class="chips"><span class="chip"><span style="color:var(--lav)">- -</span> Rencana awal</span><span class="chip ok">━ Rencana terbaru</span><span class="chip bad">● Kemampuan aktual</span></div>
      <div class="note">Program dibuat ${cur.months} bulan sampai ${MONL[+S.goal.date.slice(5) - 1]} ${S.goal.date.slice(0, 4)}. Tiap evaluasi bulanan, kurva dihitung ulang dari kemampuan terbaru lo. Target ${unit === 'km' ? 'long ride' : ''} goal: <b>${fmtNum(g[roadKey], roadKey === 'speed' ? 1 : 0)} ${unit}</b>.</div>
      <div class="section-title" style="padding:14px 0 6px">Milestone 12 bulan ke depan</div>
      ${cur.points.slice(1, 13).map((p) => kv(`${MON[parseYmd(p.d).getMonth()]} ${parseYmd(p.d).getFullYear()}`, `${fmtNum(p.long)} km · ${fmtNum(p.speed, 1)} km/j · ${fmtNum(p.elev)} m`)).join('')}
      <button class="btn ghost block" style="margin-top:12px" id="editGoal">Ubah goal / kemampuan</button></div>`;
  }
  el.innerHTML = h;
  $$('[data-w]', el).forEach((b) => (b.onclick = () => { progWeek = +b.dataset.w; renderProgram(); }));
  $$('[data-rk]', el).forEach((b) => (b.onclick = () => { roadKey = b.dataset.rk; renderProgram(); }));
  $$('.day-card', el).forEach((b) => (b.onclick = () => openSessionSheet(b.dataset.d)));
  const eg = $('#editGoal', el); if (eg) eg.onclick = startOnboarding;
  $('#editBase', el).onclick = openEditBaseline;
  $('#evalProg', el).onclick = openMonthlyEval;
}

// ============ CHECK-IN ============
let ciDraft = null;
const ciWord = (q, v) => (v <= 3 ? q.lo : v <= 7 ? q.mid : q.hi);
const ciEmoji = (v) => (v <= 2 ? '😫' : v <= 4 ? '😕' : v <= 6 ? '😐' : v <= 8 ? '🙂' : '😄');
function ciPreview(draft) {
  const t = today(), bak = S.checkins[t];
  S.checkins[t] = draft; const r = readiness(draft), p = adjustedFor(t);
  if (bak) S.checkins[t] = bak; else delete S.checkins[t];
  return { r, p };
}
function renderCheckin() {
  const el = $('#view-checkin'), t = today(), existing = S.checkins[t];
  if (existing && !ciDraft) {
    const r = readiness(existing), p = adjustedFor(t), mx = existing.scale || 5;
    el.innerHTML = `<div class="card center ci-result"><div class="mono muted">Readiness · ${fmtDate(t)}</div>
      <div class="gauge">${gaugeSvg(r.score, r.color)}<div class="num"><div><b style="color:${r.color}">${r.score}</b><span class="small muted">${r.label}</span></div></div></div></div>
      <div class="card"><h2>Penyesuaian latihan hari ini</h2>
      ${p.adjust ? `<div class="note y">⚙️ ${esc(p.adjust)}</div>` : `<div class="note">✓ Kondisi oke — jalankan sesi sesuai program.</div>`}
      <div class="day-row" id="ciSess" style="margin-top:6px"><div class="day-bar" style="background:${p.color}"></div><div class="day-main"><div class="day-title">${p.ico} ${esc(p.name)}</div>
      <div class="day-meta">${p.type === 'REST' ? 'Istirahat' : `${fmtNum(p.dist, 1)} km · ${fmtNum(p.speed, 1)} km/j · ${fmtNum(p.elev)} m`}</div></div><span class="link">Detail ›</span></div></div>
      <div class="card"><h2>Kondisi lo hari ini</h2>${CHECKIN_Q.map((q) => { const v = existing[q.k], pct = ((v - 1) / (mx - 1)) * 100; return `<div class="ci-bar"><div class="ci-bar-top"><span>${q.ico} ${q.q}</span><b>${v}/${mx}</b></div><div class="ci-meter" style="--p:${pct}%"></div></div>`; }).join('')}
      ${existing.rhr ? kv('Denyut istirahat', `${existing.rhr} bpm`) : ''}${kv('Sakit', existing.sick ? 'Ya' : 'Tidak')}
      <button class="btn ghost block" style="margin-top:12px" id="ciEdit">Ubah check-in</button></div>
      ${checkinHistoryHtml()}`;
    $('#ciEdit').onclick = () => {
      ciDraft = { ...existing };
      if ((existing.scale || 5) !== 10) { CHECKIN_Q.forEach((q) => (ciDraft[q.k] = Math.round(((existing[q.k] - 1) / 4) * 9 + 1))); ciDraft.scale = 10; }
      renderCheckin();
    };
    $('#ciSess').onclick = () => openSessionSheet(t);
    return;
  }
  if (!ciDraft) { ciDraft = { scale: 10, sick: false, rhr: '' }; CHECKIN_Q.forEach((q) => (ciDraft[q.k] = 6)); }
  el.innerHTML = `<div class="ci-live card" id="ciLive"></div>
    <div class="card"><div class="mono muted">${fmtDate(t)}</div><h2 class="slab" style="font-size:22px">Gimana kondisi tubuh lo?</h2>
    <div class="small muted">Geser tiap slider — latihan hari ini langsung menyesuaikan.</div>
    ${CHECKIN_Q.map((q) => `<div class="ci-q" data-k="${q.k}">
      <div class="ci-q-top"><span class="ci-q-t">${q.ico} ${q.q}</span><span class="ci-val"><em class="ci-emo"></em><b class="ci-num"></b><small class="ci-word"></small></span></div>
      <input type="range" class="ci-range" min="1" max="10" step="1" value="${ciDraft[q.k]}" aria-label="${q.q}">
      <div class="scale-lbl"><span>${q.lo}</span><span>${q.hi}</span></div></div>`).join('')}
    <div class="toggle"><div><b>Lagi sakit?</b><div class="small muted">Demam, flu, cedera</div></div><button class="switch ${ciDraft.sick ? 'on' : ''}" id="ciSick"></button></div>
    <label class="f">Denyut jantung istirahat (opsional)<div class="unit"><input id="ciRhr" type="number" inputmode="numeric" value="${ciDraft.rhr || ''}" placeholder="contoh 58"><em>bpm</em></div></label>
    <button class="btn primary block" style="margin-top:16px" id="ciSave">Simpan & sesuaikan latihan</button></div>`;
  const paint = () => {
    $$('.ci-q', el).forEach((box) => {
      const q = CHECKIN_Q.find((x) => x.k === box.dataset.k), v = ciDraft[q.k], inp = $('.ci-range', box);
      inp.style.setProperty('--p', `${((v - 1) / 9) * 100}%`);
      $('.ci-num', box).textContent = `${v}/10`; $('.ci-word', box).textContent = ciWord(q, v); $('.ci-emo', box).textContent = ciEmoji(v);
    });
    const { r, p } = ciPreview({ ...ciDraft, rhr: parseInt($('#ciRhr')?.value, 10) || null });
    $('#ciLive').innerHTML = `<div class="ci-live-in"><div class="gauge sm">${gaugeSvg(r.score, r.color)}<div class="num"><div><b style="color:${r.color}">${r.score}</b></div></div></div>
      <div style="min-width:0"><div class="mono muted">Readiness (live)</div><div class="ci-live-lbl" style="color:${r.color}">${r.label}</div>
      <div class="small">${p.type === 'REST' ? '😴 Hari ini: <b>Rest Day</b>' : `${p.ico} <b>${esc(p.name)}</b> · ${fmtNum(p.dist)} km · ${fmtNum(p.speed, 1)} km/j`}</div>
      ${p.adjust ? `<div class="small" style="color:var(--orange);margin-top:2px">${esc(p.adjust.replace(/^Readiness \d+\/100 → /, ''))}</div>` : '<div class="small muted">Sesuai program</div>'}</div></div>`;
  };
  $$('.ci-range', el).forEach((inp) => (inp.oninput = () => { ciDraft[inp.closest('.ci-q').dataset.k] = +inp.value; paint(); }));
  $('#ciRhr').oninput = paint;
  $('#ciSick').onclick = (e) => { ciDraft.sick = !ciDraft.sick; e.currentTarget.classList.toggle('on', ciDraft.sick); paint(); };
  paint();
  $('#ciSave').onclick = () => {
    ciDraft.rhr = parseInt($('#ciRhr').value, 10) || null; ciDraft.scale = 10;
    const r = readiness(ciDraft); ciDraft.score = r.score; ciDraft.level = r.level;
    S.checkins[t] = ciDraft; ciDraft = null; save();
    toast(`Readiness ${r.score}/100 — ${r.label}`); homeSel = t; window.scrollTo(0, 0); renderCheckin();
  };
}
function checkinHistoryHtml() {
  const days = []; for (let i = 13; i >= 0; i--) days.push(ymd(addDays(new Date(), -i)));
  const vals = days.map((d) => S.checkins[d]?.score ?? 0);
  if (vals.filter(Boolean).length < 2) return '';
  return `<div class="card"><h2>Readiness 14 hari</h2>${barChart(vals, days.map((d, i) => (i % 2 ? '' : parseYmd(d).getDate())), { color: 'var(--sageD)' })}</div>`;
}

// ============ PROGRES ============
let progTab = 'month';
function renderProgress() {
  const el = $('#view-progress');
  let h = `<div class="tabs" style="top:calc(64px + env(safe-area-inset-top))">${[['month', 'Bulanan'], ['stats', 'Statistik'], ['body', 'Tubuh & Kalori']].map(([k, l]) => `<button data-t="${k}" class="${progTab === k ? 'on' : ''}">${l}</button>`).join('')}</div><div style="height:10px"></div>`;
  if (progTab === 'month') h += monthTabHtml();
  if (progTab === 'stats') h += statsTabHtml();
  if (progTab === 'body') h += bodyTabHtml();
  el.innerHTML = h;
  $$('[data-t]', el).forEach((b) => (b.onclick = () => { progTab = b.dataset.t; renderProgress(); }));
  const eb = $('#evalBtn2', el); if (eb) eb.onclick = openMonthlyEval;
  if (progTab === 'body') bindBodyTab(el);
}
function deltaHtml(it) {
  if (it.delta == null || !isFinite(it.delta)) return '<span class="delta flat">baru</span>';
  const cls = Math.abs(it.delta) < 1 ? 'flat' : it.delta > 0 ? 'up' : 'down';
  return `<span class="delta ${cls}">${it.delta > 0 ? '▲' : it.delta < 0 ? '▼' : '•'} ${fmtNum(Math.abs(it.delta))}%</span>`;
}
function monthTabHtml() {
  const rep = monthlyReport(); if (!rep) return '<div class="empty">Belum ada data.</div>';
  const dayN = clamp(daysBetween(rep.start, today()) + 1, 1, 28);
  let h = `<div class="card"><div class="mono muted">Bulan ke-${S.cycles.length} · hari ${dayN}/28</div><h2 class="slab" style="font-size:22px">${fmtDate(rep.start)} – ${fmtDate(rep.end)}</h2>
    <div class="progress" style="margin-top:10px"><div style="width:${(dayN / 28) * 100}%"></div></div>
    <div class="stats">${statHtml('Kepatuhan', Math.round(rep.compliance * 100), '%', 'hi')}${statHtml('Sesi', `${rep.done}/${rep.planned}`)}${statHtml('Jarak', fmtNum(rep.cur.km), 'km')}</div>
    ${cycleDue() ? '<button class="btn primary block" style="margin-top:12px" id="evalBtn2">Evaluasi & buat program bulan depan</button>' : `<div class="small muted" style="margin-top:10px">Evaluasi bulanan terbuka dalam ${28 - dayN + 1} hari.</div>`}</div>`;
  h += '<div class="pad" style="margin-bottom:10px"><button class="btn ghost block" data-fx="pdf">📄 Download laporan PDF</button></div>';
  h += `<div class="card"><h2>Kemajuan bulan ini 🏆</h2>${rep.wins.length ? rep.wins.map((w) => `<div class="win"><div class="b">★</div><div>${esc(w)}</div></div>`).join('') : '<div class="small muted">Belum ada kemajuan terukur — terus latihan & rekam aktivitas ya.</div>'}</div>`;
  h += `<div class="card"><h2>Dibanding 28 hari sebelumnya</h2>${rep.items.map((it) => `<div class="cmp"><div><div class="small muted">${it.label}</div><b>${fmtNum(it.now, it.dec)} ${it.unit}</b> <span class="small muted">vs ${fmtNum(it.prev, it.dec)}</span></div>${deltaHtml(it)}</div>`).join('')}</div>`;
  const past = S.cycles.filter((c) => c.report).slice().reverse();
  if (past.length) h += `<div class="card"><h2>Riwayat evaluasi</h2>${past.map((c) => kv(fmtDate(c.start), `${c.feedback?.feel || '-'} · ${fmtNum(c.base.dist)} km / ${fmtNum(c.base.speed, 1)} km/j / ${fmtNum(c.base.elev)} m`)).join('')}</div>`;
  return h;
}
function statsTabHtml() {
  if (!S.activities.some(isRide)) return `<div class="card"><h2>Belum ada data bersepeda</h2><div class="small muted">${S.auth ? 'Belum ada ride di Strava.' : 'Hubungkan Strava — semua riwayat ride lo akan diakumulasi di sini.'}</div>${S.auth ? '' : '<button class="btn primary block" style="margin-top:12px" onclick="stravaConnect()">Connect with Strava</button>'}</div>${otherSportsHtml()}`;
  const s = summarize(S.activities);
  const longA = S.activities.reduce((m, a) => (a.distance > (m?.distance || 0) ? a : m), null);
  const elevA = S.activities.reduce((m, a) => (a.elev > (m?.elev || 0) ? a : m), null);
  const spdA = S.activities.filter((a) => a.distance >= 5000).reduce((m, a) => (a.avg_speed > (m?.avg_speed || 0) ? a : m), null);
  let h = `<div class="pad"><div class="sgrid">
    <div class="cell"><div class="lbl">Total jarak</div><div class="val">${fmtNum(s.km)}<small> km</small></div><div class="sub">${fmtNum(s.count)} ride · ${fmtNum(s.sec / 3600)} jam</div></div>
    <div class="cell"><div class="lbl">Jarak terjauh</div><div class="val">${fmtNum(s.longest, 1)}<small> km</small></div><div class="sub">${longA ? esc(longA.name) + ' · ' + fmtDate(actDate(longA)) : ''}</div></div>
    <div class="cell"><div class="lbl">Total elevasi</div><div class="val">${fmtNum(s.elev)}<small> m</small></div><div class="sub">≈ ${fmtNum(s.elev / 8849, 1)}× Everest</div></div>
    <div class="cell"><div class="lbl">Elevasi terbesar</div><div class="val">${fmtNum(s.maxElev)}<small> m</small></div><div class="sub">${elevA ? esc(elevA.name) : ''}</div></div>
    <div class="cell"><div class="lbl">Avg speed tertinggi</div><div class="val">${fmtNum(s.topSpeed, 1)}<small> km/j</small></div><div class="sub">${spdA ? esc(spdA.name) + ' (≥5 km)' : ''}</div></div>
    <div class="cell"><div class="lbl">Avg speed tersering</div><div class="val">${fmtNum(s.modeSpeed)}–${fmtNum(s.modeSpeed + 1)}<small> km/j</small></div><div class="sub">${s.modeCount} ride di rentang ini</div></div>
    <div class="cell"><div class="lbl">Total kalori</div><div class="val">${fmtNum(s.kcal)}<small> kcal</small></div><div class="sub">≈ ${fmtNum(s.fatG / 1000, 1)} kg lemak</div></div>
    <div class="cell"><div class="lbl">Rata-rata per ride</div><div class="val">${fmtNum(s.avgDist, 1)}<small> km</small></div><div class="sub">${fmtNum(s.avgSpeed, 1)} km/j keseluruhan</div></div>
    </div></div>`;
  const keys = Object.keys(s.hist).map(Number).sort((a, b) => a - b);
  if (keys.length) {
    const rng = []; for (let k = keys[0]; k <= keys[keys.length - 1]; k++) rng.push(k);
    h += `<div class="card" style="margin-top:10px"><h2>Distribusi avg speed</h2><div class="small muted">Jumlah ride (≥10 km) per rentang kecepatan</div>
      ${barChart(rng.map((k) => s.hist[k] || 0), rng.map((k) => k), { hiLast: false, color: 'var(--teal)' })}</div>`;
  }
  // per tahun
  const years = {}; S.activities.forEach((a) => { const y = actDate(a).slice(0, 4); (years[y] = years[y] || []).push(a); });
  h += `<div class="card"><h2>Per tahun</h2>${Object.keys(years).sort().reverse().map((y) => { const ss = summarize(years[y]); return kv(y, `${fmtNum(ss.km)} km · ${fmtNum(ss.elev)} m · ${ss.count} ride`); }).join('')}</div>`;
  h += otherSportsHtml();
  h += `<div class="small muted center" style="padding:6px 16px 16px">Powered by Strava · ${S.lastSync ? 'sinkron ' + new Date(S.lastSync).toLocaleString('id-ID', { dateStyle: 'medium', timeStyle: 'short' }) : 'belum sinkron'}${S.demo ? ' · DATA DEMO' : ''}</div>`;
  return h;
}
function bodyTabHtml() {
  const b = bodyStats(), p = S.profile;
  const wk = summarize(actsBetween(ymd(addDays(new Date(), -6)), today()), true);
  const mo = summarize(actsBetween(ymd(addDays(new Date(), -29)), today()), true);
  const w = S.weights;
  let h = `<div class="card"><h2>Kalkulator tubuh</h2>
    <div class="grid3"><label class="f">Berat (kg)<div class="unit"><input id="bWeight" type="number" step="0.1" value="${p.weight}"><em>kg</em></div></label>
    <label class="f">Tinggi (cm)<div class="unit"><input id="bHeight" type="number" value="${p.height}"><em>cm</em></div></label>
    <label class="f">Umur (th)<div class="unit"><input id="bAge" type="number" value="${p.age}"><em>th</em></div></label></div>
    <button class="btn teal block" style="margin-top:12px" id="bSave">Simpan & hitung ulang</button>
    <div class="stats four" style="margin-top:14px">${statHtml('BMI', fmtNum(b.bmi, 1), '')}${statHtml('Kategori', b.cat)}${statHtml('Lemak', fmtNum(b.fatPct, 1), '%')}${statHtml('BMR', fmtNum(b.bmr), '')}</div>
    <div class="note">BB ideal (BMI Asia 18,5–22,9): <b>${fmtNum(b.idealLo, 1)}–${fmtNum(b.idealHi, 1)} kg</b> · Kebutuhan harian aktif ≈ <b>${fmtNum(b.tdee)} kcal</b> · HR max ≈ <b>${b.hrMax} bpm</b>${S.goal?.weight ? ` · Target BB: <b>${S.goal.weight} kg</b> (${fmtNum(p.weight - S.goal.weight, 1)} kg lagi)` : ''}</div></div>`;
  h += `<div class="card"><h2>Kalori & lemak terbakar</h2><div class="small muted">Dari semua aktivitas (semua olahraga), dihitung pakai berat ${fmtNum(p.weight, 1)} kg</div>
    <div class="section-title" style="padding:12px 0 0;font-size:14px">7 hari terakhir</div>
    <div class="stats">${statHtml('Kalori', fmtNum(wk.kcal), 'kcal', 'hi')}${statHtml('Lemak', fmtNum(wk.fatG), 'g', 'hi')}${statHtml('Setara BB', fmtNum(wk.kcal / 7.7), 'g')}</div>
    <div class="section-title" style="padding:12px 0 0;font-size:14px">30 hari terakhir</div>
    <div class="stats">${statHtml('Kalori', fmtNum(mo.kcal), 'kcal', 'hi')}${statHtml('Lemak', fmtNum(mo.fatG / 1000, 2), 'kg', 'hi')}${statHtml('Setara BB', fmtNum(mo.kcal / 7700, 2), 'kg')}</div>
    <div class="note">Setara BB = kalori ÷ 7.700 kcal/kg. Berat benar-benar turun kalau asupan makan harian < ${fmtNum(b.tdee)} kcal + kalori latihan.</div></div>`;
  if (w.length >= 2) {
    const x0 = parseYmd(w[0].d).getTime();
    h += `<div class="card"><h2>Riwayat berat badan</h2>${lineChart({ series: [{ pts: w.map((x) => [(parseYmd(x.d).getTime() - x0) / 864e5, x.kg]), color: 'var(--teal)', dots: true, area: true }], xLabels: [[0, fmtDateShort(w[0].d).slice(5)], [(parseYmd(w[w.length - 1].d).getTime() - x0) / 864e5, fmtDateShort(w[w.length - 1].d).slice(5)]], goalY: S.goal?.weight || null, yFmt: (v) => fmtNum(v, 1) })}
      <div class="stats">${statHtml('Awal', fmtNum(w[0].kg, 1), 'kg')}${statHtml('Sekarang', fmtNum(w[w.length - 1].kg, 1), 'kg')}${statHtml('Perubahan', (w[w.length - 1].kg - w[0].kg > 0 ? '+' : '') + fmtNum(w[w.length - 1].kg - w[0].kg, 1), 'kg', 'hi')}</div></div>`;
  }
  return h;
}
function bindBodyTab(el) {
  $('#bSave', el).onclick = () => {
    const wv = parseFloat($('#bWeight').value), hv = parseFloat($('#bHeight').value), av = parseInt($('#bAge').value, 10);
    if (!(wv > 30 && hv > 120 && av > 10)) return toast('Cek lagi angkanya');
    S.profile.height = hv; S.profile.age = av; logWeight(wv); save(); toast('Data tubuh diperbarui'); renderProgress();
  };
}

// ============ MONTHLY EVALUATION ============
function openEditBaseline() {
  const c = currentCycle(), b = c.base, sug = recordedBaselineSuggestion();
  openSheet(`<div class="sheet-pad"><h2 class="st">Atur Baseline Performa Bersepeda</h2><div class="small muted">Data ini jadi fondasi pembuatan program latihan 1 bulan ke depan.</div></div>
    <div class="card" style="margin-top:12px">
    <label class="f">Rata-rata jarak bersepeda yang sering ditempuh (km)<input id="bbDist" type="number" inputmode="decimal" step="1" value="${round(b.dist, 1)}"></label>
    <label class="f">Average speed paling sering dicapai (km/jam)<input id="bbSpeed" type="number" inputmode="decimal" step="0.5" value="${round(b.speed, 0.5)}"></label>
    <label class="f">Elevasi gain maksimal yang dikuasai (m)<input id="bbElev" type="number" inputmode="decimal" step="10" value="${round(b.elev, 10)}"></label>
    ${sug ? `<button class="btn ghost small" style="margin-top:12px" id="bbSug">Isi dari Strava (28 hari: ${fmtNum(sug.dist, 1)} km · ${fmtNum(sug.speed, 1)} km/j · ${fmtNum(sug.elev)} m)</button>` : ''}
    <button class="btn primary block" style="margin-top:16px" id="bbSave">Kalkulasi Ulang Program Bulanan</button></div>`, (root) => {
    const sg = $('#bbSug', root); if (sg) sg.onclick = () => { $('#bbDist').value = sug.dist; $('#bbSpeed').value = sug.speed; $('#bbElev').value = sug.elev; };
    $('#bbSave', root).onclick = () => {
      const nb = { dist: parseFloat($('#bbDist').value), speed: parseFloat($('#bbSpeed').value), elev: parseFloat($('#bbElev').value), d: today() };
      if (!(nb.dist > 0 && nb.speed > 5 && nb.elev >= 0)) return toast('Cek lagi angkanya');
      recalcCycle(c, nb); S.baseline = nb; save(); closeSheet(); render(); scheduleNotifications();
      toast(`Program dihitung ulang — long ride ${fmtNum(c.cap.long)} km, speed ${fmtNum(c.cap.speed, 1)} km/j`);
    };
  });
}

const EVAL_ITEMS = [
  ['cardio', 'Nafas & Cardiorespiratory Terasa Lebih Ringan', 'Bisa mengayuh lebih lama tanpa lelah berlebihan.'],
  ['climb', 'Daya Otot Tanjakan Bertambah', 'Elevasi gain terasa lebih mudah diatasi.'],
  ['speed', 'Average Speed Naik Secara Konsisten', 'Nyaman di kecepatan jelajah yang lebih tinggi.'],
  ['recovery', 'Pemulihan Lebih Cepat', 'Pegal hilang lebih cepat setelah latihan berat.'],
  ['hard', 'Program Terasa Terlalu Berat', 'Porsi bulan depan akan ditahan & sedikit diturunkan.'],
];
function openMonthlyEval() {
  const rep = monthlyReport(), c = currentCycle(), sug = recordedBaselineSuggestion();
  const dayN = clamp(daysBetween(c.start, today()) + 1, 1, 99);
  openSheet(`<div class="sheet-pad"><h2 class="st">Evaluasi & Refleksi Kemajuan Bulanan</h2>
    <div class="small muted">Pilih peningkatan yang lo rasakan selama 1 bulan terakhir untuk penyesuaian porsi bulan berikutnya.</div>
    ${dayN < 28 ? `<div class="note y">Baru hari ke-${dayN} dari 28. Evaluasi sekarang akan memulai program bulan baru hari ini.</div>` : ''}
    <div id="evChecks">${EVAL_ITEMS.map(([k, t, d]) => `<div class="check-card" data-k="${k}"><div class="box"></div><div><b>${t}</b><span>${d}</span></div></div>`).join('')}</div></div>
    ${rep.wins.length ? `<div class="card" style="margin-top:12px"><h2>Kemajuan terukur</h2>${rep.wins.map((w) => `<div class="win"><div class="b">★</div><div>${esc(w)}</div></div>`).join('')}</div>` : ''}
    <details class="card evx" style="margin-top:12px"><summary><b>Sesuaikan angka baseline (opsional)</b></summary>
      ${sug ? `<div class="small muted" style="margin-top:8px">Data Strava 28 hari: ${fmtNum(sug.dist, 1)} km · ${fmtNum(sug.speed, 1)} km/j · ${fmtNum(sug.elev)} m <button class="link" id="evSug">Pakai</button></div>` : ''}
      <div class="grid3"><label class="f">Jarak (km)<input id="evDist" type="number" value="${round(c.base.dist, 1)}"></label>
      <label class="f">Speed (km/j)<input id="evSpeed" type="number" step="0.5" value="${round(c.base.speed, 0.5)}"></label>
      <label class="f">Elevasi (m)<input id="evElev" type="number" step="10" value="${round(c.base.elev, 10)}"></label></div>
      <label class="f">Berat badan sekarang (kg)<input id="evWeight" type="number" step="0.1" value="${S.profile.weight}"></label></details>
    <div class="sheet-pad"><button class="btn primary block" id="evSave">Perbarui Program Bulan Depan</button></div>`, (root) => {
    const sel = new Set();
    const label = () => {
      const pos = ['cardio', 'climb', 'speed', 'recovery'].filter((k) => sel.has(k)).length;
      $('#evSave', root).textContent = sel.has('hard') ? 'Perbarui Program Bulan Depan (−10% Porsi)' : pos ? `Perbarui Program Bulan Depan (+${pos >= 2 ? '10–15' : '5–10'}% Porsi)` : 'Perbarui Program Bulan Depan (Porsi Tetap)';
    };
    label();
    $$('.check-card', root).forEach((b) => (b.onclick = () => {
      const k = b.dataset.k;
      if (sel.has(k)) sel.delete(k); else { sel.add(k); if (k === 'hard') ['cardio', 'climb', 'speed', 'recovery'].forEach((x) => sel.delete(x)); else sel.delete('hard'); }
      $$('.check-card', root).forEach((x) => x.classList.toggle('on', sel.has(x.dataset.k))); label();
    }));
    const es = $('#evSug', root); if (es) es.onclick = () => { $('#evDist').value = sug.dist; $('#evSpeed').value = sug.speed; $('#evElev').value = sug.elev; };
    $('#evSave', root).onclick = () => {
      let nb = { dist: +$('#evDist').value, speed: +$('#evSpeed').value, elev: +$('#evElev').value, d: today() };
      const pos = ['cardio', 'climb', 'speed', 'recovery'].filter((k) => sel.has(k)).length;
      if (sel.has('cardio')) nb.dist *= 1.12;
      if (sel.has('climb')) nb.elev *= 1.12;
      if (sel.has('speed')) nb.speed *= 1.03;
      let mult = 1 + 0.05 * pos;
      if (sel.has('hard')) { nb.dist *= 0.9; nb.elev *= 0.9; mult = 0.7; }
      c.report = { wins: rep.wins, compliance: rep.compliance, km: rep.cur.km };
      logWeight(+$('#evWeight').value);
      S.baseline = nb;
      const nc = newCycle(nb, mult, { improvements: [...sel], feel: sel.has('hard') ? 'Terlalu berat' : pos ? `+${pos} peningkatan` : 'Tetap' }, null);
      save(); closeSheet(); progWeek = 0; homeSel = today();
      toast(`Program bulan ke-${S.cycles.length} siap! Long ride ${fmtNum(nc.cap.long)} km`);
      go('program'); scheduleNotifications();
    };
  });
}

// ============ PROFILE (ANDA) ============
let youTab = 'progress';
function renderYou() {
  const el = $('#view-you'), p = S.profile, b = bodyStats(), all = summarize(S.activities);
  let h = `<div class="card"><div class="prof">${avatarHtml()}<div style="flex:1;min-width:0"><h2>${esc(p.name || 'Pesepeda')}</h2>
    <div class="small muted">${p.age} th · ${fmtNum(p.weight, 1)} kg · ${p.height} cm</div>
    ${stravaProfileUrl() ? `<a class="small strava-link" href="${stravaProfileUrl()}" target="_blank" rel="noopener" style="font-weight:700">strava.com/athletes/${S.athlete.id} ↗</a>` : '<span class="small muted">Strava belum terhubung</span>'}
    </div></div>
    <div class="btn-row"><button class="btn ghost small" id="editProf">Edit profil</button><label class="btn ghost small" style="text-align:center">Ganti foto<input type="file" accept="image/*" id="photoIn" hidden></label></div>
    <div class="stats">${statHtml('Total km', fmtNum(all.km), '')}${statHtml('Ride', fmtNum(all.count), '')}${statHtml('Elevasi', fmtNum(all.elev), 'm')}</div></div>`;
  if (S.goal) {
    const c = currentCycle(), g = goalCap();
    const pct = c ? Math.round(((c.cap.long / g.long + c.cap.speed / g.speed + c.cap.elev / g.elev) / 3) * 100) : 0;
    h += `<div class="card goal-card"><div class="mono">Goal · ${MONL[+S.goal.date.slice(5) - 1]} ${S.goal.date.slice(0, 4)} · ${monthsToGoal()} bulan lagi</div>
      <div class="big">${esc(S.goal.title)}</div>
      <div class="stats">${statHtml('Jarak', fmtNum(S.goal.dist), 'km')}${statHtml('Avg speed', fmtNum(S.goal.speed, 1), 'km/j')}${statHtml('Elevasi', fmtNum(S.goal.elev), 'm')}</div>
      <div class="bar-track"><div class="bar-fill" style="width:${clamp(pct, 2, 100)}%"></div></div><div class="small" style="margin-top:6px;color:var(--lav)">Kapasitas saat ini ${clamp(pct, 0, 100)}% dari goal</div></div>`;
  }
  h += youExtrasHtml();
  h += `<div class="card"><div class="card-head"><h2>Data tubuh</h2><button class="link" id="toBody">Kalkulator ›</button></div>
    <div class="stats four">${statHtml('Berat', fmtNum(p.weight, 1), 'kg')}${statHtml('Tinggi', p.height, 'cm')}${statHtml('Umur', p.age, 'th')}${statHtml('BMI', fmtNum(b.bmi, 1), '')}</div></div>`;
  h += `<div class="tabs">${[['progress', 'Progres'], ['acts', 'Aktivitas']].map(([k, l]) => `<button data-yt="${k}" class="${youTab === k ? 'on' : ''}">${l}</button>`).join('')}</div>`;
  if (youTab === 'progress') {
    const weeks = [], labels = [];
    const mon = addDays(parseYmd(today()), -((new Date().getDay() + 6) % 7));
    for (let i = 11; i >= 0; i--) { const s = addDays(mon, -7 * i); weeks.push(summarize(actsBetween(ymd(s), ymd(addDays(s, 6)))).km); labels.push(i % 3 === 0 ? `${s.getDate()}/${s.getMonth() + 1}` : ''); }
    const thisW = summarize(actsBetween(ymd(mon), today()));
    const yr = summarize(actsBetween(`${new Date().getFullYear()}-01-01`, today()));
    h += `<div class="card" style="margin-top:0;border-top:0"><div class="mono muted">Minggu ini</div>
      <div class="stats">${statHtml('Jarak', fmtNum(thisW.km, 1), 'km')}${statHtml('Waktu', fmtDurSec(thisW.sec))}${statHtml('Elevasi', fmtNum(thisW.elev), 'm')}</div>
      <div style="margin-top:14px">${barChart(weeks, labels, { fmt: (v) => fmtNum(v) })}</div><div class="small muted center">Jarak per minggu · 12 minggu terakhir</div></div>
      <div class="card"><h2>Tahun ${new Date().getFullYear()}</h2>${kv('Jarak', `${fmtNum(yr.km)} km`)}${kv('Ride', yr.count)}${kv('Elevasi', `${fmtNum(yr.elev)} m`)}${kv('Waktu', fmtDurSec(yr.sec))}${kv('Ride terjauh', `${fmtNum(yr.longest, 1)} km`)}</div>
      <div class="card"><h2>Sepanjang masa</h2>${kv('Jarak terjauh', `${fmtNum(all.longest, 1)} km`)}${kv('Elevasi terbesar', `${fmtNum(all.maxElev)} m`)}${kv('Avg speed tertinggi', `${fmtNum(all.topSpeed, 1)} km/j`)}${kv('Avg speed tersering', `${fmtNum(all.modeSpeed)}–${fmtNum(all.modeSpeed + 1)} km/j`)}
      <button class="btn ghost block" style="margin-top:12px" id="toStats">Semua statistik ›</button></div>`;
  } else {
    h += S.activities.length ? S.activities.slice(0, 80).map((a) => { const sp = sportOf(a), km = a.distance / 1000, mv = a.moving_time || a.elapsed_time; return `<div class="card" data-act="${a.id}" style="margin-bottom:1px;padding:12px 16px"><div class="day-title">${sp.ico} ${esc(a.name)}</div>
      <div class="day-meta">${fmtDateShort(actDate(a))} · ${km ? fmtNum(km, 1) + ' km · ' : ''}${sp.pace && km ? fmtPace(mv / km) + '/km · ' : km ? fmtNum(a.avg_speed * 3.6, 1) + ' km/j · ' : ''}${fmtDurSec(mv)} · ${fmtNum(burnOfActivity(a).kcal)} kcal</div></div>`; }).join('') : '<div class="empty">Belum ada aktivitas.</div>';
  }
  el.innerHTML = h;
  $$('[data-yt]', el).forEach((b) => (b.onclick = () => { youTab = b.dataset.yt; renderYou(); }));
  $$('[data-act]', el).forEach((b) => (b.onclick = () => openActivitySheet(b.dataset.act)));
  $('#editProf', el).onclick = startOnboarding;
  $('#toBody', el).onclick = () => { progTab = 'body'; go('progress'); };
  const ts = $('#toStats', el); if (ts) ts.onclick = () => { progTab = 'stats'; go('progress'); };
  $('#photoIn', el).onchange = (e) => {
    const f = e.target.files[0]; if (!f) return;
    const img = new Image(), rd = new FileReader();
    rd.onload = () => { img.onload = () => { const cv = document.createElement('canvas'), s = 256; cv.width = cv.height = s; const k = Math.max(s / img.width, s / img.height); const ctx = cv.getContext('2d'); ctx.drawImage(img, (s - img.width * k) / 2, (s - img.height * k) / 2, img.width * k, img.height * k); S.profile.photo = cv.toDataURL('image/jpeg', 0.85); save(); render(); toast('Foto profil diperbarui'); }; img.src = rd.result; };
    rd.readAsDataURL(f);
  };
}

// ============ ACTIVITY DETAIL ============
function openActivitySheet(id) {
  const a = S.activities.find((x) => String(x.id) === String(id)); if (!a) return;
  const b = burnOfActivity(a), d = actDate(a), p = adjustedFor(d), sp = sportOf(a), km = a.distance / 1000, mv = a.moving_time || a.elapsed_time;
  let prof = '';
  if (a.alts && a.alts.filter((x) => x != null).length > 5 && a.poly) {
    const pts = decodePolyline(a.poly); let acc = 0; const series = [];
    pts.forEach((pt, i) => { if (i) acc += haversine(pts[i - 1], pt); if (a.alts[i] != null) series.push([acc / 1000, a.alts[i]]); });
    prof = `<div class="card"><h2>Profil elevasi</h2>${lineChart({ series: [{ pts: series, color: 'var(--teal)', area: true }], xLabels: [[0, '0 km'], [acc / 1000, fmtNum(acc / 1000, 1) + ' km']], h: 130 })}</div>`;
  }
  openSheet(`<div class="sheet-pad"><div class="mono muted">${sp.ico} ${sp.label} · ${fmtDate(d)} · ${(a.start_date_local || '').slice(11, 16)}</div><h2 class="st">${esc(a.name)}</h2>${a.desc ? `<div class="small">${esc(a.desc)}</div>` : ''}</div>
    ${polylineSvg(a.poly) ? `<div class="pad">${polylineSvg(a.poly)}</div>` : ''}
    <div class="card" style="margin-top:12px">${actStatsHtml(a, b)}
    ${km ? `<div class="stats">${sp.pace ? statHtml('Pace', fmtPace(km ? mv / km : 0), '/km') : statHtml('Max speed', fmtNum(a.max_speed * 3.6, 1), 'km/j')}${statHtml('Waktu total', fmtDurSec(a.elapsed_time || mv))}${statHtml(a.rpe ? 'RPE' : 'Avg HR', a.rpe ? a.rpe + '/10' : a.avg_hr ? Math.round(a.avg_hr) : '—', !a.rpe && a.avg_hr ? 'bpm' : '')}</div>` : ''}</div>
    ${prof}
    <div class="card"><h2>Pembakaran energi</h2><div class="stats">${statHtml('Kalori', fmtNum(b.kcal), 'kcal', 'hi')}${statHtml('Lemak', fmtNum(b.fatG), 'g', 'hi')}${statHtml('Setara BB', fmtNum(b.weightLossG), 'g')}</div>
    ${kv('Sumber energi dari lemak', `${Math.round(b.frac * 100)}%`)}${kv('Dihitung dengan berat', `${fmtNum(S.profile.weight, 1)} kg`)}${kv('Metode', a.kilojoules && isRide(a) ? 'Power meter (kJ)' : sp.gps ? 'MET kecepatan + kerja menanjak' : 'MET olahraga × durasi')}
    <div class="small muted" style="margin-top:8px">Setara ≈ ${fmtNum(b.kcal / 250, 1)} piring nasi putih (250 kcal).</div></div>
    ${splitsHtml(a)}
    <div class="pad" style="margin-bottom:10px"><button class="btn primary block" id="shareBtn">📸 Bagikan ke Story</button></div>
    ${isRide(a) && p && p.type !== 'REST' ? `<div class="card"><h2>Program hari itu</h2>${kv('Sesi', `${p.ico} ${esc(p.name)}`)}${kv('Target', `${fmtNum(p.dist, 1)} km · ${fmtNum(p.speed, 1)} km/j · ${fmtNum(p.elev)} m`)}<button class="btn ghost block" style="margin-top:10px" id="toSess">Lihat hasil vs target</button></div>` : ''}
    <div class="pad">
      ${a.source === 'strava' ? `<a class="btn ghost block center strava-link" style="text-decoration:none" href="${stravaActivityUrl(a.id)}" target="_blank" rel="noopener">View on Strava ↗</a>` : ''}
      ${a.source !== 'strava' ? '<button class="btn danger block" style="margin-top:8px" id="delAct">Hapus aktivitas</button>' : ''}
    </div>`, (root) => {
    const ts = $('#toSess', root); if (ts) ts.onclick = () => openSessionSheet(d);
    $('#shareBtn', root).onclick = () => openShareSheet(a);
    const gx = $('#gpxBtn', root); if (gx) gx.onclick = () => exportActivityGpx(a);
    const da = $('#delAct', root); if (da) da.onclick = () => { if (!confirm('Hapus aktivitas ini?')) return; S.activities = S.activities.filter((x) => x.id !== a.id); save(); closeSheet(); render(); toast('Aktivitas dihapus'); };
  });
}

// ============ OLAHRAGA LAIN & KALENDER ============
function otherSportsHtml() {
  const by = summarize(S.activities, true).bySport, keys = Object.keys(by).filter((k) => k !== 'Ride');
  if (!keys.length) return '';
  return `<div class="card"><h2>Olahraga lain</h2>${keys.map((k) => kv(`${SPORTS[k].ico} ${SPORTS[k].label}`, `${by[k].n}× · ${by[k].km ? fmtNum(by[k].km, 1) + ' km · ' : ''}${fmtDurSec(by[k].sec)}`)).join('')}</div>`;
}
const calStamp = (d, hm, addMin = 0) => { const dt = parseYmd(d); const [h, m] = hm.split(':').map(Number); dt.setHours(h, m + addMin, 0, 0); return `${dt.getFullYear()}${pad(dt.getMonth() + 1)}${pad(dt.getDate())}T${pad(dt.getHours())}${pad(dt.getMinutes())}00`; };
const sessionText = (p) => `${p.ico} ${p.name}: ${fmtNum(p.dist, 1)} km · ${fmtNum(p.speed, 1)} km/j · elevasi ${fmtNum(p.elev)} m · ${fmtDur(p.dur)} · ${p.zone}\n\n${p.steps.map((x, i) => `${i + 1}. ${x}`).join('\n')}\n\nNutrisi: ${p.fuel || '-'}`;
function gcalLink(p) {
  const t = S.settings.trainTime, dur = Math.max(30, Math.round(p.dur || 60));
  const q = new URLSearchParams({ action: 'TEMPLATE', text: `🚴 ${p.name} — Cycling Coach`, dates: `${calStamp(p.date, t)}/${calStamp(p.date, t, dur)}`, details: sessionText(p).replace(/\\n/g, '\n'), ctz: Intl.DateTimeFormat().resolvedOptions().timeZone || 'Asia/Jakarta' });
  return 'https://calendar.google.com/calendar/render?' + q.toString();
}
function downloadIcs() {
  const t = S.settings.trainTime, lines = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Cycling Coach//ID', 'CALSCALE:GREGORIAN', 'X-WR-CALNAME:Cycling Coach'];
  const escI = (x) => String(x).replace(/\\/g, '\\\\').replace(/;/g, '\\;').replace(/,/g, '\\,').replace(/\n/g, '\\n');
  let n = 0;
  for (let i = 0; i < 28; i++) {
    const d = ymd(addDays(new Date(), i)), p = planFor(d); if (!p || p.type === 'REST') continue;
    const dur = Math.max(30, Math.round(p.dur || 60)); n++;
    lines.push('BEGIN:VEVENT', `UID:cc-${d}@cyclingcoach`, `DTSTAMP:${calStamp(today(), '00:00')}`, `DTSTART:${calStamp(d, t)}`, `DTEND:${calStamp(d, t, dur)}`,
      `SUMMARY:${escI(`${p.ico} ${p.name} — ${fmtNum(p.dist, 1)} km`)}`, `DESCRIPTION:${escI(sessionText(p).replace(/\\n/g, '\n'))}`,
      'BEGIN:VALARM', 'ACTION:DISPLAY', 'DESCRIPTION:Waktunya latihan!', 'TRIGGER:-PT15M', 'END:VALARM', 'END:VEVENT');
  }
  lines.push('END:VCALENDAR');
  shareOrDownload('jadwal-cycling-coach.ics', lines.join('\r\n'), 'text/calendar');
  toast(`${n} sesi latihan diekspor`);
}

// ============ SETTINGS ============
function openSettings() {
  const st = S.settings;
  openSheet(`<div class="sheet-pad"><h2 class="st">Setelan</h2></div>
    <div class="card" style="margin-top:10px"><h2>Strava</h2>
    ${S.auth ? `<div class="feed-head" style="margin:8px 0">${avatarHtml()}<div><div class="feed-name">${esc([S.athlete?.firstname, S.athlete?.lastname].filter(Boolean).join(' ') || 'Terhubung')}</div><div class="feed-meta">${S.activities.filter((a) => a.source === 'strava').length} aktivitas · sinkron ${S.lastSync ? new Date(S.lastSync).toLocaleString('id-ID', { dateStyle: 'short', timeStyle: 'short' }) : '-'}</div></div></div>
      <div class="btn-row"><button class="btn primary" id="sSync">Sinkron sekarang</button><button class="btn danger" id="sDisc">Putuskan</button></div>
      <button class="btn ghost block" style="margin-top:8px" id="sFull">Sinkron ulang semua riwayat</button>`
    : `<div class="small muted">1) Buka <b>strava.com/settings/api</b> → buat app (butuh langganan Strava). 2) Isi <b>Authorization Callback Domain</b>: <code>${isNative ? 'localhost' : esc(location.hostname)}</code>. 3) Salin Client ID & Secret ke sini.</div>
      <label class="f">Client ID<input id="sCid" inputmode="numeric" value="${esc(st.clientId)}"></label>
      <label class="f">Client Secret<input id="sSec" type="password" value="${esc(st.clientSecret)}"></label>
      <button class="btn primary block" style="margin-top:12px" id="sConn">Simpan & Connect with Strava</button>`}
    <div class="toggle"><div><b>Sinkron otomatis</b><div class="small muted">Tiap app dibuka, kembali aktif & tiap 5 menit</div></div><button class="switch ${st.autoSync ? 'on' : ''}" id="sAuto"></button></div>
    <div class="small muted center" style="margin-top:4px">Powered by Strava</div></div>
    <div class="card"><h2>Jadwal & pengingat</h2>
    <label class="f">Rest day per minggu<select id="sRest"><option value="1" ${st.restDays == 1 ? 'selected' : ''}>1 hari + recovery spin</option><option value="2" ${st.restDays == 2 ? 'selected' : ''}>2 hari</option></select></label>
    <label class="f">Hari long ride<select id="sLong"><option value="6" ${st.longDay == 6 ? 'selected' : ''}>Sabtu</option><option value="0" ${st.longDay == 0 ? 'selected' : ''}>Minggu</option></select></label>
    <div class="grid2"><label class="f">Pengingat check-in<input id="sCi" type="time" value="${st.checkinTime}"></label><label class="f">Jam latihan<input id="sTr" type="time" value="${st.trainTime}"></label></div>
    <button class="btn teal block" style="margin-top:12px" id="sSave">Simpan</button>
    ${isNative ? '<button class="btn ghost block" style="margin-top:8px" id="sTest">Tes notifikasi</button>' : `<div class="note" style="margin-top:12px">🔔 Di versi browser, pengingat dikirim lewat kalender HP supaya tetap bunyi walau app ditutup.</div>
    <button class="btn ghost block" style="margin-top:8px" id="sIcs">📅 Export jadwal 4 minggu (.ics)</button>
    <div class="small muted" style="margin-top:6px">Buka file .ics di HP/laptop → pilih Google Calendar / Kalender. Atau tambah per sesi lewat tombol "Tambah ke Google Calendar" di detail latihan.</div>`}</div>
    ${settingsExtrasHtml()}
    <div class="card"><h2>Lokasi cuaca</h2><div class="small muted">${S.settings.loc ? `Sekarang: <b>${esc(S.settings.loc.name)}</b>${S.settings.loc.auto ? ' (otomatis)' : ''}` : 'Belum diatur'} · untuk prakiraan cuaca & planner hidrasi.</div><button class="btn ghost block" style="margin-top:10px" id="sLoc">📍 Atur lokasi</button></div>
    <div class="card"><h2>Tampilan</h2><label class="f">Tema<select id="sTheme"><option value="auto" ${st.theme === 'auto' ? 'selected' : ''}>Otomatis (ikut HP)</option><option value="light" ${st.theme === 'light' ? 'selected' : ''}>Terang</option><option value="dark" ${(st.theme || 'dark') === 'dark' ? 'selected' : ''}>Gelap (Strava)</option></select></label></div>
    <div class="card"><h2>Data</h2><div class="small muted">Data tersimpan di browser/HP ini. Pindah perangkat? Backup lalu pulihkan di perangkat baru.</div><div class="btn-row"><button class="btn ghost" id="sExport">Backup data</button><label class="btn ghost center">Pulihkan<input type="file" accept="application/json,.json" id="sImport" hidden></label></div><button class="btn ghost block" style="margin-top:8px" id="sGoal">Ubah goal & kemampuan</button>
    <button class="btn danger block" style="margin-top:8px" id="sReset">Hapus semua data</button>
    <div class="small muted center" style="margin-top:12px">Cycling Coach v1.0 · Data tersimpan di HP</div></div>`, (root) => {
    const on = (id, fn) => { const e = $('#' + id, root); if (e) e.onclick = fn; };
    on('sSave', () => { st.restDays = +$('#sRest').value; st.longDay = +$('#sLong').value; st.checkinTime = $('#sCi').value; st.trainTime = $('#sTr').value; save(); scheduleNotifications(); closeSheet(); render(); toast('Setelan disimpan'); });
    on('sTest', testNotif);
    on('sIcs', downloadIcs);
    on('sLoc', openLocationSheet);
    const th = $('#sTheme', root); if (th) th.onchange = () => { st.theme = th.value; save(); applyTheme(); };
    on('sConn', () => { st.clientId = $('#sCid').value.trim(); st.clientSecret = $('#sSec').value.trim(); save(); stravaConnect(); });
    on('sSync', () => { closeSheet(); syncStrava(false); });
    on('sFull', () => { closeSheet(); syncStrava(false, true); });
    on('sDisc', async () => { if (confirm('Putuskan koneksi Strava? Aktivitas dari Strava di app akan dihapus.')) { await stravaDisconnect(); closeSheet(); } });
    on('sAuto', (e) => { st.autoSync = !st.autoSync; e.currentTarget.classList.toggle('on', st.autoSync); save(); });
    on('sGoal', () => { closeSheet(); startOnboarding(); });
    on('sExport', () => {
      const data = { ...S, auth: null, settings: { ...S.settings, clientSecret: '' } };
      const blob = new Blob([JSON.stringify(data)], { type: 'application/json' });
      const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `cycling-coach-backup-${today()}.json`; a.click();
      setTimeout(() => URL.revokeObjectURL(a.href), 2000); S.lastBackup = Date.now(); save(); toast('Backup diunduh');
    });
    const imp = $('#sImport', root); if (imp) imp.onchange = async (e) => {
      const f = e.target.files[0]; if (!f) return;
      try {
        const d = JSON.parse(await f.text()); if (!d.profile || !d.cycles) throw new Error('format');
        const keep = { auth: S.auth, athlete: S.athlete, cid: S.settings.clientId, sec: S.settings.clientSecret };
        S = Object.assign(structuredClone(DEFAULT_STATE), d); S.auth = keep.auth; S.athlete = keep.athlete || d.athlete;
        S.settings.clientId = S.settings.clientId || keep.cid; S.settings.clientSecret = keep.sec;
        save(); closeSheet(); toast('Data dipulihkan ✓'); go('home');
      } catch { toast('File backup tidak valid'); }
    };
    on('sReset', () => { if (confirm('Hapus semua data Cycling Coach?')) { try { localStorage.removeItem(STORE_KEY); } catch {} location.reload(); } });
  });
}

// ============ NOTIFIKASI ============
const LN = isNative && Cap.Plugins ? Cap.Plugins.LocalNotifications : null;
async function scheduleNotifications() {
  if (!LN || !S.onboarded) return;
  try {
    const perm = await LN.checkPermissions();
    if (perm.display !== 'granted') { const r = await LN.requestPermissions(); if (r.display !== 'granted') return; }
    const pend = await LN.getPending();
    if (pend.notifications.length) await LN.cancel({ notifications: pend.notifications.map((n) => ({ id: n.id })) });
    const [ch, cm] = S.settings.checkinTime.split(':').map(Number), [th, tm] = S.settings.trainTime.split(':').map(Number);
    const list = [{ id: 1, title: '❤️ Check-in kondisi tubuh', body: 'Jawab 5 pertanyaan — latihan hari ini langsung disesuaikan.', schedule: { on: { hour: ch, minute: cm }, allowWhileIdle: true } }];
    for (let i = 0; i < 14; i++) {
      const d = ymd(addDays(new Date(), i)), p = planFor(d); if (!p || p.type === 'REST') continue;
      const at = parseYmd(d); at.setHours(th, tm, 0, 0); if (at <= new Date()) continue;
      list.push({ id: 100 + i, title: `${p.ico} ${p.name}`, body: `${fmtNum(p.dist, 1)} km · ${fmtNum(p.speed, 1)} km/j · ${fmtNum(p.elev)} m · ${p.zone}`, schedule: { at, allowWhileIdle: true } });
    }
    await LN.schedule({ notifications: list });
  } catch (e) { console.warn('notif', e); }
}
async function testNotif() {
  if (!LN) return toast('Notifikasi hanya jalan di versi APK');
  const r = await LN.requestPermissions(); if (r.display !== 'granted') return toast('Izin notifikasi ditolak');
  await LN.schedule({ notifications: [{ id: 99, title: '🚴 Cycling Coach', body: 'Notifikasi aktif! Siap gowes?', schedule: { at: new Date(Date.now() + 4000), allowWhileIdle: true } }] });
  toast('Notifikasi muncul dalam 4 detik');
}

// ============ RENDER & BOOT ============
function applyTheme() { const t = S.settings.theme || 'dark'; if (t === 'auto') delete document.documentElement.dataset.theme; else document.documentElement.dataset.theme = t; }
function updateBrand() {
  const b = $('#brandSub'); if (b) b.innerHTML = S.goal ? `<i></i>Target ${esc(S.goal.date.slice(0, 4))}: ${esc(S.goal.title)}` : 'Program latihan adaptif';
  const pill = $('#syncTop.status-pill'); if (pill) { pill.classList.toggle('on', !!S.auth); $('#stravaState').textContent = S.auth ? 'Terhubung' : 'Hubungkan'; }
}
function render() {
  applyTheme();
  if (!S.onboarded) return;
  updateBrand();
  checkBadges();
  ({ home: renderHome, program: renderProgram, checkin: renderCheckin, record: renderRecord, progress: renderProgress, you: renderYou })[VIEW]();
}
if (!isNative && 'serviceWorker' in navigator && location.protocol === 'https:') navigator.serviceWorker.register('sw.js').catch(() => {});
applyTheme();
// ---------- layar masuk dengan Strava ----------
function showStravaLogin(showApi) {
  const el = $('#login'), st = S.settings, need = true;
  $('#app').classList.add('hidden'); $('#onboarding').classList.add('hidden'); el.classList.remove('hidden');
  el.innerHTML = `<div class="lg-brand"><div class="brand-logo lg-logo"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="15" fill="#FC4C02"/><g><path d="M2 52 L19 30 L27 39 L40 19 L62 52 Z" fill="#000" fill-opacity=".3"/><circle cx="48" cy="13" r="4" fill="#fff"/><g fill="none" stroke="#fff" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="19" cy="44" r="8.5"/><circle cx="45" cy="44" r="8.5"/><path d="M19 44 L27 31 L40 31 L45 44 M27 31 L31.5 44 L40 31 M25 26.5 H30 M40 31 L38.5 25 L43 24.5"/></g></g></svg></div><div><div class="brand-name" style="color:#fff">CYCLING COACH</div><div class="lg-tag">Connect · program latihan adaptif</div></div></div>
    <div class="lg-hero"><h1>Latihan terarah.<br>Data dari Strava.</h1>
    <p>Masuk pakai akun Strava — nama, foto & semua aktivitas lo langsung jadi data program latihan.</p></div>
    <div class="lg-actions">
      ${need ? `<div class="lg-card" style="margin:0 0 4px"><b>Kunci API Strava (sekali saja)</b>
        <div class="small muted" style="margin-top:4px">Dari <b>strava.com/settings/api</b>. Callback Domain: <code>${isNative ? 'localhost' : esc(location.hostname)}</code></div>
        <label class="f">Client ID<input id="lgCid" inputmode="numeric" value="${esc(st.clientId)}"></label>
        <label class="f">Client Secret<input id="lgSec" type="password" value="${esc(st.clientSecret)}"></label></div>` : ''}
      <button class="lg-btn strava-btn" id="lgStrava"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/></svg><span>Masuk dengan Strava</span></button>
      ${need ? '' : '<button class="link" id="lgApi" style="color:rgba(255,255,255,.7);align-self:center">Ubah kunci API</button>'}
      <div class="lg-or"><span>atau</span></div>
      <button class="lg-btn ghost" id="lgGuest">Lanjut tanpa Strava</button>
      ${isNative ? '' : '<a class="link" href="../" style="color:rgba(255,255,255,.7);align-self:center;margin-top:6px;text-decoration:none">← Pilih versi lain</a>'}
      <div class="lg-fine">Data tersimpan di perangkat ini · Powered by Strava</div>
    </div>`;
  $('#lgStrava').onclick = () => {
    if (need) { st.clientId = $('#lgCid').value.trim(); st.clientSecret = $('#lgSec').value.trim(); save(); }
    if (!st.clientId || !st.clientSecret) return toast('Isi Client ID & Client Secret dulu');
    stravaConnect();
  };
  const api = $('#lgApi'); if (api) api.onclick = () => showStravaLogin(true);
  $('#lgGuest').onclick = () => { S.guest = true; save(); el.classList.add('hidden'); startApp(false); };
}

let appStarted = false;
function startApp(returned) {
  $('#login').classList.add('hidden');
  if (!S.onboarded) { startOnboarding(); if (returned) toast('Strava terhubung — lanjut isi profil'); return; }
  $('#onboarding').classList.add('hidden');
  $('#app').classList.remove('hidden');
  go('home');
  if (appStarted) return;
  appStarted = true;
  if (S.auth && S.settings.autoSync && !returned && Date.now() - S.lastSync > 5 * 60000) syncStrava(true);
  setInterval(() => { if (document.visibilityState === 'visible' && S.auth && S.settings.autoSync) syncStrava(true); }, 5 * 60000);
  scheduleNotifications();
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState !== 'visible') return;
    if (homeSel && homeSel < today()) homeSel = today();
    render();
    if (S.auth && S.settings.autoSync && Date.now() - S.lastSync > 5 * 60000) syncStrava(true);
  });
}
(async function boot() {
  const returned = new URLSearchParams(location.search).get('state') === 'cyclingcoach' ? await handleOAuthReturn() : false;
  if (!S.auth && !S.guest && !S.onboarded) { showStravaLogin(); return; }
  startApp(returned);
})();
