/* Cycling Coach Connect — integrasi Strava (OAuth + sinkron aktivitas) */
'use strict';

const STRAVA = 'https://www.strava.com';
const STRAVA_SCOPE = 'read,profile:read_all,activity:read_all';
const redirectUri = () => (isNative ? 'https://localhost/' : location.origin + location.pathname);

function stravaConnect() {
  if (!S.settings.clientId || !S.settings.clientSecret) { toast('Isi Client ID & Secret Strava dulu'); openSettings(); return; }
  if (!isNative && (location.protocol !== 'https:' || (() => { try { return window.self !== window.top; } catch { return true; } })())) {
    toast('Connect Strava hanya bisa dari link Netlify (https://…netlify.app), bukan dari preview'); return;
  }
  if (!isNative && !confirm(`Pastikan "Authorization Callback Domain" di strava.com/settings/api persis:\n\n${location.hostname}\n\nLanjut ke Strava?`)) return;
  const u = new URL(STRAVA + '/oauth/authorize');
  u.search = new URLSearchParams({ client_id: S.settings.clientId, response_type: 'code', redirect_uri: redirectUri(), approval_prompt: 'auto', scope: STRAVA_SCOPE, state: 'cyclingcoach' }).toString();
  location.href = u.toString();
}

async function tokenRequest(params) {
  const q = new URLSearchParams({ client_id: S.settings.clientId, client_secret: S.settings.clientSecret, ...params });
  const r = await fetch(`${STRAVA}/oauth/token?${q}`, { method: 'POST', headers: { Accept: 'application/json' } });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.message || `HTTP ${r.status}`);
  return j;
}

async function handleOAuthReturn() {
  const qs = new URLSearchParams(location.search);
  if (qs.get('state') !== 'cyclingcoach') return false;
  history.replaceState(null, '', location.pathname);
  if (qs.get('error')) { toast('Koneksi Strava dibatalkan'); return false; }
  try {
    const j = await tokenRequest({ code: qs.get('code'), grant_type: 'authorization_code' });
    S.auth = { access_token: j.access_token, refresh_token: j.refresh_token, expires_at: j.expires_at, scope: qs.get('scope') || '' };
    S.athlete = j.athlete || null;
    if (S.demo) { S.demo = false; S.activities = S.activities.filter((a) => a.source === 'local'); }
    if (S.athlete) {
      if (!S.profile.name) S.profile.name = [S.athlete.firstname, S.athlete.lastname].filter(Boolean).join(' ');
      if (S.athlete.weight && !S.weights.length) S.profile.weight = S.athlete.weight;
    }
    save();
    toast(`Terhubung ke Strava sebagai ${S.athlete?.firstname || 'atlet'} ✓`);
    if (!(S.auth.scope || '').includes('activity:read')) toast('Izin "lihat aktivitas" belum dicentang — sinkron akan gagal');
    await syncStrava(false, true);
    return true;
  } catch (e) { toast('Gagal konek Strava: ' + e.message); return false; }
}

async function ensureToken() {
  if (!S.auth) throw new Error('Belum terhubung ke Strava');
  if (S.auth.expires_at * 1000 > Date.now() + 60000) return S.auth.access_token;
  const j = await tokenRequest({ grant_type: 'refresh_token', refresh_token: S.auth.refresh_token });
  Object.assign(S.auth, { access_token: j.access_token, refresh_token: j.refresh_token, expires_at: j.expires_at }); save();
  return S.auth.access_token;
}

async function stravaApi(path, params) {
  const token = await ensureToken();
  const q = params ? '?' + new URLSearchParams(params) : '';
  const r = await fetch(STRAVA + path + q, { headers: { Authorization: `Bearer ${token}`, Accept: 'application/json' } });
  const j = await r.json().catch(() => ({}));
  if (r.status === 401) throw new Error('Akses ditolak — putuskan & hubungkan ulang Strava');
  if (r.status === 429) throw new Error('Limit API Strava tercapai, coba lagi 15 menit lagi');
  if (!r.ok) throw new Error(j.message || `HTTP ${r.status}`);
  return j;
}

const slimActivity = (a) => ({
  id: a.id, source: 'strava', name: a.name, sport_type: a.sport_type || a.type, start_date_local: a.start_date_local,
  distance: a.distance || 0, moving_time: a.moving_time || 0, elapsed_time: a.elapsed_time || 0,
  elev: a.total_elevation_gain || 0, avg_speed: a.average_speed || 0, max_speed: a.max_speed || 0,
  avg_hr: a.average_heartrate || 0, kilojoules: a.kilojoules || 0, poly: a.map?.summary_polyline || '',
  city: a.location_city || '',
});

let syncing = false;
function setSyncUi(on) { const b = $('#syncTop'); if (b) b.classList.toggle('spin', on); }
async function syncStrava(silent = false, full = false) {
  if (!S.auth || syncing) return;
  syncing = true; setSyncUi(true);
  try {
    const params = { per_page: '200' };
    const known = new Set(S.activities.map((a) => a.id));
    const stravaActs = S.activities.filter((a) => a.source === 'strava');
    if (!full && stravaActs.length) {
      const latest = stravaActs.reduce((m, a) => (a.start_date_local > m ? a.start_date_local : m), '');
      params.after = String(Math.floor(new Date(latest.replace('Z', '')).getTime() / 1000) - 86400 * 2);
    }
    let page = 1, added = 0, fresh = [];
    while (page <= 30) {
      const batch = await stravaApi('/api/v3/athlete/activities', { ...params, page: String(page) });
      fresh = fresh.concat(batch);
      if (batch.length < 200) break; page++;
    }
    const map = new Map((full ? S.activities.filter((a) => a.source === 'local') : S.activities).map((a) => [a.id, a]));
    fresh.forEach((a) => { if (!known.has(a.id)) added++; map.set(a.id, slimActivity(a)); });
    S.activities = [...map.values()].sort((a, b) => b.start_date_local.localeCompare(a.start_date_local));
    S.activities.filter((a) => a.source === 'strava').forEach((a, i) => { if (i >= 40) a.poly = ''; });
    S.lastSync = Date.now(); save();
    if (!silent) toast(added ? `${added} aktivitas baru dari Strava ✓` : 'Data Strava sudah terbaru');
  } catch (e) { if (!silent) toast('Sinkron gagal: ' + e.message); }
  finally { syncing = false; setSyncUi(false); render(); }
}

async function stravaDisconnect() {
  try { const t = await ensureToken(); await fetch(`${STRAVA}/oauth/deauthorize?access_token=${t}`, { method: 'POST' }); } catch {}
  S.auth = null; S.athlete = null; S.activities = S.activities.filter((a) => a.source === 'local'); save(); render();
}

const stravaProfileUrl = () => (S.athlete?.id ? `https://www.strava.com/athletes/${S.athlete.id}` : '');
const stravaActivityUrl = (id) => `https://www.strava.com/activities/${id}`;
