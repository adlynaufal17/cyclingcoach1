/* Cycling Coach — ganti emoji jadi ikon garis (SVG) yang konsisten */
'use strict';
const ICON_PATHS = {
  pin: '<path d="M12 21s-7-6.2-7-11.5A7 7 0 0 1 19 9.5C19 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/>',
  bike: '<circle cx="5.5" cy="17" r="3.5"/><circle cx="18.5" cy="17" r="3.5"/><path d="M5.5 17 9 10h6.5l3 7M9 10l3.2 7 3.3-7M8 7h3M15.5 10 14.5 6.5h2.5"/>',
  heart: '<path d="M12 20s-7.5-4.6-9.2-9.3A4.8 4.8 0 0 1 12 6.6a4.8 4.8 0 0 1 9.2 4.1C19.5 15.4 12 20 12 20z"/>',
  moon: '<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/>',
  target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.5"/>',
  dumbbell: '<path d="M6.5 6.5v11M3.5 9v6M17.5 6.5v11M20.5 9v6M6.5 12h11"/>',
  stretch: '<circle cx="12" cy="4.5" r="2"/><path d="M4 10.5c3 1 5.5 1 8 1s5-.1 8-1M12 11.5v4M12 15.5l-4 5M12 15.5l4 5"/>',
  flame: '<path d="M12 21c-3.9 0-6.5-2.6-6.5-6.2 0-3.4 2.3-5.4 3.8-7.3.4 1.6 1.3 2.7 2.4 3.2C11.5 7.4 12.6 4.6 15 3c-.3 2.6.8 4.4 2 6 1.1 1.6 1.5 3.1 1.5 4.8 0 4.4-2.6 7.2-6.5 7.2z"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M12 2.5v3M12 18.5v3M4.6 4.6l2.1 2.1M17.3 17.3l2.1 2.1M2.5 12h3M18.5 12h3M4.6 19.4l2.1-2.1M17.3 6.7l2.1-2.1"/>',
  calendar: '<rect x="3.5" y="5" width="17" height="15.5" rx="2.5"/><path d="M3.5 10h17M8 3v4M16 3v4"/>',
  medal: '<circle cx="12" cy="15" r="5.5"/><path d="M8.5 10.5 6 3h4l2 4.5L14 3h4l-2.5 7.5M12 12.8v4.4"/>',
  zap: '<path d="M13 2.5 4.5 13.5H12l-1 8 8.5-11H12z"/>',
  mountain: '<path d="M2.5 20 9 8.5l3.5 5.5 2.5-3.5 6.5 9.5z"/><path d="M7 12.5l2 1.5 1.5-1"/>',
  pause: '<rect x="6" y="4.5" width="4" height="15" rx="1"/><rect x="14" y="4.5" width="4" height="15" rx="1"/>',
  wrench: '<path d="M14.5 6.5a4 4 0 0 0 5 5l-9 9a2.1 2.1 0 0 1-3-3l9-9a4 4 0 0 0-2-2z"/><path d="M14.5 6.5 17 4"/>',
  trend: '<path d="M3 17 9 11l4 4 8-8"/><path d="M15 7h6v6"/>',
  link: '<path d="M10 13.5a4.5 4.5 0 0 0 6.4.4l3-3a4.5 4.5 0 0 0-6.4-6.4l-1.6 1.6"/><path d="M14 10.5a4.5 4.5 0 0 0-6.4-.4l-3 3a4.5 4.5 0 0 0 6.4 6.4l1.6-1.6"/>',
  map: '<path d="M3 6.5 9 4l6 2.5 6-2.5v13.5L15 20l-6-2.5L3 20z"/><path d="M9 4v13.5M15 6.5V20"/>',
  cloudsun: '<path d="M8 4.5v1.5M3.5 9H5M4.6 5.6l1 1M11.4 5.6l-1 1"/><path d="M5.5 11.5a3 3 0 0 1 5.7-1.3"/><path d="M8.5 20h9a3.5 3.5 0 0 0 .3-7 5 5 0 0 0-9.6 1.2A3 3 0 0 0 8.5 20z"/>',
  file: '<path d="M6 2.5h8.5l4 4V21H6z"/><path d="M14 2.5v4.5h4.5M9 12.5h6M9 16.5h4"/>',
  trophy: '<path d="M7.5 4h9v5a4.5 4.5 0 0 1-9 0z"/><path d="M7.5 6H4.5a3 3 0 0 0 3 4M16.5 6h3a3 3 0 0 1-3 4M12 13.5V17M8.5 20.5h7M9.5 17h5v3.5h-5z"/>',
  lock: '<rect x="4.5" y="10.5" width="15" height="10.5" rx="2.5"/><path d="M8 10.5V7.5a4 4 0 0 1 8 0v3M12 14.5v2.5"/>',
  alert: '<path d="M12 3.5 2.5 20h19z"/><path d="M12 10v4.5M12 17.5v.2"/>',
  rain: '<path d="M7.5 15.5a4 4 0 0 1-.4-8 5.5 5.5 0 0 1 10.6 1.4A3.4 3.4 0 0 1 17 15.5z"/><path d="M8 18.5l-1 2.5M12 18.5l-1 2.5M16 18.5l-1 2.5"/>',
  alarm: '<circle cx="12" cy="13" r="7.5"/><path d="M12 9v4l2.5 2M3.5 5 6 3M20.5 5 18 3"/>',
  bottle: '<path d="M10 2.5h4v3l1.5 2.5V21h-7V8L10 5.5z"/><path d="M8.5 12h7M8.5 16h7"/>',
  run: '<circle cx="14" cy="4.5" r="2"/><path d="M6 12.5l3-3.5 4 1.5 2 3.5 3.5 1M10.5 11 8 16.5l-3.5 1M12.5 13.5l1.5 3.5-1 4"/>',
  walk: '<circle cx="12.5" cy="4.5" r="2"/><path d="M12 7.5l-2.5 6.5 3 2.5V21M9.5 14 8 21M11.5 9.5l3.5 2.5 2 0"/>',
  waves: '<path d="M2.5 9c2 0 2-1.5 4-1.5s2 1.5 4 1.5 2-1.5 4-1.5 2 1.5 4 1.5 2-1.5 3-1.5M2.5 15c2 0 2-1.5 4-1.5s2 1.5 4 1.5 2-1.5 4-1.5 2 1.5 4 1.5 2-1.5 3-1.5"/>',
  leaf: '<path d="M5 19c0-8 5-13.5 15-14-.5 10-6 15-14 15"/><path d="M5 19c3-4 6-6.5 9.5-8.5"/>',
  road: '<path d="M8 3 4 21M16 3l4 18M12 4v2.5M12 10.5v3M12 17.5v3"/>',
  brain: '<path d="M12 5.5a3 3 0 0 0-5.5-1A3 3 0 0 0 4 9a3 3 0 0 0 0 5 3 3 0 0 0 3 4.5 3 3 0 0 0 5 1.5V5.5z"/><path d="M12 5.5a3 3 0 0 1 5.5-1A3 3 0 0 1 20 9a3 3 0 0 1 0 5 3 3 0 0 1-3 4.5 3 3 0 0 1-5 1.5"/>',
  rocket: '<path d="M14.5 3.5c3.5 0 6 2.5 6 6-1.5 3.5-5 6.5-8.5 8L9 14c1.5-3.5 4.5-7 5.5-10.5z"/><path d="M9 14l-3.5.5L4 18l3.5-.5M12 17.5l-.5 3.5 3.5-1.5.5-3.5"/><circle cx="15.5" cy="8.5" r="1.5"/>',
  spark: '<path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5 18 18M18 6l-2.5 2.5M8.5 15.5 6 18"/>',
  face1: '<circle cx="12" cy="12" r="9"/><path d="M8 16.5c1.5-1.5 6.5-1.5 8 0M8.5 9.5l1.5 1M15.5 9.5l-1.5 1"/>',
  face2: '<circle cx="12" cy="12" r="9"/><path d="M8.5 16c1.5-1 5.5-1 7 0M9 10h.01M15 10h.01"/>',
  face3: '<circle cx="12" cy="12" r="9"/><path d="M8.5 15.5h7M9 10h.01M15 10h.01"/>',
  face4: '<circle cx="12" cy="12" r="9"/><path d="M8.5 14.5c1.5 1.5 5.5 1.5 7 0M9 10h.01M15 10h.01"/>',
  face5: '<circle cx="12" cy="12" r="9"/><path d="M7.5 13.5c1.5 3 7.5 3 9 0zM9 9.5h.01M15 9.5h.01"/>',
  face6: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="15.5" r="1.8"/><path d="M9 10h.01M15 10h.01"/>',
  camera: '<path d="M3.5 8h4l1.5-2.5h6L16.5 8h4v11.5h-17z"/><circle cx="12" cy="13.5" r="3.5"/>',
  bell: '<path d="M6 16.5V11a6 6 0 0 1 12 0v5.5l1.5 1.5h-15z"/><path d="M10 20.5a2 2 0 0 0 4 0"/>',
  clip: '<rect x="5" y="4.5" width="14" height="16.5" rx="2"/><path d="M9 3h6v3H9zM8.5 11h7M8.5 15h5"/>',
  bulb: '<path d="M9 17.5h6M10 21h4M12 3a6 6 0 0 0-3.5 10.9c.6.5 1 1.3 1 2.1v1.5h5V16c0-.8.4-1.6 1-2.1A6 6 0 0 0 12 3z"/>',
  dot: '<circle cx="12" cy="12" r="5" fill="currentColor"/>',
  check: '<circle cx="12" cy="12" r="9"/><path d="M8 12.5l2.8 2.8L16.5 9"/>',
  flag: '<path d="M5 21V4M5 4.5h11l-2 4 2 4H5"/>',
  globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 2.5 3.5 5.5 3.5 9s-1 6.5-3.5 9c-2.5-2.5-3.5-5.5-3.5-9S9.5 5.5 12 3z"/>',
  sunrise: '<path d="M4.5 17.5a7.5 7.5 0 0 1 15 0M2.5 20.5h19M12 3v5M9.5 5.5 12 3l2.5 2.5M5.2 10.7l1.4 1.4M18.8 10.7l-1.4 1.4"/>',
  banana: '<path d="M5 6c-1 6 2.5 12.5 9 13.5 2.5.4 4.5-.3 5.5-1.5-6-1-9.5-5-10-11.5z"/><path d="M5 6 4 4"/>',
  wind: '<path d="M3 8.5h11a2.5 2.5 0 1 0-2.5-2.5M3 12.5h15a2.5 2.5 0 1 1-2.5 2.5M3 16.5h7"/>',
  home: '<path d="M3.5 11 12 4l8.5 7v9.5h-6v-6h-5v6h-6z"/>',
  rec: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4.5" fill="currentColor"/>',
  phone: '<rect x="6.5" y="2.5" width="11" height="19" rx="2.5"/><path d="M11 18.5h2"/>',
  trash: '<path d="M4 6.5h16M9.5 6.5V4h5v2.5M6 6.5l1 14h10l1-14M10 10.5v6M14 10.5v6"/>',
  pulse: '<path d="M3 12h4l2-5 4 10 2-5h6"/>',
  save: '<path d="M4.5 3.5h12l3 3v14h-15z"/><path d="M8 3.5v5h7v-5M7.5 20.5v-6h9v6"/>',
  volume: '<path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z"/><path d="M15.5 9a4 4 0 0 1 0 6M18 6.5a7.5 7.5 0 0 1 0 11"/>',
  compass: '<circle cx="12" cy="12" r="9"/><path d="M15.5 8.5l-2 5-5 2 2-5z"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2.5v2.5M12 19v2.5M2.5 12H5M19 12h2.5M5.3 5.3l1.8 1.8M16.9 16.9l1.8 1.8M5.3 18.7l1.8-1.8M16.9 7.1l1.8-1.8"/>',
  cloud: '<path d="M7 18.5a4.5 4.5 0 0 1-.4-9 6 6 0 0 1 11.5 1.6A3.8 3.8 0 0 1 17.5 18.5z"/>',
  fog: '<path d="M3 8.5h18M5 12.5h14M3 16.5h18M7 20.5h10"/>',
  cloudsunrain: '<path d="M7.5 4v1.5M3.5 8H5M4.6 5l1 1"/><path d="M5.5 10.5a3 3 0 0 1 5.5-1.5"/><path d="M8.5 16.5h9a3.3 3.3 0 0 0 .2-6.5 4.8 4.8 0 0 0-9.2 1.2 2.7 2.7 0 0 0 0 5.3z"/><path d="M10 19.5l-.8 2M14 19.5l-.8 2"/>',
  snow: '<path d="M7.5 14.5a4 4 0 0 1-.4-8 5.5 5.5 0 0 1 10.6 1.4A3.4 3.4 0 0 1 17 14.5z"/><path d="M8 18h.01M12 19.5h.01M16 18h.01M10 21.5h.01M14 21.5h.01"/>',
  storm: '<path d="M7.5 14.5a4 4 0 0 1-.4-8 5.5 5.5 0 0 1 10.6 1.4A3.4 3.4 0 0 1 17 14.5h-1.5"/><path d="M12.5 12.5l-3 4.5h4l-2.5 4.5"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2"/>',
  chart: '<path d="M4 20.5V10M10 20.5V4M16 20.5v-7M2.5 20.5h19"/>',
  download: '<path d="M12 3.5v12M7 11l5 5 5-5M4.5 20.5h15"/>',
};
const EMOJI_ICON = {
  '📍': 'pin', '🚴': 'bike', '🚲': 'bike', '❤️': 'heart', '😴': 'moon', '🛌': 'moon', '🎯': 'target', '🏋️': 'dumbbell', '💪': 'dumbbell', '🦾': 'dumbbell',
  '🧘': 'stretch', '🦵': 'stretch', '🔥': 'flame', '⚙️': 'gear', '⚙': 'gear', '📅': 'calendar', '🏅': 'medal', '🥇': 'medal g', '🥈': 'medal s', '🥉': 'medal b',
  '⚡': 'zap', '⛰️': 'mountain', '🏔️': 'mountain', '⏸': 'pause', '🔧': 'wrench', '📈': 'trend', '🔗': 'link', '🗺️': 'map', '🌤️': 'cloudsun', '📄': 'file',
  '🏆': 'trophy', '🔒': 'lock', '⚠️': 'alert', '🌧️': 'rain', '⏰': 'alarm', '🧃': 'bottle', '🏃': 'run', '🚶': 'walk', '🥾': 'walk', '🏊': 'waves', '🌿': 'leaf',
  '🛣️': 'road', '🧠': 'brain', '🚀': 'rocket', '🎉': 'spark', '😫': 'face1', '😕': 'face2', '😐': 'face3', '🙂': 'face4', '😄': 'face5', '😮': 'face6',
  '📸': 'camera', '🔔': 'bell', '📋': 'clip', '💡': 'bulb', '🟢': 'dot', '💯': 'check', '✅': 'check', '🇮🇩': 'flag', '🌏': 'globe', '🌅': 'sunrise',
  '🍌': 'banana', '💨': 'wind', '🏠': 'home', '⏺': 'rec', '📱': 'phone', '🗑️': 'trash', '⚕️': 'pulse', '💾': 'save', '🔊': 'volume', '🧭': 'compass',
  '☀️': 'sun', '☁️': 'cloud', '🌫️': 'fog', '🌦️': 'cloudsunrain', '🌨️': 'snow', '⛈️': 'storm', '🌙': 'moon', '🕒': 'clock', '📊': 'chart', '⬇': 'download', '⬇️': 'download',
};
const EMOJI_RE = /(?:🇮🇩)|(?:[☀-➿⬀-⯿⏩-⏺]|\uD83C[\uDC00-\uDFFF]|\uD83D[\uDC00-\uDFFF]|\uD83E[\uDC00-\uDFFF])️?/g;
const EMOJI_TEST = new RegExp(EMOJI_RE.source, 'g');
function hasEmoji(v) { const m = String(v || '').match(EMOJI_TEST); return !!m && m.some((x) => !EMOJI_KEEP.has(x.replace('\uFE0F', ''))); }
const EMOJI_KEEP = new Set(['✓', '✔', '★', '☆', '❚', '✎', '✕', '✖', '✗']);
function iconSvg(name, cls = '') {
  const [n, tone] = name.split(' ');
  const p = ICON_PATHS[n]; if (!p) return '';
  return `<svg class="ei ${tone ? 'ei-' + tone : ''} ${cls}" viewBox="0 0 24 24" aria-hidden="true">${p}</svg>`;
}
function emojiToIcon(str) {
  return String(str).replace(EMOJI_RE, (m) => { if (EMOJI_KEEP.has(m.replace('\uFE0F', ''))) return m; const k = EMOJI_ICON[m] || EMOJI_ICON[m.replace('️', '')] || EMOJI_ICON[m + '️']; return k ? iconSvg(k) : ''; });
}
const stripEmoji = (s) => String(s || '').replace(EMOJI_RE, (m) => (EMOJI_KEEP.has(m.replace('\uFE0F', '')) ? m : '')).replace(/\s{2,}/g, ' ').trim();
// ganti emoji di DOM (teks node) — dipanggil otomatis lewat MutationObserver
function deEmoji(root) {
  if (!root || root.nodeType === 8) return;
  if (root.nodeType === 3) { swapText(root); return; }
  if (root.closest && root.closest('svg,script,style,textarea,input,option,title')) return;
  const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, { acceptNode: (n) => (hasEmoji(n.nodeValue) && !n.parentElement.closest('svg,script,style,textarea,option,title') ? 1 : 2) });
  const list = []; while (w.nextNode()) list.push(w.currentNode);
  list.forEach(swapText);
}
function swapText(n) {
  const v = n.nodeValue; if (!hasEmoji(v)) return;
  const par = n.parentElement; if (!par || par.closest('svg,script,style,textarea,option,title')) return;
  const span = document.createElement('span'); span.className = 'ei-wrap'; span.style.display = 'contents';
  span.innerHTML = emojiToIcon(v.replace(/[&<>]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' })[c]));
  n.replaceWith(...span.childNodes);
}
// opsi <option> & title tidak bisa berisi SVG → hapus emojinya saja
function deEmojiPlain(root) { (root.querySelectorAll ? root.querySelectorAll('option') : []).forEach((o) => { if (hasEmoji(o.textContent)) { o.textContent = stripEmoji(o.textContent); } }); }
(function () {
  const run = (n) => { try { deEmoji(n); if (n.querySelectorAll) deEmojiPlain(n); } catch (e) {} };
  const start = () => {
    run(document.body);
    new MutationObserver((ms) => ms.forEach((m) => { if (m.type === 'characterData') run(m.target); else m.addedNodes.forEach(run); }))
      .observe(document.body, { childList: true, subtree: true, characterData: true });
  };
  if (document.body) start(); else document.addEventListener('DOMContentLoaded', start);
})();
