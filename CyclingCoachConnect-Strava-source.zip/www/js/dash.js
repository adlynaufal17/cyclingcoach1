/* Cycling Coach — tampilan dashboard (sidebar desktop, banner, kartu sesi, daftar aktivitas, rail kanan) */
'use strict';

const DASH_ICO = {
  medal: '<svg viewBox="0 0 24 24"><circle cx="12" cy="15" r="5"/><path d="M8.5 11 6 3h4l2 5 2-5h4l-2.5 8"/></svg>',
  pdf: '<svg viewBox="0 0 24 24"><path d="M6 3h8l4 4v14H6z"/><path d="M14 3v4h4M9 13h6M9 17h4"/></svg>',
  gear: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M4.2 4.2l2.1 2.1M17.7 17.7l2.1 2.1M2 12h3M19 12h3M4.2 19.8l2.1-2.1M17.7 6.3l2.1-2.1"/></svg>',
  play: '<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z" fill="currentColor" stroke="none"/></svg>',
  prev: '<svg viewBox="0 0 24 24"><path d="M18 6v12L9 12zM6 6v12" fill="currentColor"/></svg>',
  next: '<svg viewBox="0 0 24 24"><path d="M6 6v12l9-6zM18 6v12" fill="currentColor"/></svg>',
  dots: '<svg viewBox="0 0 24 24"><circle cx="12" cy="5" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="12" cy="19" r="1.6"/></svg>',
};

// ---------- banner ilustrasi (gunung + rute + roda) ----------
function dashArtSvg() {
  return `<svg class="dash-art" viewBox="0 0 320 220" aria-hidden="true"><defs>
    <radialGradient id="daG" cx="70%" cy="30%" r="70%"><stop offset="0" stop-color="#fff" stop-opacity=".55"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient></defs>
    <circle cx="240" cy="60" r="90" fill="url(#daG)"/><circle cx="250" cy="52" r="16" fill="#fff" opacity=".9"/>
    <path d="M0 220 L70 120 L110 160 L175 70 L250 170 L290 140 L320 170 V220 Z" fill="#000" opacity=".22"/>
    <path d="M0 220 L90 150 L140 185 L210 120 L320 200 V220 Z" fill="#000" opacity=".25"/>
    <path d="M20 200 C 80 196, 70 150, 130 150 S 190 110, 236 96" fill="none" stroke="#fff" stroke-width="4" stroke-linecap="round" stroke-dasharray="1 11"/>
    <circle cx="20" cy="200" r="7" fill="#fff"/><circle cx="236" cy="96" r="9" fill="#fff"/><circle cx="236" cy="96" r="4" fill="#FC4C02"/></svg>`;
}

// ---------- kartu sesi minggu ini (gaya playlist) ----------
function dashWeekHtml(t, sel) {
  const mon = addDays(parseYmd(t), -((parseYmd(t).getDay() + 6) % 7));
  let h = '';
  for (let i = 0; i < 7; i++) {
    const d = ymd(addDays(mon, i)), p = planFor(d), cm = completionFor(d);
    const done = cm && (cm.acts?.length || cm.manual) && !cm.rest;
    const miss = p && p.type !== 'REST' && d < t && !done;
    const rest = !p || p.type === 'REST';
    h += `<button class="pl ${rest ? 'rest' : ''} ${d === sel ? 'sel' : ''} ${d === t ? 'today' : ''}" data-d="${d}">
      <div class="pl-top"><span>${d === t ? 'Hari ini' : DAY3[parseYmd(d).getDay()] + ' ' + parseYmd(d).getDate()}</span>${done ? '<i class="ok">✓</i>' : miss ? '<i class="miss">!</i>' : ''}</div>
      <div class="pl-ico">${p ? p.ico : '😴'}</div>
      <div class="pl-bot"><div><b>${esc(p ? p.short || p.name : 'Rest')}</b><small>${rest ? 'Pemulihan' : fmtDur(p.dur)}</small></div><span class="pl-play">${DASH_ICO.play}</span></div></button>`;
  }
  return `<div class="section-title">Sesi minggu ini <button class="link" data-go2="program">Lihat semua</button></div><div class="pl-row">${h}</div>`;
}

// ---------- mini rute untuk thumbnail ----------
function miniRoute(poly, s = 48) {
  if (!poly || typeof decodePolyline !== 'function') return '';
  const pts = decodePolyline(poly); if (pts.length < 2) return '';
  const la = pts.map((q) => q[0]), lo = pts.map((q) => q[1]);
  const a0 = Math.min(...la), a1 = Math.max(...la), o0 = Math.min(...lo), o1 = Math.max(...lo);
  const k = Math.cos(((a0 + a1) / 2) * Math.PI / 180), sx = (o1 - o0) * k || 1e-6, sy = a1 - a0 || 1e-6, sc = (s - 12) / Math.max(sx, sy);
  const ox = (s - sx * sc) / 2, oy = (s - sy * sc) / 2;
  const step = Math.max(1, Math.floor(pts.length / 60));
  const d = pts.filter((_, i) => i % step === 0 || i === pts.length - 1).map((q, i) => `${i ? 'L' : 'M'}${(ox + (q[1] - o0) * k * sc).toFixed(1)} ${(oy + (a1 - q[0]) * sc).toFixed(1)}`).join('');
  return `<svg viewBox="0 0 ${s} ${s}"><path d="${d}" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
}

// ---------- daftar aktivitas (gaya trending) ----------
function dashActsHtml(acts) {
  if (!acts.length) return '';
  return `<div class="tr-list">${acts.map((a, i) => {
    const sp = sportOf(a), km = a.distance / 1000, mv = a.moving_time || a.elapsed_time;
    const meta = [km ? `${fmtNum(km, 1)} km` : '', km && !sp.pace ? `${fmtNum(a.avg_speed * 3.6, 1)} km/j` : '', a.elev ? `${fmtNum(a.elev)} m` : ''].filter(Boolean).join(' · ');
    return `<div class="tr" data-act="${a.id}"><span class="tr-n">${pad(i + 1)}</span>
      <div class="tr-th">${miniRoute(a.poly) || `<span>${sp.ico}</span>`}</div>
      <div class="tr-t"><b>${esc(a.name)}</b><small>${sp.ico} ${fmtDateShort(actDate(a))} · ${meta}</small></div>
      <span class="tr-d">${fmtDurSec(mv)}</span><span class="tr-play">${DASH_ICO.play}</span></div>`;
  }).join('')}</div>`;
}

// ---------- rail kanan: rekor + "sesi berikutnya" (gaya now playing) ----------
let dashOff = 0;
function dashNextSession() {
  const t = today();
  for (let i = dashOff; i < dashOff + 14; i++) { const d = ymd(addDays(parseYmd(t), i)), p = adjustedFor(d); if (p && p.type !== 'REST') return { d, p, i }; }
  return null;
}
function dashRailHtml() {
  const rides = S.activities.filter(isRide);
  const top = [...rides].sort((a, b) => b.distance - a.distance).slice(0, 3);
  let h = '<aside class="home-rail">';
  if (top.length) h += `<div class="rail-card"><div class="rail-h">Rekor lo <button class="link" data-go2="progress">Lihat semua</button></div>${top.map((a, i) => `
    <div class="rk" data-act="${a.id}"><div class="rk-ic">${['🥇', '🥈', '🥉'][i]}</div><div class="rk-t"><b>${esc(a.name)}</b><small>${fmtNum(a.distance / 1000, 1)} km · ${fmtNum(a.avg_speed * 3.6, 1)} km/j · ${fmtNum(a.elev)} m</small></div></div>`).join('')}</div>`;
  const n = dashNextSession();
  if (n) {
    const { d, p } = n, bars = Array.from({ length: 34 }, (_, i) => 6 + Math.round(Math.abs(Math.sin(i * 0.7 + p.name.length) * 22 + Math.sin(i * 0.23) * 8)));
    const lbl = d === today() ? 'Hari ini' : d === ymd(addDays(new Date(), 1)) ? 'Besok' : fmtDateShort(d);
    h += `<div class="np"><div class="np-art">${dashArtSvg()}<span class="np-ico">${p.ico}</span></div>
      <div class="np-k">Sesi berikutnya · ${lbl}</div><div class="np-t">${esc(p.name)}</div><div class="np-s">${fmtDur(p.dur)} · ${esc(p.zone || '')} · RPE ${esc(String(p.rpe || ''))}</div>
      <div class="np-wave"><span>0:00</span><div>${bars.map((v, i) => `<i style="height:${v}px;${i < 8 ? 'opacity:1' : ''}"></i>`).join('')}</div><span>${fmtDur(p.dur)}</span></div>
      <div class="np-ctl"><button id="npPrev" aria-label="Sesi sebelumnya">${DASH_ICO.prev}</button><button class="np-go" id="npGo" aria-label="Mulai">${DASH_ICO.play}</button><button id="npNext" aria-label="Sesi berikutnya">${DASH_ICO.next}</button></div></div>`;
  }
  return h + '</aside>';
}
function bindDashHome(el) {
  const n = dashNextSession();
  const g = $('#npGo', el); if (g && n) g.onclick = () => { if ($('#view-record') && $('[data-go="record"]')) go('record'); else openSessionSheet(n.d); };
  const pv = $('#npPrev', el); if (pv) pv.onclick = () => { dashOff = Math.max(0, (n ? n.i : 1) - 1); if (dashOff && !dashPrevExists()) dashOff = 0; renderHome(); };
  const nx = $('#npNext', el); if (nx) nx.onclick = () => { dashOff = (n ? n.i : 0) + 1; renderHome(); };
  $$('.pl', el).forEach((b) => (b.onclick = () => { homeSel = b.dataset.d; renderHome(); }));
}
function dashPrevExists() { return true; }

// ---------- sidebar desktop ----------
function dashSideInit() {
  if ($('#side') || !$('#app')) return;
  const side = document.createElement('aside'); side.id = 'side';
  const logo = $('.brand-logo') ? $('.brand-logo').innerHTML : '';
  const menu = $$('.tabbar button').map((b) => {
    const svg = b.querySelector('svg') ? b.querySelector('svg').outerHTML : '', lbl = b.querySelector('span:last-child')?.textContent || b.dataset.go;
    return `<button class="sd-i" data-go="${b.dataset.go}">${svg}<span>${lbl}</span></button>`;
  }).join('');
  side.innerHTML = `<div class="sd-brand"><div class="sd-logo">${logo}</div><b>CYCLING COACH</b></div>
    <div class="sd-me"><div id="sdAv"></div><div><small>Hai,</small><b id="sdName"></b></div></div>
    <div class="sd-h">Menu</div><nav class="sd-nav">${menu}</nav>
    <div class="sd-h">Lainnya</div><nav class="sd-nav">
      <button class="sd-i" data-sx="badge">${DASH_ICO.medal}<span>Badge & streak</span></button>
      <button class="sd-i" data-sx="pdf">${DASH_ICO.pdf}<span>Laporan PDF</span></button>
      <button class="sd-i" data-sx="set">${DASH_ICO.gear}<span>Setelan</span></button></nav>
    <div class="sd-mini" id="sdMini"></div>`;
  $('#app').prepend(side);
  $$('[data-go]', side).forEach((b) => (b.onclick = () => go(b.dataset.go)));
  $('[data-sx="badge"]', side).onclick = () => go('you');
  $('[data-sx="pdf"]', side).onclick = () => (typeof FX !== 'undefined' && FX.pdf ? FX.pdf() : go('progress'));
  $('[data-sx="set"]', side).onclick = () => openSettings();
}
function dashSync() {
  dashSideInit();
  const side = $('#side'); if (!side) return;
  $$('.sd-nav [data-go]', side).forEach((b) => b.classList.toggle('active', b.dataset.go === VIEW));
  $('#sdAv').innerHTML = avatarHtml(44);
  $('#sdName').textContent = (S.profile.name || 'Pesepeda').split(' ')[0];
  const t = today(), p = adjustedFor(t), mini = $('#sdMini');
  if (p) {
    mini.innerHTML = `<div class="sm-ico">${p.ico}</div><div class="sm-t"><small>Hari ini</small><b>${esc(p.short || p.name)}</b></div><button class="sm-go" aria-label="Detail">${DASH_ICO.play}</button>`;
    mini.querySelector('.sm-go').onclick = () => openSessionSheet(t);
  } else mini.innerHTML = '';
  document.body.classList.add('has-side');
}
