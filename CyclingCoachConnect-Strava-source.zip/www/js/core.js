/* Cycling Coach — core: state, util, training engine, kalkulasi tubuh & kalori */
'use strict';

// ============ STATE ============
const STORE_KEY = 'cyclingcoachconnect.v1';
const DEFAULT_STATE = {
  onboarded: false,
  profile: { name: '', photo: '', age: 30, sex: 'M', weight: 70, height: 170 },
  weights: [],            // [{d:'YYYY-MM-DD', kg}]
  baseline: null,         // {dist, speed, elev, d}
  goal: null,             // {title, date:'YYYY-MM', dist, speed, elev, weight}
  settings: { restDays: 1, longDay: 6, trainTime: '06:00', checkinTime: '05:30', autoSync: true, clientId: '', clientSecret: '' },
  auth: null, athlete: null, lastSync: 0,
  cycles: [],             // [{id, start, cap:{long,speed,elev}, base:{...}, mult, feedback, report}]
  checkins: {},           // {date: {sleep, energy, soreness, stress, motivation, sick, rhr, score, level}}
  manualDone: {},         // {date: true}
  activities: [],         // aktivitas hasil rekam GPS / manual
};

let S = load();
function load() {
  try {
    const raw = JSON.parse(localStorage.getItem(STORE_KEY) || '{}');
    const s = Object.assign(structuredClone(DEFAULT_STATE), raw);
    s.profile = Object.assign({}, DEFAULT_STATE.profile, raw.profile);
    s.settings = Object.assign({}, DEFAULT_STATE.settings, raw.settings);
    return s;
  } catch { return structuredClone(DEFAULT_STATE); }
}
function save() { try { localStorage.setItem(STORE_KEY, JSON.stringify(S)); } catch (e) { console.warn('save', e); } }

// ============ UTIL ============
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const pad = (n) => String(n).padStart(2, '0');
const ymd = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const parseYmd = (s) => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d || 1); };
const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
const daysBetween = (a, b) => Math.round((parseYmd(b) - parseYmd(a)) / 86400000);
const today = () => ymd(new Date());
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const round = (v, s = 1) => Math.round(v / s) * s;
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
const DAY = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
const DAY3 = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'];
const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
const MONL = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
const fmtDate = (s) => { const d = parseYmd(s); return `${d.getDate()} ${MON[d.getMonth()]} ${d.getFullYear()}`; };
const fmtDateShort = (s) => { const d = parseYmd(s); return `${DAY3[d.getDay()]}, ${d.getDate()} ${MON[d.getMonth()]}`; };
const fmtNum = (v, dec = 0) => Number(v || 0).toLocaleString('id-ID', { maximumFractionDigits: dec, minimumFractionDigits: 0 });
const fmtDur = (min) => { min = Math.round(min); const h = Math.floor(min / 60), m = min % 60; return h ? `${h}j ${pad(m)}m` : `${m}m`; };
const fmtDurSec = (s) => fmtDur((s || 0) / 60);

// ============ OLAHRAGA ============
const SPORTS = {
  Ride: { label: 'Sepeda', ico: '🚴', gps: true, pace: false, minSpd: 1.0, maxSpd: 28 },
  Run: { label: 'Lari', ico: '🏃', gps: true, pace: true, minSpd: 0.6, maxSpd: 9 },
  Walk: { label: 'Jalan kaki', ico: '🚶', gps: true, pace: true, minSpd: 0.3, maxSpd: 4 },
  Hike: { label: 'Hiking', ico: '🥾', gps: true, pace: true, minSpd: 0.3, maxSpd: 4 },
  WeightTraining: { label: 'Gym', ico: '🏋️', gps: false, met: 5.0 },
  Yoga: { label: 'Yoga', ico: '🧘', gps: false, met: 2.5 },
  Swim: { label: 'Renang', ico: '🏊', gps: false, met: 7.0 },
  Workout: { label: 'Workout lain', ico: '💪', gps: false, met: 8.0 },
};
const RIDE_TYPES = new Set(['Ride', 'VirtualRide', 'MountainBikeRide', 'GravelRide', 'EBikeRide', 'EMountainBikeRide', 'Velomobile', 'Handcycle']);
const isRide = (a) => RIDE_TYPES.has(a.sport_type);
function sportKey(t) {
  if (RIDE_TYPES.has(t)) return 'Ride';
  if (['Run', 'TrailRun', 'VirtualRun'].includes(t)) return 'Run';
  if (SPORTS[t]) return t;
  if (t === 'Crossfit' || t === 'HighIntensityIntervalTraining') return 'Workout';
  return 'Workout';
}
const sportOf = (a) => SPORTS[sportKey(a.sport_type)];
const fmtPace = (secPerKm) => { if (!isFinite(secPerKm) || secPerKm <= 0 || secPerKm > 5999) return '–:––'; const m = Math.floor(secPerKm / 60), s = Math.round(secPerKm % 60); return `${m}:${pad(s === 60 ? 0 : s)}`; };

// ============ TUBUH ============
function bodyStats(p = S.profile) {
  const h = p.height / 100;
  const bmi = p.weight / (h * h);
  const bmr = 10 * p.weight + 6.25 * p.height - 5 * p.age + (p.sex === 'M' ? 5 : -161); // Mifflin-St Jeor
  const fatPct = clamp(1.2 * bmi + 0.23 * p.age - 10.8 * (p.sex === 'M' ? 1 : 0) - 5.4, 3, 60); // Deurenberg
  const cat = bmi < 18.5 ? 'Kurus' : bmi < 23 ? 'Normal' : bmi < 25 ? 'Berlebih' : 'Obesitas'; // cut-off Asia-Pasifik (WHO)
  const hrMax = S.ftp?.lthr ? Math.round(S.ftp.lthr / 0.9) : Math.round(208 - 0.7 * p.age); // dari tes FTP, atau rumus Tanaka
  const idealLo = 18.5 * h * h, idealHi = 22.9 * h * h;
  return { bmi, bmr, fatPct, fatKg: p.weight * fatPct / 100, cat, hrMax, idealLo, idealHi, tdee: bmr * 1.55 };
}
const hrZone = (lo, hi) => { const m = bodyStats().hrMax; return `${Math.round(m * lo)}–${Math.round(m * hi)} bpm`; };

// ============ KALORI ============
// MET bersepeda (Compendium of Physical Activities) berdasar kecepatan rata-rata
function metForSpeed(v) {
  if (v < 16) return 4.0; if (v < 19) return 6.8; if (v < 22) return 8.0;
  if (v < 25) return 10.0; if (v < 30) return 12.0; return 15.8;
}
// estimasi: kcal flat (MET) + kerja menanjak (m·g·h / efisiensi 24%)
function metRun(v) { if (v < 7) return 6.0; if (v < 8.5) return 8.3; if (v < 10.5) return 9.8; if (v < 12) return 11.0; if (v < 13.5) return 11.8; if (v < 15) return 12.8; return 14.5; }
function calcBurn({ distKm, speed, elev = 0, movingSec, kilojoules, avgHr, sport = 'Ride' }) {
  const w = S.profile.weight || 70;
  const hours = movingSec ? movingSec / 3600 : (speed ? distKm / speed : 0);
  let kcal;
  const climb = ((w + (sport === 'Ride' ? 10 : 0)) * 9.81 * elev) / 4184 / 0.24 * 0.6;
  if (sport === 'Ride' && kilojoules) kcal = kilojoules * 1.0; // power meter: 1 kJ kerja ≈ 1 kcal energi
  else if (sport === 'Ride') kcal = metForSpeed(speed || 15) * w * hours + climb;
  else if (sport === 'Run') kcal = metRun(speed || 9) * w * hours + climb * 0.5;
  else if (sport === 'Walk') kcal = (speed > 5.5 ? 4.3 : 3.5) * w * hours + climb * 0.5;
  else if (sport === 'Hike') kcal = 6.0 * w * hours + climb * 0.5;
  else kcal = (SPORTS[sport]?.met || 6) * w * hours;
  // fraksi energi dari lemak berdasar intensitas
  const hrMax = bodyStats().hrMax;
  let frac;
  if (avgHr) { const p = avgHr / hrMax; frac = p < 0.65 ? 0.55 : p < 0.75 ? 0.45 : p < 0.85 ? 0.3 : 0.15; }
  else if (sport === 'Ride') { const rel = S.baseline ? speed / S.baseline.speed : 1; frac = rel < 0.9 ? 0.5 : rel < 1.0 ? 0.4 : rel < 1.08 ? 0.3 : 0.2; }
  else frac = { Walk: 0.55, Hike: 0.5, Yoga: 0.5, Run: 0.3, Swim: 0.35, WeightTraining: 0.25, Workout: 0.25 }[sport] ?? 0.35;
  const fatG = (kcal * frac) / 9;
  const weightLossKg = kcal / 7700; // ~7.700 kcal ≈ 1 kg jaringan lemak
  return { kcal: Math.round(kcal), fatG: Math.round(fatG), weightLossG: Math.round(weightLossKg * 1000), frac };
}
const burnOfActivity = (a) => calcBurn({ distKm: a.distance / 1000, speed: a.avg_speed * 3.6, elev: a.elev, movingSec: a.moving_time || a.elapsed_time, kilojoules: a.kilojoules, avgHr: a.avg_hr, sport: sportKey(a.sport_type) });

// ============ DATA AKTIVITAS ============
const actDate = (a) => (a.start_date_local || '').slice(0, 10);
const actsOn = (d) => S.activities.filter((a) => actDate(a) === d);
const actsBetween = (a, b) => S.activities.filter((x) => actDate(x) >= a && actDate(x) <= b);
function summarize(list, allSports = false) {
  const rides = allSports ? list : list.filter((a) => isRide(a) && a.distance > 1000);
  const km = rides.reduce((s, a) => s + a.distance, 0) / 1000;
  const sec = rides.reduce((s, a) => s + a.moving_time, 0);
  const elev = rides.reduce((s, a) => s + (a.elev || 0), 0);
  const longest = rides.reduce((m, a) => Math.max(m, a.distance / 1000), 0);
  const maxElev = rides.reduce((m, a) => Math.max(m, a.elev || 0), 0);
  const avgSpeed = sec ? km / (sec / 3600) : 0;
  const valid = rides.filter((a) => a.distance >= 5000);
  const topSpeed = valid.reduce((m, a) => Math.max(m, a.avg_speed * 3.6), 0);
  // kecepatan rata-rata paling sering (modus, bucket 1 km/j) — ride ≥ 10 km
  const hist = {};
  rides.filter((a) => a.distance >= 10000).forEach((a) => { const b = Math.floor(a.avg_speed * 3.6); hist[b] = (hist[b] || 0) + 1; });
  const modeB = Object.entries(hist).sort((a, b) => b[1] - a[1] || b[0] - a[0])[0];
  const modeSpeed = modeB ? +modeB[0] : 0;
  const kcal = rides.reduce((s, a) => s + burnOfActivity(a).kcal, 0);
  const fatG = rides.reduce((s, a) => s + burnOfActivity(a).fatG, 0);
  const bySport = {}; list.forEach((a) => { const k = sportKey(a.sport_type); (bySport[k] = bySport[k] || { n: 0, km: 0, sec: 0 }); bySport[k].n++; bySport[k].km += a.distance / 1000; bySport[k].sec += a.moving_time || a.elapsed_time || 0; });
  return { count: rides.length, km, sec, elev, longest, maxElev, avgSpeed, topSpeed, modeSpeed, modeCount: modeB ? modeB[1] : 0, hist, kcal, fatG, bySport, avgDist: rides.length ? km / rides.length : 0 };
}

// ============ TRAINING ENGINE ============
const SESSION = {
  REST: { name: 'Rest Day', short: 'Rest', ico: '😴', color: 'var(--muted)', desc: 'Pemulihan total, pemijatan ringan & hidrasi.' },
  RECOVERY: { name: 'Active Recovery Ride', short: 'Recovery', ico: '🌿', color: 'var(--sage)', desc: 'Spin ringan cadence 90+ RPM, tanpa target speed.' },
  ENDURANCE: { name: 'Zone 2 Base Endurance', short: 'Endurance', ico: '🚴', color: 'var(--teal)', desc: 'Pengembangan kapasitas paru-paru & mesin aerobik.' },
  INTERVAL: { name: 'VO2max Speed Intervals', short: 'Interval', ico: '⚡', color: 'var(--red)', desc: 'Menaikkan VO2max & kecepatan puncak.' },
  HILL: { name: 'Hill Repeats & Climbs', short: 'Tanjakan', ico: '⛰️', color: 'var(--orange)', desc: 'Latihan daya tahan tanjakan untuk elevasi goal.' },
  TEMPO: { name: 'Tempo & Cadence Intervals', short: 'Tempo', ico: '🔥', color: 'var(--yellowD)', desc: 'Interval kecepatan jelajah & ambang laktat.' },
  LONG: { name: 'Long Distance Simulation', short: 'Long Ride', ico: '🛣️', color: 'var(--lav)', desc: 'Simulasi rute panjang endurance, pacing & nutrisi.' },
};
// minggu 1-4 dalam siklus: build, build, overload, recovery
const WEEK_LOAD = [0.9, 1.0, 1.1, 0.7];
const WEEK_NAME = ['Adaptasi', 'Build', 'Overload', 'Recovery'];

function weekTemplate() {
  const t = { 1: 'REST', 2: 'INTERVAL', 3: 'ENDURANCE', 4: 'HILL', 5: S.settings.restDays >= 2 ? 'REST' : 'RECOVERY', 6: 'LONG', 0: 'TEMPO' };
  if (+S.settings.longDay === 0) { t[0] = 'LONG'; t[6] = 'TEMPO'; }
  return t;
}

// Roadmap jangka panjang: milestone per bulan dari baseline → goal
const MONTHLY_LIMIT = { long: 0.15, speed: 0.04, elev: 0.15 };
function goalDate() { return S.goal ? S.goal.date + '-01' : null; }
function monthsToGoal(from = today()) {
  if (!S.goal) return 0;
  const a = parseYmd(from), b = parseYmd(goalDate());
  return Math.max(1, (b.getFullYear() - a.getFullYear()) * 12 + b.getMonth() - a.getMonth());
}
function capFromBaseline(b) { return { long: b.dist * 1.25, speed: b.speed, elev: Math.max(b.elev * 1.2, 100) }; }
function goalCap() { return { long: Math.min(S.goal.dist, 400), speed: S.goal.speed, elev: S.goal.elev }; }

function buildRoadmap(startCap, from = today(), mult = 1) {
  const N = monthsToGoal(from), g = goalCap();
  const out = [{ m: 0, d: from, ...startCap }];
  let cur = { ...startCap };
  const f = (x) => 1 - Math.pow(1 - x, 1.4); // front-loaded: kemajuan awal lebih cepat
  for (let m = 1; m <= N; m++) {
    const nx = {};
    for (const k of ['long', 'speed', 'elev']) {
      const ideal = startCap[k] + (g[k] - startCap[k]) * f(m / N);
      const lim = cur[k] * (1 + MONTHLY_LIMIT[k] * mult);
      nx[k] = g[k] >= startCap[k] ? Math.min(ideal, lim) : cur[k]; // sudah melampaui goal → pertahankan
    }
    cur = nx;
    const d = parseYmd(from); d.setMonth(d.getMonth() + m);
    out.push({ m, d: ymd(d), ...cur });
  }
  const last = out[out.length - 1];
  const reach = ['long', 'speed', 'elev'].map((k) => (g[k] ? clamp(last[k] / g[k], 0, 1) : 1));
  return { points: out, reachPct: Math.round((reach.reduce((a, b) => a + b, 0) / 3) * 100), months: N };
}

function currentCycle(d = today()) {
  const c = [...S.cycles].reverse().find((x) => x.start <= d);
  return c || S.cycles[0] || null;
}
function newCycle(base, mult = 1, feedback = null, report = null) {
  const startCap = capFromBaseline(base);
  const rm = buildRoadmap(startCap, today(), mult);
  const next = rm.points[1] || rm.points[0];
  // cap bulan ini = titik tengah antara kemampuan sekarang dan milestone bulan depan
  const cap = { long: (startCap.long + next.long) / 2, speed: (startCap.speed + next.speed) / 2, elev: (startCap.elev + next.elev) / 2 };
  const c = { id: uid(), start: today(), base: { ...base }, cap, target: next, mult, feedback, report, roadmapReach: rm.reachPct };
  S.cycles.push(c);
  return c;
}
// hitung ulang program bulan berjalan dari baseline baru (tanggal mulai tetap)
function recalcCycle(c, base) {
  const startCap = capFromBaseline(base);
  const rm = buildRoadmap(startCap, c.start, c.mult || 1);
  const next = rm.points[1] || rm.points[0];
  c.base = { ...base }; c.target = next; c.roadmapReach = rm.reachPct;
  c.cap = { long: (startCap.long + next.long) / 2, speed: (startCap.speed + next.speed) / 2, elev: (startCap.elev + next.elev) / 2 };
}
const cycleEnd = (c) => ymd(addDays(parseYmd(c.start), 27));
const cycleDue = () => { const c = currentCycle(); return c && daysBetween(c.start, today()) >= 28; };

function phaseLabel(d = today()) {
  const m = monthsToGoal(d);
  if (m <= 1) return { name: 'Taper & Peak', desc: 'Volume turun, intensitas dijaga. Fokus segar di hari H.' };
  if (m <= 3) return { name: 'Spesifik', desc: 'Latihan meniru kondisi goal: jarak, speed & elevasi target.' };
  const inYear = m % 12;
  if (inYear >= 9 || inYear === 0) return { name: 'Base', desc: 'Bangun fondasi aerobik: banyak Z2, jam di sadel.' };
  if (inYear >= 5) return { name: 'Build', desc: 'Tambah intensitas: interval, tempo & tanjakan.' };
  return { name: 'Build Lanjut', desc: 'Volume & intensitas naik bertahap, uji kemampuan tiap bulan.' };
}

// Detail sesi untuk tanggal tertentu (sebelum penyesuaian harian)
function planFor(d) {
  const c = currentCycle(d);
  if (!c || d < S.cycles[0].start) return null; // sebelum program dimulai
  const date = parseYmd(d);
  const type = weekTemplate()[date.getDay()];
  const dayIdx = daysBetween(c.start, d);
  const wk = clamp(Math.floor(Math.max(0, dayIdx) / 7), 0, 3);
  const L = WEEK_LOAD[wk];
  const cap = c.cap;
  const hrMax = bodyStats().hrMax;
  const base = { date: d, type, ...SESSION[type], week: wk + 1, weekName: WEEK_NAME[wk], load: L, cycle: c };
  const mk = (dist, speed, elev, extra) => {
    dist = Math.max(0, round(dist, dist > 50 ? 5 : 1)); speed = round(speed, 0.5); elev = round(elev, 10);
    return { ...base, dist, speed, elev, dur: speed ? (dist / speed) * 60 : 0, ...extra };
  };
  switch (type) {
    case 'REST':
      return { ...base, dist: 0, speed: 0, elev: 0, dur: 0, zone: '—', hr: '—', rpe: '—',
        purpose: 'Tubuh jadi lebih kuat saat istirahat, bukan saat latihan. Superkompensasi terjadi hari ini.',
        steps: ['Tidur 7–9 jam', 'Stretching / foam roll 10–15 menit', 'Jalan santai opsional 20–30 menit', 'Cek & rawat sepeda (rantai, tekanan ban)'],
        fuel: 'Makan normal, protein cukup (1,6 g/kg BB), perbanyak sayur & air.' };
    case 'RECOVERY':
      return mk(Math.min(cap.long * 0.3, 30), cap.speed * 0.75, cap.elev * 0.1, {
        zone: 'Z1', hr: `< ${Math.round(hrMax * 0.65)} bpm`, rpe: '2/10',
        purpose: 'Melancarkan aliran darah ke otot kaki tanpa menambah kelelahan.',
        steps: ['Kayuh ringan, cadence tinggi 90–100 rpm', 'Rute datar, hindari tanjakan', 'Boleh ngobrol lancar sepanjang ride', 'Stop kalau kaki masih berat — ganti rest'],
        fuel: 'Air putih cukup. Tidak perlu gel/karbo tambahan.' });
    case 'ENDURANCE':
      return mk(cap.long * 0.55 * L, cap.speed * 0.88, cap.elev * 0.45 * L, {
        zone: 'Z2', hr: hrZone(0.65, 0.75), rpe: '4/10',
        purpose: 'Membangun mesin aerobik & efisiensi pembakaran lemak — fondasi semua goal.',
        steps: ['Pemanasan 10 menit progresif', 'Main set: stabil di Z2, cadence 85–95 rpm', 'Jaga napas lewat hidung sebisanya', 'Pendinginan 10 menit santai'],
        fuel: 'Minum 500–750 ml/jam. Makan 30–45 g karbo/jam jika > 90 menit.' });
    case 'INTERVAL': {
      const reps = [4, 5, 6, 3][wk];
      return mk(cap.long * 0.4 * L, cap.speed * 0.95, cap.elev * 0.25, {
        zone: 'Z5 (interval) · Z2 (sisa)', hr: hrZone(0.9, 0.97), rpe: '8–9/10',
        intervalSpeed: round(cap.speed * 1.18, 0.5),
        purpose: 'Menaikkan VO2max & kecepatan maksimal yang bisa ditahan — kunci naikkan avg speed.',
        steps: ['Pemanasan 15 menit + 3× sprint 10 detik', `Main set: ${reps}× 4 menit @ ${round(cap.speed * 1.18, 0.5)} km/j (Z5)`, 'Recovery 4 menit kayuh ringan di antara repetisi', 'Sisa ride di Z2, pendinginan 10 menit'],
        fuel: 'Makan karbo 2–3 jam sebelum. Bawa 1 bidon + 1 gel.' });
    }
    case 'HILL': {
      const reps = [4, 5, 6, 3][wk];
      return mk(cap.long * 0.45 * L, cap.speed * 0.8, cap.elev * 0.9 * L, {
        zone: 'Z4 (tanjakan)', hr: hrZone(0.84, 0.92), rpe: '7–8/10',
        purpose: 'Menguatkan otot & power menanjak supaya elevasi target terasa lebih ringan.',
        steps: ['Pemanasan 15 menit di jalan datar', `Main set: ${reps}× tanjakan 5–8 menit (Z4), posisi duduk`, 'Turunan = recovery, kayuh ringan', 'Repetisi terakhir boleh berdiri (out of saddle)', 'Pendinginan 10 menit'],
        fuel: 'Minum 750 ml/jam, 40–60 g karbo/jam. Bawa jaket tipis buat turunan.' });
    }
    case 'TEMPO':
      return mk(cap.long * 0.65 * L, cap.speed * 1.02, cap.elev * 0.55 * L, {
        zone: 'Z3–Z4 (sweet spot)', hr: hrZone(0.8, 0.88), rpe: '6–7/10',
        purpose: 'Menaikkan ambang laktat (FTP) — bikin speed tinggi bisa ditahan lebih lama.',
        steps: ['Pemanasan 15 menit', `Main set: 2× 20 menit sweet spot @ ${round(cap.speed * 1.08, 0.5)} km/j`, 'Recovery 5 menit di antara blok', 'Sisa jarak di Z2, pendinginan 10 menit'],
        fuel: 'Minum 750 ml/jam, 45–60 g karbo/jam.' });
    case 'LONG':
      return mk(cap.long * L, cap.speed * 0.92, cap.elev * 1.0 * L, {
        zone: 'Z2 (sebagian Z3)', hr: hrZone(0.65, 0.8), rpe: '5/10',
        purpose: 'Latihan inti: melatih daya tahan, pacing, nutrisi & mental untuk jarak goal.',
        steps: ['Mulai pelan — 30 menit pertama di bawah target speed', 'Jaga Z2, tanjakan boleh Z3', 'Makan tiap 45 menit, minum tiap 15 menit', 'Simulasikan kondisi goal (bawaan, jam start, rute)', '30 menit terakhir: tes negative split'],
        fuel: 'Sarapan karbo 2–3 jam sebelum. 60–90 g karbo/jam, 500–750 ml + elektrolit per jam.' });
  }
}

// ============ PENYESUAIAN HARIAN ============
const CHECKIN_Q = [
  { k: 'sleep', ico: '😴', q: 'Kualitas tidur semalam', lo: 'Buruk', mid: 'Cukup', hi: 'Nyenyak' },
  { k: 'energy', ico: '⚡', q: 'Level energi pagi ini', lo: 'Lemas', mid: 'Biasa', hi: 'Segar' },
  { k: 'soreness', ico: '🦵', q: 'Kondisi otot kaki', lo: 'Pegal parah', mid: 'Sedikit pegal', hi: 'Bugar' },
  { k: 'stress', ico: '🧠', q: 'Pikiran / stres', lo: 'Stres berat', mid: 'Sedang', hi: 'Tenang' },
  { k: 'motivation', ico: '🔥', q: 'Motivasi latihan', lo: 'Malas', mid: 'Lumayan', hi: 'Semangat' },
];
function readiness(ci) {
  if (!ci) return null;
  if (ci.sick) return { score: 0, level: 'SICK', label: 'Sakit', color: 'var(--red)' };
  const w = { sleep: 0.25, energy: 0.25, soreness: 0.25, stress: 0.1, motivation: 0.15 };
  const mx = ci.scale || 5;
  let s = 0; for (const k in w) s += (clamp((ci[k] || 1) - 1, 0, mx - 1) / (mx - 1)) * w[k];
  let score = Math.round(s * 100);
  // denyut istirahat naik > 5 bpm dari rata-rata = tanda kelelahan
  if (ci.rhr) {
    const hist = Object.values(S.checkins).map((x) => x.rhr).filter(Boolean);
    const avg = hist.length ? hist.reduce((a, b) => a + b, 0) / hist.length : ci.rhr;
    if (ci.rhr - avg > 7) score -= 15; else if (ci.rhr - avg > 4) score -= 8;
  }
  score = clamp(score, 0, 100);
  if (score >= 80) return { score, level: 'PRIMA', label: 'Prima', color: 'var(--ok)' };
  if (score >= 65) return { score, level: 'BAIK', label: 'Baik', color: 'var(--sage)' };
  if (score >= 50) return { score, level: 'CUKUP', label: 'Cukup', color: 'var(--yellowD)' };
  if (score >= 35) return { score, level: 'LELAH', label: 'Lelah', color: 'var(--orange)' };
  return { score, level: 'DRAINED', label: 'Sangat lelah', color: 'var(--red)' };
}
// rasio beban akut (7 hari) vs kronis (28 hari) dari aktivitas
function loadRatio(d = today()) {
  const end = parseYmd(d);
  const load = (days) => actsBetween(ymd(addDays(end, -days)), ymd(addDays(end, -1))).reduce((s, a) => s + a.moving_time / 3600 * (1 + (a.elev || 0) / 1000), 0);
  const acute = load(7) / 7, chronic = load(28) / 28;
  return chronic > 0.05 ? acute / chronic : 1;
}

function adjustedFor(d) {
  const p = planFor(d);
  if (!p) return null;
  const ci = S.checkins[d];
  const r = readiness(ci);
  const acwr = d === today() ? loadRatio(d) : 1;
  const out = { ...p, original: p, adjust: null };
  if (p.type === 'REST') return out;
  const scale = (f, note, type) => {
    const t = type ? { ...SESSION[type], type } : {};
    out.dist = round(p.dist * f, 1); out.elev = round(p.elev * f, 10);
    if (type === 'RECOVERY') { out.dist = round(Math.min(p.dist * f, p.cycle.cap.long * 0.3, 30), 1); out.elev = round(p.cycle.cap.elev * 0.1, 10); }
    if (type === 'RECOVERY') { out.speed = round(p.cycle.cap.speed * 0.75, 0.5); out.zone = 'Z1'; out.rpe = '2/10'; out.steps = ['Kayuh ringan cadence 90+ rpm', 'Rute datar, tanpa target speed', 'Berhenti kapan saja kalau terasa berat']; out.hr = `< ${Math.round(bodyStats().hrMax * 0.65)} bpm`; out.intervalSpeed = null; }
    Object.assign(out, t);
    out.dur = out.speed ? (out.dist / out.speed) * 60 : 0;
    out.adjust = note;
  };
  if (r) {
    if (r.level === 'SICK' || r.level === 'DRAINED') {
      Object.assign(out, { ...SESSION.REST, type: 'REST', dist: 0, speed: 0, elev: 0, dur: 0, zone: '—', hr: '—', rpe: '—',
        steps: ['Istirahat total', 'Perbanyak minum & tidur', 'Latihan dilanjut besok kalau kondisi membaik'],
        adjust: r.level === 'SICK' ? 'Lo lagi sakit → latihan diganti REST. Jangan dipaksa.' : `Readiness ${r.score}/100 → tubuh butuh istirahat, sesi diganti REST.` });
    } else if (r.level === 'LELAH') scale(0.5, `Readiness ${r.score}/100 → diganti Recovery Spin ringan (volume −50%).`, 'RECOVERY');
    else if (r.level === 'CUKUP') {
      if (['INTERVAL', 'HILL', 'TEMPO'].includes(p.type)) scale(0.8, `Readiness ${r.score}/100 → intensitas tinggi diganti Endurance Z2, volume −20%.`, 'ENDURANCE');
      else scale(0.8, `Readiness ${r.score}/100 → volume dikurangi 20%.`);
    } else if (r.level === 'PRIMA' && acwr < 1.3) {
      out.dist = round(p.dist * 1.05, 1); out.elev = round(p.elev * 1.05, 10); out.dur = out.speed ? (out.dist / out.speed) * 60 : 0;
      out.adjust = `Readiness ${r.score}/100 — kondisi prima! Boleh tambah 5% volume.`;
    }
  }
  if (!out.adjust && acwr > 1.4 && out.type !== 'REST') {
    scale(0.8, `Beban 7 hari terakhir ${Math.round(acwr * 100)}% dari rata-rata bulanan → volume −20% untuk cegah overtraining.`);
  }
  return out;
}

// cocokkan aktivitas rekaman dengan program di tanggal itu
function completionFor(d) {
  const p = adjustedFor(d);
  const acts = actsOn(d).filter(isRide).sort((a, b) => b.distance - a.distance);
  if (!p) return null;
  if (p.type === 'REST') return { rest: true, acts };
  if (!acts.length) return S.manualDone[d] ? { manual: true, acts } : null;
  const km = acts.reduce((s, a) => s + a.distance, 0) / 1000;
  const elev = acts.reduce((s, a) => s + (a.elev || 0), 0);
  const sec = acts.reduce((s, a) => s + a.moving_time, 0);
  const spd = sec ? km / (sec / 3600) : 0;
  const pct = (a, t) => (t ? clamp(a / t, 0, 1.5) : 1);
  const score = Math.round(((Math.min(pct(km, p.dist), 1.1) + Math.min(pct(spd, p.speed), 1.1) + Math.min(pct(elev, p.elev || 1), 1.1)) / 3) * 100);
  return { acts, km, elev, spd, sec, score: Math.min(score, 100), pDist: pct(km, p.dist), pSpd: pct(spd, p.speed), pElev: pct(elev, p.elev || 1) };
}

// ============ LAPORAN BULANAN ============
function monthlyReport(c = currentCycle()) {
  if (!c) return null;
  const s = c.start, e = ymd(addDays(parseYmd(c.start), 27));
  const ps = ymd(addDays(parseYmd(s), -28)), pe = ymd(addDays(parseYmd(s), -1));
  const cur = summarize(actsBetween(s, e)), prev = summarize(actsBetween(ps, pe));
  // kepatuhan program
  let planned = 0, done = 0;
  const lim = today() < e ? today() : e;
  for (let d = parseYmd(s); ymd(d) <= lim; d = addDays(d, 1)) {
    const k = ymd(d), p = planFor(k);
    if (p && p.type !== 'REST') { planned++; const cm = completionFor(k); if (cm && (cm.acts.length || cm.manual)) done++; }
  }
  const diff = (a, b) => (b ? ((a - b) / b) * 100 : null);
  const items = [];
  const add = (label, a, b, unit, dec = 0) => {
    const dlt = diff(a, b);
    items.push({ label, now: a, prev: b, unit, dec, delta: dlt });
  };
  add('Total jarak', cur.km, prev.km, 'km', 1);
  add('Jumlah ride', cur.count, prev.count, 'x');
  add('Avg speed', cur.avgSpeed, prev.avgSpeed, 'km/j', 1);
  add('Total elevasi', cur.elev, prev.elev, 'm');
  add('Ride terjauh', cur.longest, prev.longest, 'km', 1);
  add('Elevasi terbesar', cur.maxElev, prev.maxElev, 'm');
  add('Kalori terbakar', cur.kcal, prev.kcal, 'kcal');
  const wins = [];
  if (cur.avgSpeed > prev.avgSpeed && prev.avgSpeed) wins.push(`Avg speed naik ${fmtNum(cur.avgSpeed - prev.avgSpeed, 1)} km/j 🚀`);
  if (cur.longest > prev.longest && prev.longest) wins.push(`Ride terjauh bertambah ${fmtNum(cur.longest - prev.longest, 1)} km`);
  if (cur.maxElev > prev.maxElev && prev.maxElev) wins.push(`Tanjakan terbesar naik ${fmtNum(cur.maxElev - prev.maxElev)} m ⛰️`);
  if (cur.km > prev.km && prev.km) wins.push(`Volume bulanan naik ${fmtNum(diff(cur.km, prev.km))}%`);
  if (planned && done / planned >= 0.8) wins.push(`Konsisten! ${Math.round((done / planned) * 100)}% sesi program dijalankan`);
  const w = S.weights.filter((x) => x.d >= ps).sort((a, b) => a.d.localeCompare(b.d));
  if (w.length >= 2 && w[w.length - 1].kg < w[0].kg) wins.push(`Berat badan turun ${fmtNum(w[0].kg - w[w.length - 1].kg, 1)} kg`);
  return { cycle: c, start: s, end: e, cur, prev, items, wins, planned, done, compliance: planned ? done / planned : 0 };
}

// saran nilai baseline baru dari rekaman 28 hari terakhir
function recordedBaselineSuggestion() {
  const s = summarize(actsBetween(ymd(addDays(new Date(), -28)), today()));
  if (!s.count) return null;
  const els = actsBetween(ymd(addDays(new Date(), -28)), today()).filter(isRide).map((a) => a.elev || 0).sort((a, b) => b - a);
  const top = els.slice(0, Math.max(1, Math.ceil(els.length / 4)));
  return { dist: round(s.avgDist, 1), speed: round(s.modeSpeed || s.avgSpeed, 0.5), elev: round(top.reduce((a, b) => a + b, 0) / top.length, 10), count: s.count };
}

// ============ GEO ============
function haversine(a, b) {
  const R = 6371000, toR = Math.PI / 180;
  const dLat = (b[0] - a[0]) * toR, dLng = (b[1] - a[1]) * toR;
  const x = Math.sin(dLat / 2) ** 2 + Math.cos(a[0] * toR) * Math.cos(b[0] * toR) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(x));
}
function encodePolyline(pts) {
  let out = '', pLat = 0, pLng = 0;
  const enc = (v) => { v = v < 0 ? ~(v << 1) : v << 1; let s = ''; while (v >= 0x20) { s += String.fromCharCode((0x20 | (v & 0x1f)) + 63); v >>= 5; } return s + String.fromCharCode(v + 63); };
  for (const p of pts) { const la = Math.round(p[0] * 1e5), ln = Math.round(p[1] * 1e5); out += enc(la - pLat) + enc(ln - pLng); pLat = la; pLng = ln; }
  return out;
}
// Douglas-Peucker: kembalikan index titik yang dipertahankan
function simplifyIdx(pts, tolM) {
  if (pts.length < 3) return pts.map((_, i) => i);
  const keep = new Uint8Array(pts.length); keep[0] = keep[pts.length - 1] = 1;
  const k = Math.cos(pts[0][0] * Math.PI / 180) * 111320, ky = 110540;
  const xy = pts.map((p) => [p[1] * k, p[0] * ky]);
  const stack = [[0, pts.length - 1]];
  while (stack.length) {
    const [a, b] = stack.pop(); let md = 0, mi = -1;
    const [ax, ay] = xy[a], [bx, by] = xy[b], dx = bx - ax, dy = by - ay, L = dx * dx + dy * dy || 1e-9;
    for (let i = a + 1; i < b; i++) {
      const t = clamp(((xy[i][0] - ax) * dx + (xy[i][1] - ay) * dy) / L, 0, 1);
      const d = Math.hypot(xy[i][0] - (ax + t * dx), xy[i][1] - (ay + t * dy));
      if (d > md) { md = d; mi = i; }
    }
    if (md > tolM && mi > 0) { keep[mi] = 1; stack.push([a, mi], [mi, b]); }
  }
  const idx = []; keep.forEach((v, i) => v && idx.push(i)); return idx;
}
