/* Cycling Coach — perekam aktivitas (GPS & timer), GPS & timer */
'use strict';

const REC_KEY = 'cyclingcoachconnect.rec';
let R = null;              // rekaman aktif
let recSport = 'Ride';     // pilihan olahraga di layar awal
let gpsWatch = null, bgWatch = null, wakeLock = null, tickT = null;
let recMap = null, recLine = null, recDot = null, lastFix = null, gpsState = 'idle';

try { R = JSON.parse(localStorage.getItem(REC_KEY) || 'null'); } catch { R = null; }
const spOf = (r) => ({ ...SPORTS[r.sport], gps: SPORTS[r.sport].gps && !r.noGps });
const saveRec = () => { try { R ? localStorage.setItem(REC_KEY, JSON.stringify(R)) : localStorage.removeItem(REC_KEY); } catch {} };

// ---------- waktu ----------
const pausedMs = (r = R, now = Date.now()) => r.pauses.reduce((s, p) => s + ((p.e || now) - p.s), 0);
const elapsedSec = (r = R, now = Date.now()) => Math.max(0, (now - r.startedAt - pausedMs(r, now)) / 1000);
const fmtClock = (sec) => { sec = Math.floor(sec); const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60; return h ? `${h}:${pad(m)}:${pad(s)}` : `${pad(m)}:${pad(s)}`; };
const localIso = (ms) => { const d = new Date(ms); return `${ymd(d)}T${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}Z`; };

// ---------- GPS ----------
async function gpsStart() {
  gpsStop();
  const BG = isNative && Cap.Plugins && Cap.Plugins.BackgroundGeolocation;
  if (BG) {
    try {
      bgWatch = await BG.addWatcher({ backgroundTitle: 'Cycling Coach merekam', backgroundMessage: 'Aktivitas sedang direkam — tap untuk kembali', requestPermissions: true, stale: false, distanceFilter: 2 },
        (loc, err) => {
          if (err) { gpsState = err.code === 'NOT_AUTHORIZED' ? 'denied' : 'error'; updateLive(); if (err.code === 'NOT_AUTHORIZED' && confirm('Izin lokasi ditolak. Buka pengaturan untuk mengizinkan?')) BG.openSettings(); return; }
          onFix({ lat: loc.latitude, lng: loc.longitude, alt: loc.altitude, acc: loc.accuracy, t: loc.time || Date.now() });
        });
      return;
    } catch (e) { console.warn('bg geo', e); }
  }
  if (!navigator.geolocation || !window.isSecureContext) { gpsState = 'unsupported'; return; }
  gpsState = 'searching';
  gpsWatch = navigator.geolocation.watchPosition(
    (p) => onFix({ lat: p.coords.latitude, lng: p.coords.longitude, alt: p.coords.altitude, acc: p.coords.accuracy, t: p.timestamp || Date.now() }),
    (e) => {
      // hanya izin ditolak yang menghentikan GPS; sinyal hilang/timeout sementara tetap ditunggu
      if (e.code === 1) { gpsState = 'denied'; gpsStop(); if (VIEW === 'record' && !R) renderRecord(); return; }
      gpsState = R ? 'weak' : e.code === 2 ? 'off' : 'searching'; updateLive();
      if (!R && e.code === 2 && VIEW === 'record') { gpsStop(); renderRecord(); }
    },
    { enableHighAccuracy: true, maximumAge: 0, timeout: 30000 });
}
function gpsStop() {
  if (gpsWatch != null) { navigator.geolocation.clearWatch(gpsWatch); gpsWatch = null; }
  if (bgWatch != null) { try { Cap.Plugins.BackgroundGeolocation.removeWatcher({ id: bgWatch }); } catch {} bgWatch = null; }
}
async function keepAwake(on) {
  try {
    if (on && 'wakeLock' in navigator && !wakeLock) { wakeLock = await navigator.wakeLock.request('screen'); wakeLock.addEventListener('release', () => (wakeLock = null)); }
    if (!on && wakeLock) { await wakeLock.release(); wakeLock = null; }
  } catch {}
}
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible' && R && R.status === 'rec') keepAwake(true); });

function onFix(f) {
  lastFix = f;
  gpsState = f.acc <= 25 ? 'good' : f.acc <= 50 ? 'weak' : 'poor';
  if (!R || R.status !== 'rec' || !spOf(R).gps) { updateLive(); return; }
  const sp = SPORTS[R.sport];
  const firstFew = R.pts.length < 3;
  if (f.acc > (firstFew ? 40 : 30)) { updateLive(); return; }
  const cur = [f.lat, f.lng, f.alt != null ? Math.round(f.alt * 10) / 10 : null, Math.round((f.t - R.startedAt) / 1000), Math.round(f.acc)];
  const last = R.pts[R.pts.length - 1];
  if (last) {
    const d = haversine(last, cur), dt = cur[3] - last[3];
    if (d < Math.max(3, f.acc * 0.3)) { updateLive(); return; }          // terlalu dekat → noise
    const v = dt > 0 ? d / dt : 999;
    if (v > sp.maxSpd * 1.5) { updateLive(); return; }                   // lompatan GPS
    R.dist += d;
    if (dt > 0 && dt < 30 && v >= sp.minSpd && !R.pauseMark) R.moving += dt;
    if (v > R.maxSpd && dt >= 2) R.maxSpd = v;
    // elevasi dengan histeresis 4 m (GPS altitude berisik)
    if (cur[2] != null) {
      if (R.refAlt == null) R.refAlt = cur[2];
      else if (cur[2] - R.refAlt >= 4) { R.elev += cur[2] - R.refAlt; R.refAlt = cur[2]; }
      else if (R.refAlt - cur[2] >= 4) R.refAlt = cur[2];
    }
  } else if (cur[2] != null) R.refAlt = cur[2];
  R.pauseMark = false;
  R.pts.push(cur);
  if (typeof trackSplits === 'function') trackSplits();
  if (R.pts.length % 5 === 0) saveRec();
  if (recLine) { recLine.addLatLng([cur[0], cur[1]]); }
  updateLive();
}

// ---------- kontrol ----------
async function recStart() {
  const sp = SPORTS[recSport];
  R = { sport: recSport, startedAt: Date.now(), status: 'rec', pauses: [], pts: [], dist: 0, moving: 0, elev: 0, maxSpd: 0, refAlt: null };
  saveRec();
  if (sp.gps) {
    if (isNative && Cap.Plugins?.LocalNotifications) { try { await Cap.Plugins.LocalNotifications.requestPermissions(); } catch {} }
    gpsStart();
  }
  keepAwake(true);
  startTick(); renderRecord(); updateRecPill(); if (typeof speak === 'function') speak('Rekaman dimulai. Selamat latihan!');
}
function recPause() {
  if (!R || R.status !== 'rec') return;
  R.status = 'paused'; R.pauses.push({ s: Date.now() }); R.pauseMark = true; saveRec(); renderRecord(); updateRecPill(); if (typeof speak === 'function') speak('Rekaman dijeda');
}
function recResume() {
  if (!R || R.status !== 'paused') return;
  R.status = 'rec'; const p = R.pauses[R.pauses.length - 1]; if (p && !p.e) p.e = Date.now(); R.pauseMark = true; saveRec();
  keepAwake(true); renderRecord(); updateRecPill(); if (typeof speak === 'function') speak('Lanjut');
}
function recDiscard() {
  gpsStop(); keepAwake(false); stopTick(); R = null; saveRec(); destroyMap(); renderRecord(); updateRecPill();
}
function startTick() { stopTick(); tickT = setInterval(() => { updateLive(); updateRecPill(); }, 1000); }
function stopTick() { if (tickT) clearInterval(tickT); tickT = null; }

// ---------- ringkasan live ----------
function liveStats(r = R) {
  const sp = spOf(r), el = elapsedSec(r);
  const moving = sp.gps ? Math.max(r.moving, 1) : el;
  const km = r.dist / 1000;
  const avgKmh = sp.gps && r.moving > 5 ? km / (r.moving / 3600) : 0;
  // kecepatan sekarang: 20 detik terakhir
  let curKmh = 0;
  if (sp.gps && r.pts.length > 1 && r.status === 'rec') {
    const last = r.pts[r.pts.length - 1], nowRel = (Date.now() - r.startedAt) / 1000;
    if (nowRel - last[3] < 15) {
      let i = r.pts.length - 1, d = 0;
      while (i > 0 && last[3] - r.pts[i - 1][3] <= 20) { d += haversine(r.pts[i - 1], r.pts[i]); i--; }
      const dt = last[3] - r.pts[i][3]; curKmh = dt > 0 ? (d / dt) * 3.6 : 0;
    }
  }
  return { el, moving, km, avgKmh, curKmh, elev: r.elev, maxKmh: r.maxSpd * 3.6 };
}
const spdOrPace = (sp, kmh) => (sp.pace ? { v: fmtPace(kmh > 0.5 ? 3600 / kmh : 0), u: '/km' } : { v: fmtNum(kmh, 1), u: 'km/j' });

function gpsBadge() {
  const m = { idle: ['Menunggu GPS', 'var(--muted)'], searching: ['Mencari GPS…', 'var(--yellowD)'], good: ['GPS bagus', 'var(--teal)'], weak: ['GPS lemah', 'var(--orange)'], poor: ['GPS buruk', 'var(--red)'], denied: ['Izin lokasi ditolak', 'var(--red)'], off: ['GPS HP mati', 'var(--red)'], error: ['GPS error', 'var(--red)'], unsupported: ['GPS tidak didukung', 'var(--red)'] }[gpsState] || ['GPS', 'var(--muted)'];
  return `<span class="gps-badge"><i style="background:${m[1]}"></i>${m[0]}${lastFix && gpsState !== 'denied' ? ` · ±${Math.round(lastFix.acc)} m` : ''}</span>`;
}

function updateLive() {
  if (VIEW !== 'record') return;
  const g = $('#gpsBadgeWrap'); if (g) g.innerHTML = gpsBadge();
  if (!R) return;
  const sp = spOf(R), L = liveStats();
  const set = (id, v) => { const e = $('#' + id); if (e) e.textContent = v; };
  const apOn = S.settings.autoPause !== false && sp.gps;
  set('lvTime', fmtClock(apOn ? Math.min(R.moving, L.el) : L.el));
  set('lvTimeLbl', typeof isAutoPaused === 'function' && isAutoPaused() ? '⏸ Auto-pause' : apOn ? 'Waktu bergerak' : 'Waktu');
  if (sp.gps) {
    set('lvDist', L.km.toFixed(2).replace('.', ','));
    const c = spdOrPace(sp, L.curKmh), a = spdOrPace(sp, L.avgKmh);
    set('lvCur', c.v); set('lvAvg', a.v); set('lvElev', fmtNum(L.elev));
    set('lvMove', fmtClock(Math.min(R.moving, L.el)));
    const tgt = $('#lvTarget');
    if (tgt && tgt.dataset.km) { const pct = clamp(L.km / +tgt.dataset.km, 0, 1); $('#lvTargetBar').style.width = pct * 100 + '%'; set('lvTargetTxt', `${fmtNum(L.km, 1)} / ${fmtNum(+tgt.dataset.km, 1)} km`); }
  }
  const b = burnOfActivity({ distance: R.dist, avg_speed: L.avgKmh / 3.6, elev: R.elev, moving_time: sp.gps ? R.moving : L.el, sport_type: R.sport });
  set('lvKcal', fmtNum(b.kcal));
  if (!recMap && lastFix && $('#recMapSvg') && sp.gps && R.pts.length > 1 && !(R.pts.length % 3)) $('#recMapSvg').innerHTML = polylineSvg(encodePolyline(R.pts), 360, 220);
}

// ---------- peta ----------
function initMap() {
  destroyMap();
  const el = $('#recMap'); if (!el) return;
  if (!window.L) { el.innerHTML = '<div id="recMapSvg" class="map-fallback"></div>'; return; }
  const start = R && R.pts.length ? [R.pts[R.pts.length - 1][0], R.pts[R.pts.length - 1][1]] : lastFix ? [lastFix.lat, lastFix.lng] : [-6.2, 106.816];
  recMap = L.map(el, { zoomControl: false, attributionControl: true }).setView(start, lastFix || (R && R.pts.length) ? 16 : 11);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '© OpenStreetMap' }).addTo(recMap);
  recLine = L.polyline(R ? R.pts.map((p) => [p[0], p[1]]) : [], { color: '#FF4D1F', weight: 5, opacity: 0.9 }).addTo(recMap);
  recDot = L.circleMarker(start, { radius: 8, color: '#fff', weight: 3, fillColor: '#2F80FF', fillOpacity: 1 }).addTo(recMap);
  setTimeout(() => recMap && recMap.invalidateSize(), 200);
}
function destroyMap() { if (recMap) { recMap.remove(); recMap = null; recLine = null; recDot = null; } }
function followMap() {
  if (!recMap || !lastFix) return;
  const ll = [lastFix.lat, lastFix.lng];
  recDot.setLatLng(ll);
  if (!recMap._userMoved) recMap.panTo(ll, { animate: true });
}
setInterval(() => { if (VIEW === 'record') followMap(); }, 2000);

// ---------- layar Rekam ----------
function renderRecord() {
  const el = $('#view-record'); if (!el) return;
  if (VIEW !== 'record') { destroyMap(); return; }
  if (!R) {
    // pra-rekam: pilih olahraga & cari GPS
    const p = adjustedFor(today());
    const sp = SPORTS[recSport];
    if (sp.gps && gpsWatch == null && bgWatch == null && !['denied', 'off', 'unsupported'].includes(gpsState)) gpsStart();
    const gpsBlocked = sp.gps && ['denied', 'off', 'unsupported'].includes(gpsState);
    if (!sp.gps) gpsStop();
    el.innerHTML = `${gpsBlocked ? '' : sp.gps ? '<div id="recMap" class="rec-map"></div>' : `<div class="rec-map rec-timer-hero"><div style="font-size:64px">${sp.ico}</div><div class="mono" style="color:var(--sage)">Mode timer · tanpa GPS</div></div>`}
      <div class="card" style="margin-top:0">
        ${gpsBlocked ? gpsHelpHtml().replace('margin-top:12px', 'margin:0 0 14px') : ''}
        <div class="card-head"><h2>Pilih olahraga</h2><div id="gpsBadgeWrap">${sp.gps ? gpsBadge() : ''}</div></div>
        <div class="sport-grid">${Object.entries(SPORTS).map(([k, s]) => `<button data-sp="${k}" class="${k === recSport ? 'on' : ''}"><span>${s.ico}</span>${s.label}</button>`).join('')}</div>
        ${p && p.type !== 'REST' && recSport === 'Ride' ? `<div class="note" style="margin-top:12px">📋 Program hari ini: <b>${p.ico} ${esc(p.name)}</b> — ${fmtNum(p.dist, 1)} km · ${fmtNum(p.speed, 1)} km/j · ${fmtNum(p.elev)} m</div>` : ''}
        ${sp.gps && !isNative && !gpsBlocked ? '<div class="small muted" style="margin-top:10px">💡 Versi browser: biarkan layar tetap menyala & app terbuka selama merekam. Pakai versi APK supaya tetap merekam saat layar mati.</div>' : ''}
        <button class="rec-start" id="recGo"><span>MULAI</span></button>
        <button class="btn ghost block" id="recManual">+ Catat aktivitas manual</button>
      </div>`;
    $$('[data-sp]', el).forEach((b) => (b.onclick = () => { recSport = b.dataset.sp; renderRecord(); }));
    const rt = $('#gpsRetry'); if (rt) rt.onclick = gpsRetry;
    const tm = $('#gpsTimer'); if (tm) tm.onclick = () => { R = null; recStartTimerOnly(); };
    $('#recGo').onclick = () => {
      if (gpsBlocked) { gpsRetry(); return; }
      if (SPORTS[recSport].gps && !['good', 'weak'].includes(gpsState) && !confirm('Sinyal GPS belum bagus. Tetap mulai? (akurasi awal bisa kurang)')) return;
      recStart();
    };
    $('#recManual').onclick = openManualSheet;
    if (sp.gps && !gpsBlocked) initMap(); else destroyMap();
    return;
  }
  const sp = spOf(R), paused = R.status === 'paused';
  const p = adjustedFor(today());
  const tgtKm = R.sport === 'Ride' && p && p.type !== 'REST' ? p.dist : 0;
  el.innerHTML = `${sp.gps ? '<div id="recMap" class="rec-map"></div>' : `<div class="rec-map rec-timer-hero"><div style="font-size:64px">${sp.ico}</div></div>`}
    <div class="card rec-panel ${paused ? 'paused' : ''}" style="margin-top:0">
      <div class="card-head"><div class="mono ${paused ? '' : 'rec-live'}">${paused ? '⏸ Dijeda' : '● Merekam'} · ${sp.ico} ${sp.label}</div><div id="gpsBadgeWrap">${sp.gps ? gpsBadge() : ''}</div></div>
      <div class="lv-big"><div class="lbl" id="lvTimeLbl">Waktu</div><div id="lvTime" class="val">00:00</div></div>
      ${sp.gps ? `<div class="lv-grid">
        <div><div class="lbl">Jarak</div><div class="val"><span id="lvDist">0,00</span><small>km</small></div></div>
        <div><div class="lbl">${sp.pace ? 'Pace' : 'Speed'}</div><div class="val"><span id="lvCur">0</span><small>${sp.pace ? '/km' : 'km/j'}</small></div></div>
        <div><div class="lbl">Rata-rata</div><div class="val"><span id="lvAvg">0</span><small>${sp.pace ? '/km' : 'km/j'}</small></div></div>
        <div><div class="lbl">Elevasi</div><div class="val"><span id="lvElev">0</span><small>m</small></div></div>
        <div><div class="lbl">Waktu gerak</div><div class="val"><span id="lvMove">00:00</span></div></div>
        <div><div class="lbl">Kalori</div><div class="val"><span id="lvKcal">0</span><small>kcal</small></div></div></div>
        ${tgtKm ? `<div id="lvTarget" data-km="${tgtKm}" style="margin-top:12px"><div class="kv" style="border:0;padding:0 0 4px"><span>Target program</span><b id="lvTargetTxt"></b></div><div class="progress"><div id="lvTargetBar" style="width:0"></div></div></div>` : ''}`
      : `<div class="lv-grid" style="grid-template-columns:1fr"><div><div class="lbl">Kalori (estimasi)</div><div class="val"><span id="lvKcal">0</span><small>kcal</small></div></div></div>`}
      <div class="rec-ctrl">
        ${paused ? '<button class="btn teal" id="recResume">▶ Lanjut</button><button class="btn primary" id="recFinish">■ Selesai</button>' : '<button class="btn primary big" id="recPause">❚❚ Jeda</button>'}
      </div>
    </div>`;
  const on = (id, fn) => { const e = $('#' + id); if (e) e.onclick = fn; };
  on('recPause', recPause); on('recResume', recResume); on('recFinish', openFinishSheet);
  if (sp.gps) { initMap(); if (recMap) recMap.on('dragstart', () => { recMap._userMoved = true; setTimeout(() => recMap && (recMap._userMoved = false), 15000); }); }
  updateLive();
}

// pill merah di top bar saat merekam & berada di tab lain
function updateRecPill() {
  let pill = $('#recPill');
  if (!R) { if (pill) pill.remove(); return; }
  if (!pill) { pill = document.createElement('button'); pill.id = 'recPill'; pill.className = 'rec-pill'; pill.onclick = () => go('record'); $('.topbar').insertBefore(pill, $('.top-actions')); }
  pill.classList.toggle('paused', R.status === 'paused');
  pill.textContent = `${R.status === 'paused' ? '⏸' : '●'} ${fmtClock(elapsedSec())}${spOf(R).gps ? ' · ' + fmtNum(R.dist / 1000, 2) + ' km' : ''}`;
  pill.style.display = VIEW === 'record' ? 'none' : '';
}

// ---------- simpan ----------
function autoName(sport, ms) {
  const h = new Date(ms).getHours();
  const t = h < 11 ? 'Pagi' : h < 15 ? 'Siang' : h < 18 ? 'Sore' : 'Malam';
  return { Ride: `Gowes ${t}`, Run: `Lari ${t}`, Walk: `Jalan ${t}`, Hike: `Hiking ${t}`, WeightTraining: `Gym ${t}`, Yoga: `Yoga ${t}`, Swim: `Renang ${t}`, Workout: `Workout ${t}` }[sport] || `Olahraga ${t}`;
}
function buildGpx(name, sport, startedAt, pts) {
  const trk = pts.map((p) => `<trkpt lat="${p[0].toFixed(6)}" lon="${p[1].toFixed(6)}">${p[2] != null ? `<ele>${p[2]}</ele>` : ''}${p[3] != null ? `<time>${new Date(startedAt + p[3] * 1000).toISOString()}</time>` : ''}</trkpt>`).join('');
  const type = { Ride: 'cycling', Run: 'running', Walk: 'walking', Hike: 'hiking' }[sport] || 'other';
  return `<?xml version="1.0" encoding="UTF-8"?>\n<gpx version="1.1" creator="Cycling Coach" xmlns="http://www.topografix.com/GPX/1/1"><metadata><name>${esc(name)}</name><time>${new Date(startedAt).toISOString()}</time></metadata><trk><name>${esc(name)}</name><type>${type}</type><trkseg>${trk}</trkseg></trk></gpx>`;
}
async function shareOrDownload(filename, text, mime) {
  const blob = new Blob([text], { type: mime });
  try {
    const file = new File([blob], filename, { type: mime });
    if (navigator.canShare && navigator.canShare({ files: [file] })) { await navigator.share({ files: [file], title: filename }); return; }
  } catch (e) { if (e && e.name === 'AbortError') return; }
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = filename; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 3000);
}

function openFinishSheet() {
  if (!R) return;
  if (R.status === 'rec') recPause();
  const sp = spOf(R), L = liveStats();
  if (L.el < 10) { if (confirm('Rekaman terlalu singkat. Buang rekaman ini?')) recDiscard(); return; }
  openSheet(`<div class="sheet-pad"><div class="mono muted">Selesai · ${sp.ico} ${sp.label}</div><h2 class="st">Simpan aktivitas</h2></div>
    ${sp.gps && R.pts.length > 1 ? `<div class="pad">${polylineSvg(encodePolyline(R.pts))}</div>` : ''}
    <div class="card" style="margin-top:12px"><div class="stats">${sp.gps ? statHtml('Jarak', fmtNum(L.km, 2), 'km') : ''}${statHtml('Waktu', fmtClock(sp.gps ? R.moving : L.el))}${sp.gps ? statHtml(sp.pace ? 'Pace' : 'Avg speed', spdOrPace(sp, L.avgKmh).v, spdOrPace(sp, L.avgKmh).u) : statHtml('Kalori', fmtNum(burnOfActivity({ distance: 0, avg_speed: 0, elev: 0, moving_time: L.el, sport_type: R.sport }).kcal), 'kcal')}</div>
    <label class="f">Judul<input id="fnName" value="${esc(autoName(R.sport, R.startedAt))}"></label>
    ${R.noGps && SPORTS[R.sport].gps ? '<label class="f">Jarak (km, opsional)<input id="fnKm" type="number" step="0.1" min="0" placeholder="0"></label>' : ''}
    <label class="f">Catatan<textarea id="fnDesc" rows="2" placeholder="Gimana rasanya? Rute, cuaca, dll."></textarea></label>
    <label class="f">Seberapa berat? (RPE)<select id="fnRpe">${[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((v) => `<option value="${v}" ${v === 5 ? 'selected' : ''}>${v} — ${['Sangat ringan', 'Ringan', 'Ringan', 'Sedang', 'Sedang', 'Agak berat', 'Berat', 'Berat', 'Sangat berat', 'Maksimal'][v - 1]}</option>`).join('')}</select></label>
    <button class="btn primary block" style="margin-top:14px" id="fnSave">Simpan aktivitas</button>
    <div class="btn-row"><button class="btn ghost" id="fnBack">Lanjut rekam</button><button class="btn danger" id="fnDiscard">Buang</button></div></div>`, (root) => {
    $('#fnBack', root).onclick = () => { closeSheet(); recResume(); };
    $('#fnDiscard', root).onclick = () => { if (confirm('Buang rekaman ini? Tidak bisa dikembalikan.')) { closeSheet(); recDiscard(); toast('Rekaman dibuang'); } };
    $('#fnSave', root).onclick = () => {
      const kmIn = $('#fnKm'); if (kmIn && parseFloat(kmIn.value) > 0) R.dist = parseFloat(kmIn.value) * 1000;
      const a = finalizeRecording($('#fnName').value.trim() || autoName(R.sport, R.startedAt), $('#fnDesc').value.trim(), +$('#fnRpe').value);
      closeSheet(); recDiscard();
      toast('Aktivitas tersimpan ✓'); homeSel = today(); go('home'); setTimeout(() => openActivitySheet(a.id), 250);
    };
  });
}

function finalizeRecording(name, desc, rpe) {
  const sp = spOf(R), L = liveStats();
  let poly = '', times = null, alts = null;
  if (sp.gps && R.pts.length > 1) {
    let tol = 3, idx = simplifyIdx(R.pts, tol);
    while (idx.length > 1500) { tol *= 1.6; idx = simplifyIdx(R.pts, tol); }
    const kept = idx.map((i) => R.pts[i]);
    poly = encodePolyline(kept); times = kept.map((p) => p[3]); alts = kept.map((p) => (p[2] != null ? Math.round(p[2]) : null));
  }
  const moving = sp.gps ? Math.round(Math.min(R.moving, L.el)) : Math.round(L.el);
  const a = {
    id: 'l' + R.startedAt, source: 'local', name, sport_type: R.sport, start_date_local: localIso(R.startedAt), started_ms: R.startedAt,
    distance: Math.round(R.dist), moving_time: moving, elapsed_time: Math.round(L.el), elev: Math.round(R.elev),
    avg_speed: moving > 0 ? R.dist / moving : 0, max_speed: Math.max(R.maxSpd, moving > 0 ? R.dist / moving : 0), avg_hr: 0, kilojoules: 0, poly, times, alts, city: '', desc, rpe, splits: (R.splits || []).map((x) => ({ sec: x.sec, elev: x.elev })),
  };
  S.activities.push(a);
  S.activities.sort((x, y) => y.start_date_local.localeCompare(x.start_date_local));
  // hemat storage: detail waktu/elevasi hanya untuk 30 aktivitas lokal terbaru
  S.activities.filter((x) => x.source === 'local' && x.times).slice(30).forEach((x) => { x.times = null; x.alts = null; });
  save();
  return a;
}
function exportActivityGpx(a) {
  if (!a.poly) return toast('Aktivitas ini tidak punya rute GPS');
  const pts = decodePolyline(a.poly).map((p, i) => [p[0], p[1], a.alts?.[i] ?? null, a.times?.[i] ?? null]);
  const start = a.started_ms || new Date(a.start_date_local.replace('Z', '')).getTime();
  shareOrDownload(`${a.name.replace(/[^\w\- ]+/g, '').trim() || 'aktivitas'}.gpx`, buildGpx(a.name, sportKey(a.sport_type), start, pts), 'application/gpx+xml');
}

// ---------- catat manual ----------
function openManualSheet() {
  const now = new Date();
  openSheet(`<div class="sheet-pad"><h2 class="st">Catat aktivitas manual</h2><div class="small muted">Untuk olahraga yang lupa direkam, atau latihan indoor.</div></div>
    <div class="card" style="margin-top:12px">
    <label class="f">Olahraga<select id="mSport">${Object.entries(SPORTS).map(([k, s]) => `<option value="${k}" ${k === recSport ? 'selected' : ''}>${s.ico} ${s.label}</option>`).join('')}</select></label>
    <label class="f">Judul<input id="mName" placeholder="Contoh: Indoor trainer"></label>
    <div class="grid2"><label class="f">Tanggal<input id="mDate" type="date" value="${today()}" max="${today()}"></label><label class="f">Jam mulai<input id="mTime" type="time" value="${pad(now.getHours())}:${pad(now.getMinutes())}"></label></div>
    <div class="grid3"><label class="f">Durasi (mnt)<input id="mDur" type="number" min="1" value="60"></label><label class="f">Jarak (km)<input id="mKm" type="number" step="0.1" min="0" placeholder="0"></label><label class="f">Elevasi (m)<input id="mElev" type="number" min="0" placeholder="0"></label></div>
    <button class="btn primary block" style="margin-top:14px" id="mSave">Simpan</button></div>`, (root) => {
    $('#mSave', root).onclick = () => {
      const sport = $('#mSport').value, dur = parseFloat($('#mDur').value), km = parseFloat($('#mKm').value) || 0, elev = parseFloat($('#mElev').value) || 0;
      if (!(dur > 0)) return toast('Isi durasi');
      const start = new Date(`${$('#mDate').value}T${$('#mTime').value || '06:00'}:00`).getTime();
      const a = { id: 'm' + Date.now(), source: 'local', manual: true, name: $('#mName').value.trim() || autoName(sport, start), sport_type: sport, start_date_local: localIso(start), started_ms: start,
        distance: km * 1000, moving_time: dur * 60, elapsed_time: dur * 60, elev, avg_speed: km ? (km * 1000) / (dur * 60) : 0, max_speed: 0, avg_hr: 0, kilojoules: 0, poly: '', city: '', desc: '' };
      S.activities.push(a); S.activities.sort((x, y) => y.start_date_local.localeCompare(x.start_date_local)); save();
      closeSheet(); toast('Aktivitas dicatat ✓'); go('home');
    };
  });
}

// lanjutkan rekaman yang terputus (reload / app tertutup)
function resumeRecordingOnBoot() {
  if (!R) return;
  if (spOf(R).gps && R.status === 'rec') gpsStart();
  if (R.status === 'rec') keepAwake(true);
  startTick(); updateRecPill();
  toast('Rekaman sebelumnya dilanjutkan');
}

// ---------- bantuan izin lokasi ----------
const inFrame = (() => { try { return window.self !== window.top; } catch { return true; } })();
function gpsHelpHtml() {
  const ua = navigator.userAgent, ios = /iPhone|iPad|iPod/.test(ua);
  let title, steps;
  if (inFrame || !window.isSecureContext) {
    title = 'Halaman ini tidak bisa pakai GPS';
    steps = ['Lo lagi buka versi <b>preview</b> — preview di chat memang memblokir lokasi.', 'Buka lewat <b>link Netlify</b> lo (https://…netlify.app) di Chrome/Safari.', 'Saat muncul pertanyaan izin lokasi, pilih <b>Izinkan</b>.'];
  } else if (gpsState === 'off') {
    title = 'GPS / Lokasi HP sedang mati';
    steps = ['Tarik panel notifikasi HP → nyalakan <b>Lokasi</b>.', 'Kalau di dalam ruangan, pindah ke luar / dekat jendela.', 'Tap <b>Coba lagi</b>.'];
  } else if (isNative) {
    title = 'Izin lokasi ditolak';
    steps = ['Buka <b>Setelan HP → Aplikasi → Cycling Coach → Izin → Lokasi</b>.', 'Pilih <b>Izinkan saat aplikasi digunakan</b> dan aktifkan <b>Lokasi akurat</b>.', 'Pastikan Lokasi HP menyala, lalu tap <b>Coba lagi</b>.'];
  } else if (ios) {
    title = 'Izin lokasi ditolak';
    steps = ['<b>Settings → Privacy & Security → Location Services</b> → ON.', 'Di daftar yang sama: <b>Safari Websites → While Using the App</b>.', '<b>Settings → Apps → Safari → Location → Allow</b>, lalu buka ulang link & tap <b>Coba lagi</b>.'];
  } else {
    title = 'Izin lokasi ditolak';
    steps = ['Di Chrome, tap ikon <b>⚙/🔒 di kiri alamat web</b> → <b>Izin</b> → <b>Lokasi</b> → <b>Izinkan</b>. (Kalau dibuka dari ikon layar utama: buka link yang sama di Chrome dulu.)', 'Cek juga <b>Setelan HP → Aplikasi → Chrome → Izin → Lokasi → Izinkan</b>, dan Lokasi HP menyala.', 'Reload halaman, lalu tap <b>Coba lagi</b>.'];
  }
  return `<div class="note" style="margin-top:12px;background:rgba(216,44,47,.08);border-left:3px solid var(--red)"><b>📍 ${title}</b><ol class="steps" style="margin-top:6px">${steps.map((x) => `<li>${x}</li>`).join('')}</ol>
    <div class="btn-row"><button class="btn teal" id="gpsRetry">Coba lagi</button><button class="btn ghost" id="gpsTimer">Rekam tanpa GPS</button></div></div>`;
}
function gpsRetry() {
  gpsStop(); gpsState = 'idle'; lastFix = null;
  if (!navigator.geolocation || !window.isSecureContext) { gpsState = 'unsupported'; renderRecord(); return; }
  gpsState = 'searching'; renderRecord();
}
// rekam jenis GPS tapi tanpa GPS (hanya timer), dicatat sebagai durasi
function recStartTimerOnly() {
  R = { sport: recSport, noGps: true, startedAt: Date.now(), status: 'rec', pauses: [], pts: [], dist: 0, moving: 0, elev: 0, maxSpd: 0, refAlt: null };
  saveRec(); keepAwake(true); startTick(); renderRecord(); updateRecPill();
  toast('Merekam waktu saja — jarak bisa diisi saat menyimpan');
}
