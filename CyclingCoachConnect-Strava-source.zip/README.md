# Cycling Coach Connect 🚴🔗 — program latihan adaptif + Strava

Versi yang terhubung ke **Strava** (tema oranye terinspirasi Strava). Aktivitas yang lo rekam di app Strava otomatis masuk jadi data program, statistik, kalori & progres.

> Butuh **langganan Strava** untuk bikin API app (aturan Strava sejak Juni 2026). Versi tanpa Strava (rekam GPS sendiri) ada di project **Cycling Coach**.

## Fitur
- Sinkron otomatis aktivitas Strava (tiap app dibuka, kembali aktif & tiap 5 menit) — semua olahraga, statistik bersepeda dari ride
- Goal multi-tahun + roadmap bulanan, evaluasi bulanan, check-in harian yang mengubah porsi latihan
- Program 7 hari berbeda + rest day (target jarak, avg speed, elevasi, zona HR, struktur sesi, nutrisi)
- Kalori, lemak & berat badan, kalkulator tubuh, statistik akumulasi, laporan kemajuan, profil + link Strava
- Catat aktivitas manual, pengingat (APK notifikasi / browser Google Calendar & .ics)

## Setup Strava API
1. strava.com/settings/api → buat app
2. **Authorization Callback Domain**: domain link lo (mis. `cycling-coach-connect.netlify.app`) — untuk APK isi `localhost`
3. Di app: ⚙️ → isi Client ID & Secret → Connect with Strava (login email + password)

## Versi LINK (Netlify)
Extract `cycling-coach-connect-web.zip` → seret foldernya ke app.netlify.com/drop → set callback domain Strava ke domain Netlify-nya.

## Versi APK (GitHub)
Upload isi folder ini (termasuk `.github`) ke repo GitHub → tab Actions → Releases → download APK.

## Fitur tambahan (v2)
Suara pelatih & split per km + auto-pause (rekam GPS) · Badge & streak · Simulasi event (Bentang Jawa) · Tes FTP & kalibrasi zona · Latihan kekuatan/mobilitas dengan timer · Perawatan sepeda · Laporan bulanan PDF · Tur pengguna baru · Pengingat backup · Halaman privasi · Kartu IG Story · Planner nutrisi · Cuaca latihan
