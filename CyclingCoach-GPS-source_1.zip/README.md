# Cycling Coach 🚴 — program latihan adaptif + perekam GPS sendiri

Aplikasi sendiri, tanpa Strava. Tema warna Bentang Jawa 2026, layout ala aplikasi olahraga populer.

## Fitur
- **Rekam aktivitas pakai GPS HP**: sepeda, lari, jalan kaki, hiking — peta rute, jarak, speed/pace, elevasi, waktu gerak, kalori. Mode timer untuk gym, yoga, renang, workout. Catat manual & export GPX
- **Goal multi-tahun** dengan roadmap bulanan sampai tahun target, dihitung ulang tiap bulan
- **Evaluasi bulanan** (tiap 28 hari) dari peningkatan yang dirasakan + data rekaman
- **Check-in harian** → porsi latihan hari itu berubah otomatis
- **Program 7 hari berbeda** + rest day: target jarak, avg speed, elevasi, durasi, zona HR, RPE, struktur sesi, nutrisi
- **Kalori, lemak & berat badan**, kalkulator tubuh (BMI, BMR, % lemak, BB ideal)
- **Statistik akumulasi** (total km, terjauh, elevasi, avg speed tertinggi & tersering), laporan kemajuan bulanan, profil
- **Pengingat**: APK → notifikasi app; browser → Google Calendar / .ics

## Versi LINK (Netlify, paling gampang)
1. Daftar gratis di app.netlify.com
2. Extract `cycling-coach-web.zip` → seret foldernya ke **app.netlify.com/drop**
3. Buka link di HP → izinkan Lokasi → Chrome ⋮ → **Tambahkan ke layar utama**

## Versi APK (GitHub)
1. Repo baru di github.com (Public) → upload semua isi folder ini (termasuk `.github`)
2. Tab **Actions** → tunggu **Build APK** hijau → tab **Releases** → download APK
3. Bonus: workflow **Deploy Web** juga bikin link `USERNAME.github.io/NAMA-REPO` (Settings → Pages → Source: GitHub Actions)

## Rekam GPS: browser vs APK
| | Browser (link) | APK |
|---|---|---|
| Rekam GPS | ✅ selama layar nyala & app terbuka | ✅ tetap jalan saat layar mati |
| Pengingat | Google Calendar / .ics | Notifikasi dari app |

Tips: izinkan **Lokasi**, dan (APK) matikan penghemat baterai untuk Cycling Coach.
Data tersimpan di HP/browser masing-masing — pakai **Backup/Pulihkan** di ⚙️ untuk pindah perangkat.


## Fitur tambahan (v2)
Suara pelatih & split per km + auto-pause (rekam GPS) · Badge & streak · Simulasi event (Bentang Jawa) · Tes FTP & kalibrasi zona · Latihan kekuatan/mobilitas dengan timer · Perawatan sepeda · Laporan bulanan PDF · Tur pengguna baru · Pengingat backup · Halaman privasi · Kartu IG Story · Planner nutrisi · Cuaca latihan
