/* Cycling Coach — fitur tambahan: suara pelatih, split, badge & streak, simulasi event,
   tes FTP, latihan kekuatan, perawatan sepeda, laporan PDF, tur, backup, privasi */
'use strict';

const HAS_REC = typeof recStart === 'function' && !!document.querySelector('[data-go="record"]');
const IS_STRAVA_APP = typeof stravaConnect === 'function';

// ---------- klik terdelegasi: semua tombol baru pakai data-fx ----------
const FX = {};
document.addEventListener('click', (e) => {
  const t = e.target.closest('[data-fx]'); if (!t) return;
  const f = FX[t.dataset.fx]; if (f) { e.preventDefault(); f(t.dataset, t); }
});

// ======================= 4. SUARA PELATIH =======================
function speak(text) {
  if (S.settings.voice === false || !('speechSynthesis' in window)) return;
  try { const u = new SpeechSynthesisUtterance(text); u.lang = 'id-ID'; u.rate = 1.02; speechSynthesis.cancel(); speechSynthesis.speak(u); } catch {}
}
const sayDur = (sec) => { sec = Math.round(sec); const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60; return [h ? `${h} jam` : '', m ? `${m} menit` : '', !h && s ? `${s} detik` : ''].filter(Boolean).join(' ') || '0 detik'; };
const sayNum = (v, d = 1) => fmtNum(v, d).replace(',', ' koma ');
function voiceKm(km) {
  const every = +(S.settings.voiceEvery || 1);
  if (!R || km % every) return;
  const sp = spOf(R), mv = Math.min(R.moving, elapsedSec()), kmh = mv > 5 ? (R.dist / 1000) / (mv / 3600) : 0;
  const last = R.splits[R.splits.length - 1];
  let t = `Kilometer ${km}. Waktu ${sayDur(elapsedSec())}. `;
  t += sp.pace ? `Pace rata-rata ${fmtPace(kmh ? 3600 / kmh : 0).replace(':', ' menit ')} detik per kilometer. ` : `Kecepatan rata-rata ${sayNum(kmh)} kilometer per jam. `;
  if (last && !sp.pace) t += `Kilometer terakhir ${sayNum(3600 / last.sec)} kilometer per jam. `;
  const p = adjustedFor(today());
  if (R.sport === 'Ride' && p && p.type !== 'REST' && p.dist) { const left = p.dist - R.dist / 1000; t += left > 0.2 ? `Sisa target ${sayNum(left)} kilometer.` : 'Target jarak hari ini tercapai. Mantap!'; }
  speak(t);
}
// split per km (dipanggil dari recorder setiap titik GPS diterima)
function trackSplits() {
  if (!R || !spOf(R).gps) return;
  R.splits = R.splits || [];
  const kmNow = Math.floor(R.dist / 1000);
  while (R.splits.length < kmNow) {
    const mv = Math.min(R.moving, elapsedSec()), prev = R.splits.reduce((s, x) => s + x.sec, 0);
    R.splits.push({ sec: Math.max(1, Math.round(mv - prev)), elev: Math.round(R.elev) });
    voiceKm(R.splits.length);
  }
}
const isAutoPaused = () => {
  if (!R || R.status !== 'rec' || !spOf(R).gps || !R.pts.length) return false;
  return (Date.now() - R.startedAt) / 1000 - R.pts[R.pts.length - 1][3] > 12;
};
function splitsHtml(a) {
  if (!a.splits || a.splits.length < 2) return '';
  const sp = sportOf(a), best = Math.min(...a.splits.map((s) => s.sec)), worst = Math.max(...a.splits.map((s) => s.sec));
  return `<div class="card"><h2>Split per km</h2><div class="splits">${a.splits.map((s, i) => {
    const w = 30 + (70 * (worst - s.sec)) / Math.max(1, worst - best);
    return `<div class="split ${s.sec === best ? 'best' : ''}"><span class="k">${i + 1}</span><span class="bar"><i style="width:${w}%"></i></span><b>${sp.pace ? fmtPace(s.sec) + '/km' : fmtNum(3600 / s.sec, 1) + ' km/j'}</b></div>`;
  }).join('')}</div><div class="small muted" style="margin-top:6px">🟢 km tercepat · auto-pause ${S.settings.autoPause === false ? 'mati' : 'aktif'} (waktu berhenti tidak dihitung)</div></div>`;
}

// ======================= 5. BADGE & STREAK =======================
const BADGES = [
  { id: 'first', ico: '🚲', t: 'Gowes Pertama', d: 'Selesaikan ride pertama', ok: (x) => x.rides >= 1 },
  { id: 'd50', ico: '🎯', t: 'Setengah Century', d: '50 km dalam sekali ride', ok: (x) => x.longest >= 50 },
  { id: 'd100', ico: '💯', t: 'Century', d: '100 km dalam sekali ride', ok: (x) => x.longest >= 100 },
  { id: 'd200', ico: '🦾', t: 'Double Century', d: '200 km dalam sekali ride', ok: (x) => x.longest >= 200 },
  { id: 'e1000', ico: '⛰️', t: 'Raja Tanjakan', d: '1.000 m elevasi sekali ride', ok: (x) => x.maxElev >= 1000 },
  { id: 'everest', ico: '🏔️', t: 'Everest', d: 'Total elevasi 8.849 m', ok: (x) => x.elev >= 8849 },
  { id: 'k1000', ico: '🔥', t: '1.000 km', d: 'Total jarak 1.000 km', ok: (x) => x.km >= 1000 },
  { id: 'k1500', ico: '🇮🇩', t: 'Satu Bentang Jawa', d: 'Total 1.500 km — setara Carita–Banyuwangi', ok: (x) => x.km >= 1500 },
  { id: 'k5000', ico: '🌏', t: '5.000 km', d: 'Total jarak 5.000 km', ok: (x) => x.km >= 5000 },
  { id: 'spd30', ico: '⚡', t: 'Speedster', d: 'Avg speed ≥ 30 km/j (≥ 20 km)', ok: (x) => x.fast30 },
  { id: 'early', ico: '🌅', t: 'Early Bird', d: '10 ride mulai sebelum jam 06:00', ok: (x) => x.early >= 10 },
  { id: 'wk4', ico: '📅', t: 'Konsisten 4 Minggu', d: '4 minggu berturut-turut ada ride', ok: (x) => x.weekStreak >= 4 },
  { id: 'wk12', ico: '🏆', t: 'Konsisten 12 Minggu', d: '12 minggu berturut-turut ada ride', ok: (x) => x.weekStreak >= 12 },
  { id: 'ci7', ico: '❤️', t: 'Kenal Tubuh', d: 'Check-in 7 hari berturut-turut', ok: (x) => x.ciStreak >= 7 },
  { id: 'multi', ico: '🏅', t: 'Multi Sport', d: 'Coba 3 jenis olahraga berbeda', ok: (x) => x.sports >= 3 },
];
function streakInfo() {
  const rides = S.activities.filter(isRide);
  const weekKey = (d) => ymd(addDays(parseYmd(d), -((parseYmd(d).getDay() + 6) % 7)));
  const weeks = new Set(rides.map((a) => weekKey(actDate(a))));
  let ws = 0, cur = weekKey(today());
  if (!weeks.has(cur)) cur = ymd(addDays(parseYmd(cur), -7));
  while (weeks.has(cur)) { ws++; cur = ymd(addDays(parseYmd(cur), -7)); }
  let cs = 0, d = today();
  if (!S.checkins[d]) d = ymd(addDays(parseYmd(d), -1));
  while (S.checkins[d]) { cs++; d = ymd(addDays(parseYmd(d), -1)); }
  return { weekStreak: ws, ciStreak: cs, thisWeek: weeks.has(weekKey(today())) };
}
function badgeStats() {
  const s = summarize(S.activities), st = streakInfo();
  const rides = S.activities.filter(isRide);
  return { rides: s.count, longest: s.longest, maxElev: s.maxElev, elev: s.elev, km: s.km,
    fast30: rides.some((a) => a.distance >= 20000 && a.avg_speed * 3.6 >= 30),
    early: S.activities.filter((a) => (a.start_date_local || '').slice(11, 13) < '06').length,
    sports: new Set(S.activities.map((a) => sportKey(a.sport_type))).size, ...st };
}
let badgeSig = '';
function checkBadges() {
  const sig = `${S.activities.length}|${Object.keys(S.checkins).length}`;
  if (sig === badgeSig) return; badgeSig = sig;
  S.badges = S.badges || {};
  const x = badgeStats(), fresh = [];
  BADGES.forEach((b) => { if (!S.badges[b.id] && b.ok(x)) { S.badges[b.id] = today(); fresh.push(b); } });
  if (fresh.length) {
    save();
    if (!S.demo && S.onboarded) setTimeout(() => toast(`🏅 Badge baru: ${fresh.map((b) => b.t).join(', ')}`), 700);
  }
}
function badgesHtml(limit) {
  S.badges = S.badges || {};
  const got = BADGES.filter((b) => S.badges[b.id]).length, st = streakInfo();
  const list = limit ? [...BADGES].sort((a, b) => !!S.badges[b.id] - !!S.badges[a.id]).slice(0, limit) : BADGES;
  return `<div class="card"><div class="card-head"><div><div class="mono muted">Badge & streak</div><h2>${got}/${BADGES.length} badge terkumpul</h2></div>${limit ? '<button class="link" data-fx="badges">Semua ›</button>' : ''}</div>
    <div class="sbox-row" style="margin-bottom:12px"><div class="sbox"><div class="l">Streak minggu</div><div class="v">🔥 ${st.weekStreak}</div></div><div class="sbox spd"><div class="l">Check-in beruntun</div><div class="v">❤️ ${st.ciStreak}</div></div><div class="sbox elv"><div class="l">Minggu ini</div><div class="v">${st.thisWeek ? '✓ Aman' : 'Belum ride'}</div></div></div>
    <div class="badge-grid">${list.map((b) => `<div class="badge ${S.badges[b.id] ? 'on' : ''}" title="${esc(b.d)}"><div class="ico">${b.ico}</div><div class="t">${b.t}</div><div class="d">${S.badges[b.id] ? fmtDateShort(S.badges[b.id]) : esc(b.d)}</div></div>`).join('')}</div></div>`;
}
FX.badges = () => openSheet(`<div class="sheet-pad"><h2 class="st">Badge & Streak</h2></div><div style="height:10px"></div>${badgesHtml(0)}`);

// ======================= 6. SIMULASI EVENT (Bentang Jawa) =======================
function simCalc(o) {
  const v = o.speed, rideH = o.rideH, sleepH = o.sleepH, stopF = o.stops / 100;
  const dayKm = v * rideH * (1 - stopF);
  const days = [];
  let left = o.km, t = 0, cum = 0, n = 0;
  while (left > 0.01 && n < 30) {
    n++;
    const km = Math.min(left, dayKm), hours = km / (v * (1 - stopF));
    cum += km; left -= km; t += hours + (left > 0.01 ? Math.max(0, 24 - rideH - sleepH) + sleepH : 0);
    days.push({ n, km, cum, elev: (o.elev * km) / o.km, hours });
  }
  const totalH = days.reduce((s, d, i) => s + d.hours + (i < days.length - 1 ? 24 - d.hours : 0), 0);
  const needSpeed = o.km / (o.limit * (rideH / 24) * (1 - stopF));
  const kcalDay = calcBurn({ distKm: dayKm, speed: v, elev: o.elev / Math.max(1, days.length), sport: 'Ride' }).kcal;
  return { days, totalH, ok: totalH <= o.limit, needSpeed, dayKm, kcalDay };
}
FX.sim = () => {
  const c = currentCycle(), g = S.goal || {};
  const ultra = (g.title || '').toLowerCase().includes('bentang') || g.dist >= 300;
  const o = { km: ultra ? 1500 : g.dist || 200, elev: ultra ? 16000 : g.elev || 2000, limit: ultra ? 156 : Math.max(6, Math.round(((g.dist || 200) / (g.speed || 25)) * 1.5)),
    speed: round((c ? c.cap.speed : 24) * (ultra ? 0.8 : 0.95), 0.5), rideH: ultra ? 16 : 24, sleepH: ultra ? 4 : 0, stops: ultra ? 12 : 8 };
  const draw = (root) => {
    const r = simCalc(o);
    $('#simOut', root).innerHTML = `<div class="note ${r.ok ? '' : 'y'}" style="margin-top:0">${r.ok ? '✅' : '⚠️'} Estimasi finish <b>${fmtNum(r.totalH, 0)} jam</b> (${fmtNum(r.totalH / 24, 1)} hari) dari batas ${o.limit} jam. ${r.ok ? `Sisa buffer ${fmtNum(o.limit - r.totalH, 0)} jam.` : `Butuh moving speed ± <b>${fmtNum(r.needSpeed, 1)} km/j</b> dengan pola ini, atau kurangi tidur/berhenti.`}</div>
      <div class="sbox-row" style="margin-top:10px"><div class="sbox"><div class="l">Km / hari</div><div class="v">${fmtNum(r.dayKm)}</div></div><div class="sbox spd"><div class="l">Kalori / hari</div><div class="v">${fmtNum(r.kcalDay)}</div></div><div class="sbox elv"><div class="l">Elevasi / hari</div><div class="v">${fmtNum(o.elev / r.days.length)} m</div></div></div>
      <div class="sim-days">${r.days.map((d) => `<div class="kv"><span>Hari ${d.n}</span><b>${fmtNum(d.km)} km · ${fmtNum(d.elev)} m · ${fmtDur(d.hours * 60)} gowes · km ${fmtNum(d.cum)}</b></div>`).join('')}</div>
      <div class="note">🛌 Strategi tidur: ${o.sleepH ? `${o.sleepH} jam/malam, idealnya 1 blok tidur + power nap 20 menit siang.` : 'nonstop — siapkan power nap 15–20 menit tiap 8–10 jam.'}<br>🍌 Makan ${fmtNum(r.kcalDay)} kcal/hari ≈ ${fmtNum(r.kcalDay / 250)} porsi nasi — mayoritas di atas sepeda.<br>🎯 Latihan: long ride target ${fmtNum(Math.min(r.dayKm * 0.8, 400))} km + back-to-back weekend di fase Spesifik.</div>`;
  };
  openSheet(`<div class="sheet-pad"><div class="mono muted">Simulasi event</div><h2 class="st">${esc(ultra ? 'Bentang Jawa' : g.title || 'Event')}</h2><div class="small muted">Atur asumsi — hasil langsung dihitung dari kemampuan lo sekarang.</div></div>
    <div class="card" style="margin-top:12px"><div class="grid3">
      <label class="f">Jarak (km)<input data-k="km" type="number" value="${o.km}"></label><label class="f">Elevasi (m)<input data-k="elev" type="number" value="${o.elev}"></label><label class="f">Batas (jam)<input data-k="limit" type="number" value="${o.limit}"></label>
      <label class="f">Speed (km/j)<input data-k="speed" type="number" step="0.5" value="${o.speed}"></label><label class="f">Gowes/hari (j)<input data-k="rideH" type="number" value="${o.rideH}"></label><label class="f">Tidur/hari (j)<input data-k="sleepH" type="number" value="${o.sleepH}"></label></div>
      <label class="f">Waktu berhenti (makan, isi air, CP) — ${o.stops}%<input data-k="stops" type="range" min="0" max="30" value="${o.stops}" class="ci-range" style="--p:${(o.stops / 30) * 100}%"></label>
      <div class="small muted">Speed default = 80% kapasitas avg speed lo bulan ini (efek lelah di ultra).</div></div>
    <div class="card" id="simOut"></div>`, (root) => {
    $$('[data-k]', root).forEach((inp) => (inp.oninput = () => { o[inp.dataset.k] = parseFloat(inp.value) || 0; if (inp.dataset.k === 'stops') { inp.style.setProperty('--p', `${(o.stops / 30) * 100}%`); inp.parentElement.firstChild.textContent = `Waktu berhenti (makan, isi air, CP) — ${o.stops}%`; } if (o.speed > 5 && o.km > 0 && o.rideH > 0) draw(root); }));
    draw(root);
  });
};

// ======================= 7. TES FTP / ZONA =======================
const ftpDue = () => !S.ftp || daysBetween(S.ftp.d, today()) >= 49;
FX.ftp = () => {
  const f = S.ftp;
  openSheet(`<div class="sheet-pad"><div class="mono muted">Kalibrasi zona</div><h2 class="st">Tes FTP 20 menit</h2><div class="small muted">Ulangi tiap 6–8 minggu supaya target speed & zona detak jantung tetap akurat.</div></div>
    <div class="card" style="margin-top:12px"><h2>Protokol</h2><ol class="steps">
      <li>Pemanasan 15 menit progresif + 3× sprint 1 menit (istirahat 1 menit)</li><li>Kayuh santai 5 menit</li>
      <li><b>20 menit usaha maksimal yang bisa lo tahan rata</b> — rute datar/tanjakan konsisten, tanpa lampu merah</li>
      <li>Pendinginan 10–15 menit</li><li>Catat avg HR, avg speed (dan avg power kalau ada) selama 20 menit itu</li></ol></div>
    <div class="card"><h2>Hasil tes</h2><div class="grid3">
      <label class="f">Avg HR<input id="ftHr" type="number" placeholder="bpm" value="${f?.hr || ''}"></label>
      <label class="f">Avg speed<input id="ftSp" type="number" step="0.1" placeholder="km/j" value="${f?.speed || ''}"></label>
      <label class="f">Avg power<input id="ftPw" type="number" placeholder="watt (ops.)" value="${f?.power || ''}"></label></div>
      <button class="btn primary block" style="margin-top:14px" id="ftSave">Simpan & kalibrasi zona</button>
      ${f ? `<div class="note">Tes terakhir ${fmtDate(f.d)} · LTHR <b>${f.lthr} bpm</b>${f.ftp ? ` · FTP <b>${f.ftp} W</b> (${fmtNum(f.ftp / S.profile.weight, 1)} W/kg)` : ''} · threshold speed <b>${fmtNum(f.tspeed, 1)} km/j</b></div>${ftpZonesHtml(f)}` : ''}</div>`, (root) => {
    $('#ftSave', root).onclick = () => {
      const hr = +$('#ftHr').value, sp = +$('#ftSp').value, pw = +$('#ftPw').value;
      if (!(hr > 90) || !(sp > 5)) return toast('Isi minimal avg HR & avg speed');
      S.ftp = { d: today(), hr, speed: sp, power: pw || 0, lthr: Math.round(hr * 0.95), tspeed: sp * 0.95, ftp: pw ? Math.round(pw * 0.95) : 0 };
      save(); closeSheet(); render(); toast(`Zona dikalibrasi — LTHR ${S.ftp.lthr} bpm`);
      setTimeout(FX.ftp, 300);
    };
  });
};
function ftpZonesHtml(f) {
  const Z = [['Z1 Recovery', 0, 0.81, 0, 0.55], ['Z2 Endurance', 0.81, 0.89, 0.56, 0.75], ['Z3 Tempo', 0.9, 0.93, 0.76, 0.9], ['Z4 Threshold', 0.94, 0.99, 0.91, 1.05], ['Z5 VO2max', 1, 1.06, 1.06, 1.2]];
  return `<div class="section-title" style="padding:12px 0 4px">Zona latihan lo</div>${Z.map(([n, a, b, pa, pb]) => kv(n, `${a ? Math.round(f.lthr * a) : '<'}${a ? '–' : ''}${Math.round(f.lthr * b)} bpm${f.ftp ? ` · ${Math.round(f.ftp * pa)}–${Math.round(f.ftp * pb)} W` : ''}`)).join('')}`;
}

// ======================= 8. LATIHAN KEKUATAN & MOBILITAS =======================
const ROUTINES = {
  strength: { t: 'Kekuatan core & kaki', ico: '🏋️', ex: [['Squat', 45], ['Glute bridge', 45], ['Plank', 40], ['Reverse lunge', 45], ['Side plank kiri', 30], ['Side plank kanan', 30], ['Bird-dog', 45], ['Calf raise', 45], ['Dead bug', 45], ['Wall sit', 40]], rounds: 2, rest: 15 },
  mobility: { t: 'Mobilitas & stretching', ico: '🧘', ex: [['Cat-cow', 45], ['Hip flexor stretch kiri', 45], ['Hip flexor stretch kanan', 45], ['Hamstring stretch', 60], ['Pigeon pose kiri', 45], ['Pigeon pose kanan', 45], ['Quad stretch', 45], ['Thoracic rotation', 45], ['Child pose', 60]], rounds: 1, rest: 10 },
};
function strengthCardHtml(p) {
  if (!p || !['REST', 'RECOVERY'].includes(p.type)) return '';
  const k = p.type === 'REST' && parseYmd(p.date).getDay() === 1 ? 'strength' : 'mobility', r = ROUTINES[k];
  const mins = Math.round((r.ex.reduce((s, e) => s + e[1] + r.rest, 0) * r.rounds) / 60);
  return `<div class="card"><div class="card-head"><h2>${r.ico} ${r.t}</h2><span class="chip">${mins} menit</span></div>
    <div class="small muted">Rest day aktif — bikin otot stabil & mencegah cedera di ride panjang.</div>
    <div class="chips">${r.ex.map((e) => `<span class="chip">${e[0]} · ${e[1]}s</span>`).join('')}</div>
    <div class="btn-row"><button class="btn primary" data-fx="routine" data-r="${k}">▶ Mulai dengan timer</button><button class="btn ghost" data-fx="routine" data-r="${k === 'strength' ? 'mobility' : 'strength'}">${k === 'strength' ? '🧘 Mobilitas' : '🏋️ Kekuatan'}</button></div></div>`;
}
let rtT = null;
function beep(f = 880, ms = 160) { try { const ac = new (window.AudioContext || window.webkitAudioContext)(), o = ac.createOscillator(), g = ac.createGain(); o.frequency.value = f; o.connect(g); g.connect(ac.destination); g.gain.value = 0.15; o.start(); setTimeout(() => { o.stop(); ac.close(); }, ms); } catch {} }
FX.routine = (ds) => {
  const r = ROUTINES[ds.r], steps = [];
  for (let k = 0; k < r.rounds; k++) r.ex.forEach(([n, s], i) => { steps.push({ n, s, work: true, round: k + 1 }); if (!(k === r.rounds - 1 && i === r.ex.length - 1)) steps.push({ n: 'Istirahat', s: r.rest, work: false }); });
  let i = 0, left = steps[0].s, paused = false, startedAt = Date.now();
  const total = steps.reduce((s, x) => s + x.s, 0);
  openSheet(`<div class="sheet-pad center"><div class="mono muted">${r.ico} ${r.t}</div>
    <div class="rt-name" id="rtName"></div><div class="rt-time" id="rtTime"></div><div class="small muted" id="rtNext"></div>
    <div class="progress" style="margin:16px 0"><div id="rtBar" style="width:0"></div></div>
    <div class="btn-row"><button class="btn ghost" id="rtPrev">‹</button><button class="btn primary" id="rtPause" style="flex:2">❚❚ Jeda</button><button class="btn ghost" id="rtNextB">›</button></div>
    <button class="btn danger block" style="margin-top:10px" id="rtStop">Selesai</button></div>`, (root) => {
    const paint = () => {
      const st = steps[i], nx = steps[i + 1];
      $('#rtName', root).textContent = st.work ? `${st.n}${r.rounds > 1 ? ` · ronde ${st.round}` : ''}` : '😮‍💨 Istirahat';
      $('#rtName', root).style.color = st.work ? 'var(--teal)' : 'var(--muted)';
      $('#rtTime', root).textContent = `0:${pad(left)}`.replace(/^0:(\d\d)$/, (m, s) => (left >= 60 ? `${Math.floor(left / 60)}:${pad(left % 60)}` : `0:${s}`));
      $('#rtNext', root).textContent = nx ? `Berikutnya: ${nx.n}` : 'Terakhir!';
      const done = steps.slice(0, i).reduce((s, x) => s + x.s, 0) + (st.s - left);
      $('#rtBar', root).style.width = `${(done / total) * 100}%`;
    };
    const go2 = (j) => { i = clamp(j, 0, steps.length - 1); left = steps[i].s; if (steps[i].work) speak(steps[i].n); beep(steps[i].work ? 988 : 660); paint(); };
    const finish = (saveIt) => {
      clearInterval(rtT); rtT = null;
      const mins = Math.max(1, Math.round((Date.now() - startedAt) / 60000));
      if (saveIt && mins >= 3) {
        const now = Date.now();
        S.activities.push({ id: 'm' + now, source: 'local', manual: true, name: r.t, sport_type: ds.r === 'strength' ? 'WeightTraining' : 'Yoga', start_date_local: localIso(now - mins * 60000), started_ms: now - mins * 60000, distance: 0, moving_time: mins * 60, elapsed_time: mins * 60, elev: 0, avg_speed: 0, max_speed: 0, avg_hr: 0, kilojoules: 0, poly: '', city: '', desc: '' });
        S.activities.sort((x, y) => y.start_date_local.localeCompare(x.start_date_local)); save();
        toast(`Tersimpan: ${r.t} ${mins} menit ✓`);
      }
      closeSheet(); render();
    };
    $('#rtPause', root).onclick = (e) => { paused = !paused; e.currentTarget.textContent = paused ? '▶ Lanjut' : '❚❚ Jeda'; };
    $('#rtPrev', root).onclick = () => go2(i - 1);
    $('#rtNextB', root).onclick = () => go2(i + 1);
    $('#rtStop', root).onclick = () => finish(true);
    clearInterval(rtT);
    rtT = setInterval(() => {
      if (paused || !$('#rtTime')) { if (!$('#rtTime')) clearInterval(rtT); return; }
      left--; if (left <= 3 && left > 0) beep(520, 90);
      if (left <= 0) { if (i >= steps.length - 1) { beep(1200, 400); speak('Latihan selesai. Kerja bagus!'); finish(true); return; } go2(i + 1); } else paint();
    }, 1000);
    speak(`Mulai. ${steps[0].n}`); paint();
  });
};

// ======================= 9. PERAWATAN SEPEDA =======================
const PART_DEF = [['lube', 'Bersihkan & lumasi rantai', 300], ['chain', 'Ganti rantai', 3000], ['tireR', 'Ban belakang', 3500], ['tireF', 'Ban depan', 5000], ['brake', 'Kampas rem', 2500], ['cassette', 'Sproket / cassette', 9000], ['service', 'Servis total', 5000]];
function bikeParts() {
  if (!S.bike) { const d = today(); S.bike = { name: 'Sepeda utama', parts: PART_DEF.map(([k, n, life]) => ({ k, n, life, since: d })) }; save(true); }
  return S.bike.parts.map((p) => {
    const km = S.activities.filter((a) => isRide(a) && actDate(a) >= p.since).reduce((s, a) => s + a.distance / 1000, 0);
    return { ...p, km, pct: km / p.life };
  });
}
const partsDue = () => (S.onboarded ? bikeParts().filter((p) => p.pct >= 0.9) : []);
FX.bike = () => {
  const parts = bikeParts();
  openSheet(`<div class="sheet-pad"><div class="mono muted">Perawatan</div><h2 class="st">🔧 ${esc(S.bike.name)}</h2><div class="small muted">Km dihitung otomatis dari ride sejak terakhir diganti/diservis.</div></div>
    <div class="card" style="margin-top:12px">${parts.map((p) => {
      const col = p.pct >= 1 ? 'var(--red)' : p.pct >= 0.8 ? 'var(--yellowD)' : 'var(--ok)';
      return `<div class="part"><div class="part-top"><b>${esc(p.n)}</b><span style="color:${col};font-weight:700">${fmtNum(p.km)} / ${fmtNum(p.life)} km</span></div>
        <div class="ci-meter" style="--p:${Math.min(100, p.pct * 100)}%;background:linear-gradient(90deg,transparent 0 var(--p),var(--cream) var(--p) 100%),${col}"></div>
        <div class="part-bot"><span class="small muted">sejak ${fmtDate(p.since)}${p.pct >= 1 ? ' · ⚠️ waktunya!' : ''}</span><span><button class="link" data-fx="partLife" data-k="${p.k}">Ubah batas</button> · <button class="link" data-fx="partReset" data-k="${p.k}">✓ Sudah dikerjakan</button></span></div></div>`;
    }).join('')}</div>`);
};
FX.partReset = (ds) => { const p = S.bike.parts.find((x) => x.k === ds.k); p.since = today(); save(); toast(`${p.n} direset ✓`); FX.bike(); };
FX.partLife = (ds) => { const p = S.bike.parts.find((x) => x.k === ds.k); const v = parseInt(prompt(`Batas km untuk "${p.n}"`, p.life), 10); if (v > 0) { p.life = v; save(); FX.bike(); } };

// ======================= 11. LAPORAN PDF =======================
FX.pdf = () => {
  const rep = monthlyReport(); if (!rep) return;
  const b = bodyStats(), all = summarize(actsBetween(rep.start, rep.end), true), st = streakInfo();
  const weeks = [0, 1, 2, 3].map((w) => summarize(actsBetween(ymd(addDays(parseYmd(rep.start), w * 7)), ymd(addDays(parseYmd(rep.start), w * 7 + 6)))).km);
  const mx = Math.max(...weeks, 1);
  const A = cssVar('--teal', '#FF5A1F');
  const html = `<!doctype html><html><head><meta charset="utf-8"><title>Laporan Cycling Coach ${fmtDate(rep.start)}</title><style>
    @page{size:A4;margin:14mm}body{font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;color:#111318;margin:0}
    h1{font-size:26px;margin:0}.sub{color:#6B7280;margin:4px 0 18px}.hd{display:flex;gap:12px;align-items:center;border-bottom:3px solid ${A};padding-bottom:12px;margin-bottom:14px}
    .logo{width:44px;height:44px;border-radius:12px;overflow:hidden}.logo svg{width:100%;height:100%;display:block}
    .grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin:12px 0}.box{border:1px solid #E5E7EB;border-radius:10px;padding:10px}.box b{display:block;font-size:20px}.box span{font-size:11px;color:#6B7280}
    table{width:100%;border-collapse:collapse;font-size:13px;margin-top:6px}td,th{border-bottom:1px solid #E5E7EB;padding:7px 4px;text-align:left}th{color:#6B7280;font-weight:600}
    h2{font-size:16px;margin:18px 0 6px}.up{color:#16A34A}.down{color:#EF4444}.bars{display:flex;gap:12px;align-items:flex-end;height:110px;margin-top:8px}.bars div{flex:1;background:${A};border-radius:6px 6px 0 0;position:relative}.bars small{position:absolute;top:-16px;left:0;right:0;text-align:center;font-size:11px}
    li{margin:4px 0}.foot{margin-top:24px;font-size:11px;color:#9CA3AF}</style></head><body>
    <div class="hd"><div class="logo"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><defs><linearGradient id="ccgp" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FF6A1F"/><stop offset="1" stop-color="#FF2E63"/></linearGradient></defs><rect width="64" height="64" rx="15" fill="url(#ccgp)"/><g><path d="M2 52 L19 30 L27 39 L40 19 L62 52 Z" fill="#fff" fill-opacity=".24"/><circle cx="48" cy="13" r="4" fill="#fff"/><g fill="none" stroke="#fff" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="19" cy="44" r="8.5"/><circle cx="45" cy="44" r="8.5"/><path d="M19 44 L27 31 L40 31 L45 44 M27 31 L31.5 44 L40 31 M25 26.5 H30 M40 31 L38.5 25 L43 24.5"/></g></g></svg></div><div><h1>Laporan Bulanan · ${esc(S.profile.name || 'Pesepeda')}</h1><div class="sub" style="margin:2px 0 0">${fmtDate(rep.start)} – ${fmtDate(rep.end)} · Bulan ke-${S.cycles.length}${S.goal ? ` · Goal: ${esc(S.goal.title)}` : ''}</div></div></div>
    <div class="grid"><div class="box"><span>Jarak bersepeda</span><b>${fmtNum(rep.cur.km, 1)} km</b></div><div class="box"><span>Ride</span><b>${rep.cur.count}×</b></div><div class="box"><span>Elevasi</span><b>${fmtNum(rep.cur.elev)} m</b></div><div class="box"><span>Kepatuhan program</span><b>${Math.round(rep.compliance * 100)}%</b></div>
    <div class="box"><span>Avg speed</span><b>${fmtNum(rep.cur.avgSpeed, 1)} km/j</b></div><div class="box"><span>Ride terjauh</span><b>${fmtNum(rep.cur.longest, 1)} km</b></div><div class="box"><span>Kalori (semua olahraga)</span><b>${fmtNum(all.kcal)} kcal</b></div><div class="box"><span>Streak minggu</span><b>${st.weekStreak}</b></div></div>
    <h2>Kemajuan</h2><ul>${rep.wins.length ? rep.wins.map((w) => `<li>${esc(w)}</li>`).join('') : '<li>Belum ada kemajuan terukur bulan ini.</li>'}</ul>
    <h2>Jarak per minggu</h2><div class="bars">${weeks.map((k, i) => `<div style="height:${Math.max(4, (k / mx) * 100)}%"><small>${fmtNum(k)} km</small></div>`).join('')}</div>
    <div style="display:flex;gap:12px;font-size:11px;color:#6B7280;margin-top:4px">${weeks.map((_, i) => `<span style="flex:1;text-align:center">Minggu ${i + 1}</span>`).join('')}</div>
    <h2>Dibanding 28 hari sebelumnya</h2><table><tr><th>Metrik</th><th>Bulan ini</th><th>Sebelumnya</th><th>Perubahan</th></tr>${rep.items.map((it) => `<tr><td>${it.label}</td><td>${fmtNum(it.now, it.dec)} ${it.unit}</td><td>${fmtNum(it.prev, it.dec)} ${it.unit}</td><td class="${it.delta > 0 ? 'up' : it.delta < 0 ? 'down' : ''}">${it.delta == null || !isFinite(it.delta) ? '–' : `${it.delta > 0 ? '+' : ''}${fmtNum(it.delta)}%`}</td></tr>`).join('')}</table>
    <h2>Tubuh</h2><table><tr><td>Berat</td><td>${fmtNum(S.profile.weight, 1)} kg</td><td>BMI</td><td>${fmtNum(b.bmi, 1)} (${b.cat})</td></tr><tr><td>Estimasi lemak</td><td>${fmtNum(b.fatPct, 1)}%</td><td>Lemak terbakar</td><td>${fmtNum(all.fatG / 1000, 2)} kg</td></tr></table>
    <h2>Program bulan ini</h2><table><tr><td>Long ride target</td><td>${fmtNum(rep.cycle.cap.long)} km</td><td>Avg speed target</td><td>${fmtNum(rep.cycle.cap.speed, 1)} km/j</td></tr><tr><td>Elevasi target</td><td>${fmtNum(rep.cycle.cap.elev)} m</td><td>Sesi dijalankan</td><td>${rep.done}/${rep.planned}</td></tr></table>
    <div class="foot">Dibuat oleh Cycling Coach · ${new Date().toLocaleString('id-ID')}${S.demo ? ' · DATA DEMO' : ''}</div></body></html>`;
  const ifr = document.createElement('iframe'); ifr.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0';
  document.body.appendChild(ifr); ifr.contentDocument.open(); ifr.contentDocument.write(html); ifr.contentDocument.close();
  toast('Pilih "Simpan sebagai PDF" di jendela print');
  setTimeout(() => { try { ifr.contentWindow.focus(); ifr.contentWindow.print(); } catch { toast('Print tidak didukung di sini — buka lewat browser'); } setTimeout(() => ifr.remove(), 60000); }, 350);
};

// ======================= B. TUR PENGGUNA BARU =======================
const TOUR = () => [
  ['🏠', 'Beranda', 'Latihan hari ini, cuaca & jam terbaik, planner nutrisi, dan feed aktivitas lo.'],
  ['📅', 'Program', 'Roadmap sampai tahun goal + jadwal 7 hari. Tap kartu hari buat detail sesi. Evaluasi tiap akhir bulan.'],
  ['❤️', 'Kondisi', 'Geser slider tiap pagi — porsi latihan hari itu otomatis menyesuaikan kondisi tubuh.'],
  HAS_REC ? ['⏺', 'Rekam', 'Rekam gowes, lari, jalan pakai GPS. Ada suara pelatih tiap km & split otomatis.'] : ['🔗', 'Strava', 'Aktivitas Strava otomatis masuk tiap app dibuka — langsung dicocokkan dengan program.'],
  ['🏅', 'Progres & Profil', 'Statistik, badge, streak, simulasi event, tes FTP, perawatan sepeda & laporan PDF.'],
];
function maybeTour(force) {
  if (!force && S.tourDone) return;
  const steps = TOUR(); let i = 0;
  const el = document.createElement('div'); el.className = 'tour'; document.body.appendChild(el);
  const draw = () => {
    const [ico, t, d] = steps[i];
    el.innerHTML = `<div class="tour-card"><div class="tour-ico">${ico}</div><h2>${t}</h2><p>${d}</p>
      <div class="tour-dots">${steps.map((_, k) => `<i class="${k === i ? 'on' : ''}"></i>`).join('')}</div>
      <div class="btn-row"><button class="btn ghost" id="tSkip">Lewati</button><button class="btn primary" id="tNext">${i === steps.length - 1 ? 'Mulai 🚴' : 'Lanjut'}</button></div></div>`;
    $('#tSkip', el).onclick = done; $('#tNext', el).onclick = () => (i === steps.length - 1 ? done() : (i++, draw()));
  };
  const done = () => { el.remove(); S.tourDone = true; save(); };
  draw();
}
FX.tour = () => { closeSheet(); setTimeout(() => maybeTour(true), 250); };

// ======================= C. PENGINGAT BACKUP =======================
function backupDue() {
  if (S.demo || !S.onboarded || (S.activities.length < 3 && S.cycles.length < 2)) return false;
  if (S.backupSnooze && Date.now() < S.backupSnooze) return false;
  return !S.lastBackup || Date.now() - S.lastBackup > 14 * 864e5;
}
function doBackup() {
  const data = { ...S, auth: null, settings: { ...S.settings, clientSecret: '' } };
  const blob = new Blob([JSON.stringify(data)], { type: 'application/json' });
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `cycling-coach-backup-${today()}.json`; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  S.lastBackup = Date.now(); save(); toast('Backup diunduh — simpan di Google Drive / WA ke diri sendiri'); render();
}
FX.backup = doBackup;
FX.backupLater = () => { S.backupSnooze = Date.now() + 3 * 864e5; save(); render(); };

// ======================= E. PRIVASI =======================
FX.privacy = () => openSheet(`<div class="sheet-pad"><h2 class="st">Privasi & Ketentuan</h2><div class="small muted">Versi singkat, bahasa manusia.</div></div>
  <div class="card" style="margin-top:12px">
  <h2>📱 Data lo tersimpan di HP lo</h2><div class="small">Profil, goal, program, check-in, berat badan & aktivitas disimpan di browser/HP ini saja. Tidak ada server Cycling Coach yang menyimpan data lo.</div>
  <h2 style="margin-top:14px">📍 Lokasi</h2><div class="small">${HAS_REC ? 'GPS dipakai hanya saat lo menekan Rekam, untuk menghitung rute & jarak. ' : ''}Lokasi cuaca (kota/koordinat kasar) dikirim ke layanan cuaca Open-Meteo untuk mengambil prakiraan — tanpa identitas lo.</div>
  ${IS_STRAVA_APP ? `<h2 style="margin-top:14px">🔗 Strava</h2><div class="small">Kalau lo connect, app mengambil aktivitas & profil lo langsung dari Strava ke HP ini (read-only). Token login Strava disimpan di HP ini. Putuskan kapan saja di Setelan atau di strava.com/settings/apps. Powered by Strava.</div>` : ''}
  <h2 style="margin-top:14px">🗑️ Kendali penuh</h2><div class="small">Hapus semua data kapan pun lewat Setelan → Hapus semua data. Pakai Backup untuk memindahkan data ke HP lain.</div>
  <h2 style="margin-top:14px">⚕️ Catatan kesehatan</h2><div class="small">Program, kalori, lemak & zona adalah estimasi edukatif, bukan saran medis. Konsultasikan ke dokter sebelum mulai latihan berat, terutama jika punya kondisi kesehatan tertentu.</div></div>`);
FX.voice = (ds, el) => { S.settings.voice = S.settings.voice === false; save(); el.classList.toggle('on', S.settings.voice !== false); if (S.settings.voice !== false) speak('Suara pelatih aktif'); };
FX.autoPause = (ds, el) => { S.settings.autoPause = S.settings.autoPause === false; save(); el.classList.toggle('on', S.settings.autoPause !== false); };
FX.voiceTest = () => { const was = S.settings.voice; S.settings.voice = true; speak('Kilometer 5. Kecepatan rata-rata 25 kilometer per jam. Sisa target 40 kilometer.'); S.settings.voice = was; };

// ======================= HTML sisipan =======================
function homeExtrasHtml() {
  let h = '';
  const due = partsDue();
  if (backupDue()) h += `<div class="card"><div class="card-head"><div><div class="mono muted">Amankan data</div><h2>💾 Waktunya backup</h2></div></div><div class="small muted">Data lo cuma ada di HP ini. Backup tiap 2 minggu, simpan di Drive / kirim ke WA sendiri.</div><div class="btn-row"><button class="btn primary" data-fx="backup">Backup sekarang</button><button class="btn ghost" data-fx="backupLater">Nanti</button></div></div>`;
  if (due.length) h += `<div class="card"><div class="card-head"><div><div class="mono muted">Perawatan sepeda</div><h2>🔧 ${due.length} item perlu dicek</h2></div><button class="link" data-fx="bike">Lihat ›</button></div><div class="small muted">${due.map((p) => `${esc(p.n)} (${fmtNum(p.km)}/${fmtNum(p.life)} km)`).join(' · ')}</div></div>`;
  return h;
}
function youExtrasHtml() {
  return `${badgesHtml(6)}
    <div class="card"><h2>Tools</h2><div class="tool-grid">
      <button data-fx="sim"><span>🗺️</span>Simulasi event</button>
      <button data-fx="ftp"><span>📈</span>Tes FTP${ftpDue() ? ' <i class="dotw"></i>' : ''}</button>
      <button data-fx="bike"><span>🔧</span>Perawatan sepeda${partsDue().length ? ' <i class="dotw"></i>' : ''}</button>
      <button data-fx="routine" data-r="strength"><span>🏋️</span>Latihan kekuatan</button>
      <button data-fx="routine" data-r="mobility"><span>🧘</span>Mobilitas</button>
      <button data-fx="pdf"><span>📄</span>Laporan PDF</button></div></div>`;
}
function programExtrasHtml() {
  let h = `<div class="pad" style="margin:-2px 0 10px"><div class="btn-row" style="margin-top:0"><button class="btn ghost small" data-fx="sim">🗺️ Simulasi event</button><button class="btn ghost small" data-fx="ftp">📈 Tes FTP / zona</button></div></div>`;
  if (ftpDue() && S.cycles.length) h += `<div class="card" style="border-radius:var(--r);margin:0 12px 10px"><div class="card-head" style="margin:0"><div><div class="mono muted">Kalibrasi</div><h2>📈 ${S.ftp ? 'Sudah 7 minggu sejak tes terakhir' : 'Belum pernah tes FTP'}</h2><div class="small muted">Tes 20 menit supaya zona & target speed akurat.</div></div><button class="btn primary small" data-fx="ftp">Tes</button></div></div>`;
  return h;
}
function settingsExtrasHtml() {
  const v = S.settings.voice !== false, ap = S.settings.autoPause !== false;
  return `${HAS_REC ? `<div class="card"><h2>Rekam & suara</h2>
    <div class="toggle"><div><b>Suara pelatih</b><div class="small muted">Bacakan jarak, speed & sisa target</div></div><button class="switch ${v ? 'on' : ''}" data-fx="voice"></button></div>
    <label class="f">Umumkan tiap<select id="sVoiceEvery" onchange="S.settings.voiceEvery=+this.value;save()">${[1, 2, 5, 10].map((k) => `<option value="${k}" ${+(S.settings.voiceEvery || 1) === k ? 'selected' : ''}>${k} km</option>`).join('')}</select></label>
    <div class="toggle"><div><b>Auto-pause</b><div class="small muted">Timer utama pakai waktu bergerak saja</div></div><button class="switch ${ap ? 'on' : ''}" data-fx="autoPause"></button></div>
    <button class="btn ghost block" data-fx="voiceTest">🔊 Tes suara</button></div>` : ''}
    <div class="card"><h2>Bantuan</h2><div class="btn-row" style="margin-top:6px"><button class="btn ghost" data-fx="tour">🧭 Lihat tur</button><button class="btn ghost" data-fx="privacy">🔒 Privasi</button></div></div>`;
}
