/* Cycling Coach — platform & helper rute */
'use strict';

const Cap = window.Capacitor;
const isNative = !!(Cap && Cap.isNativePlatform && Cap.isNativePlatform());

// Google encoded polyline → [[lat,lng]]
function decodePolyline(str) {
  let i = 0, lat = 0, lng = 0; const out = [];
  while (i < str.length) {
    for (const k of [0, 1]) {
      let b, shift = 0, res = 0;
      do { b = str.charCodeAt(i++) - 63; res |= (b & 0x1f) << shift; shift += 5; } while (b >= 0x20);
      const v = res & 1 ? ~(res >> 1) : res >> 1;
      if (k === 0) lat += v; else lng += v;
    }
    out.push([lat / 1e5, lng / 1e5]);
  }
  return out;
}
function polylineSvg(poly, w = 340, h = 150) {
  if (!poly) return '';
  const pts = decodePolyline(poly); if (pts.length < 2) return '';
  const lats = pts.map((p) => p[0]), lngs = pts.map((p) => p[1]);
  const minLa = Math.min(...lats), maxLa = Math.max(...lats), minLo = Math.min(...lngs), maxLo = Math.max(...lngs);
  const k = Math.cos(((minLa + maxLa) / 2) * Math.PI / 180);
  const sx = (maxLo - minLo) * k || 1e-6, sy = maxLa - minLa || 1e-6;
  const sc = Math.min((w - 24) / sx, (h - 24) / sy);
  const ox = (w - sx * sc) / 2, oy = (h - sy * sc) / 2;
  const d = pts.map((p, i) => `${i ? 'L' : 'M'}${(ox + (p[1] - minLo) * k * sc).toFixed(1)},${(oy + (maxLa - p[0]) * sc).toFixed(1)}`).join('');
  const [s0, s1] = [pts[0], pts[pts.length - 1]];
  const px = (p) => [(ox + (p[1] - minLo) * k * sc).toFixed(1), (oy + (maxLa - p[0]) * sc).toFixed(1)];
  const a = px(s0), b = px(s1);
  return `<svg class="map" viewBox="0 0 ${w} ${h}" preserveAspectRatio="xMidYMid meet"><path d="${d}" fill="none" stroke="var(--route)" stroke-width="3" stroke-linejoin="round" stroke-linecap="round"/><circle cx="${a[0]}" cy="${a[1]}" r="5" fill="var(--ok)" stroke="#fff" stroke-width="2"/><circle cx="${b[0]}" cy="${b[1]}" r="5" fill="var(--red)" stroke="#fff" stroke-width="2"/></svg>`;
}
