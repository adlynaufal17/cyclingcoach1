/* Cycling Coach — cuaca latihan, planner nutrisi & kartu share IG Story */
'use strict';

// ======================= CUACA (Open-Meteo, gratis tanpa API key) =======================
const WX_KEY = 'cyclingcoach.wx';
let WX = null;
try { WX = JSON.parse(localStorage.getItem(WX_KEY) || 'null'); } catch { WX = null; }
let wxLoading = false;

const WMO = (c) => {
  if (c === 0) return ['☀️', 'Cerah'];
  if (c <= 2) return ['🌤️', 'Cerah berawan'];
  if (c === 3) return ['☁️', 'Berawan'];
  if (c <= 48) return ['🌫️', 'Berkabut'];
  if (c <= 57) return ['🌦️', 'Gerimis'];
  if (c <= 67) return ['🌧️', 'Hujan'];
  if (c <= 77) return ['🌨️', 'Salju'];
  if (c <= 82) return ['🌧️', 'Hujan lebat'];
  return ['⛈️', 'Badai petir'];
};

const WX_TTL = 15 * 60000;
const nowHM = () => { const d = new Date(); return `${pad(d.getHours())}:${pad(d.getMinutes())}`; };
// lokasi lama "Lokasi saya" → jadikan otomatis
if (S.settings.loc && S.settings.loc.auto === undefined && S.settings.loc.name === 'Lokasi saya') S.settings.loc.auto = true;

async function reverseName(lat, lon) {
  try {
    const r = await fetch(`https://api.bigdatacloud.net/data/reverse-geocode-client?${new URLSearchParams({ latitude: lat, longitude: lon, localityLanguage: 'id' })}`);
    const j = await r.json(); return j.locality || j.city || j.principalSubdivision || null;
  } catch { return null; }
}
let locBusy = false, lastLocTry = 0;
// mode otomatis: ambil posisi HP terbaru (maks. tiap 10 menit), ganti nama kota kalau pindah > 2 km
function refreshAutoLoc(force) {
  const loc = S.settings.loc;
  if (!loc || !loc.auto || !navigator.geolocation || locBusy) return Promise.resolve(false);
  if (!force && Date.now() - lastLocTry < 10 * 60000) return Promise.resolve(false);
  locBusy = true; lastLocTry = Date.now();
  return new Promise((res) => navigator.geolocation.getCurrentPosition(async (pos) => {
    const lat = +pos.coords.latitude.toFixed(3), lon = +pos.coords.longitude.toFixed(3);
    const moved = haversine([loc.lat, loc.lon], [lat, lon]) > 2000 || !loc.named;
    if (moved) { const nm = await reverseName(lat, lon); Object.assign(S.settings.loc, { lat, lon, name: nm || loc.name || 'Lokasi saya', named: !!nm, at: Date.now() }); save(); }
    locBusy = false; res(moved);
  }, () => { locBusy = false; res(false); }, { enableHighAccuracy: false, maximumAge: 10 * 60000, timeout: 15000 }));
}

async function ensureWeather(force) {
  const loc = S.settings.loc;
  if (!loc || wxLoading) return false;
  const moved = await refreshAutoLoc(force);
  const fresh = WX && WX.current && WX.lat === loc.lat && WX.lon === loc.lon && Date.now() - WX.at < WX_TTL;
  if (fresh && !force && !moved) return false;
  wxLoading = true;
  try {
    const q = new URLSearchParams({ latitude: loc.lat, longitude: loc.lon,
      current: 'temperature_2m,apparent_temperature,relative_humidity_2m,precipitation,weather_code,wind_speed_10m,is_day',
      hourly: 'temperature_2m,apparent_temperature,precipitation_probability,precipitation,wind_speed_10m,weather_code', daily: 'sunrise,sunset', timezone: 'auto', forecast_days: '7' });
    const r = await fetch('https://api.open-meteo.com/v1/forecast?' + q);
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const j = await r.json(), H = j.hourly, C = j.current || {};
    const hours = H.time.map((t, i) => ({ t, temp: H.temperature_2m[i], feel: H.apparent_temperature[i], pop: H.precipitation_probability?.[i] ?? 0, rain: H.precipitation?.[i] ?? 0, wind: H.wind_speed_10m[i], code: H.weather_code[i] }));
    const days = {}; (j.daily?.time || []).forEach((d, i) => (days[d] = { sunrise: j.daily.sunrise[i].slice(11, 16), sunset: j.daily.sunset[i].slice(11, 16) }));
    const current = C.time ? { t: C.time, temp: C.temperature_2m, feel: C.apparent_temperature, hum: C.relative_humidity_2m, rain: C.precipitation ?? 0, code: C.weather_code, wind: C.wind_speed_10m, isDay: C.is_day !== 0 } : null;
    WX = { lat: loc.lat, lon: loc.lon, at: Date.now(), hours, days, current, tz: j.timezone_abbreviation || '' };
    try { localStorage.setItem(WX_KEY, JSON.stringify(WX)); } catch {}
    return true;
  } catch (e) { console.warn('weather', e); return false; }
  finally { wxLoading = false; }
}
const wxAt = (d, hm) => { if (!WX) return null; const key = `${d}T${hm.slice(0, 2)}:00`; return WX.hours.find((h) => h.t === key) || null; };
const wxHasDay = (d) => !!(WX && WX.hours.some((h) => h.t.startsWith(d)));

function wxVerdict(e) {
  if (!e) return null;
  const tips = [];
  let lvl = 'ok';
  if (e.pop >= 70 || e.rain >= 2 || e.code >= 80) { lvl = 'bad'; tips.push('Risiko hujan tinggi — pertimbangkan indoor trainer atau geser jam'); }
  else if (e.pop >= 40) { lvl = 'warn'; tips.push('Bawa jaket hujan tipis, cek ulang sebelum berangkat'); }
  if (e.feel >= 34) { lvl = lvl === 'bad' ? 'bad' : 'warn'; tips.push('Panas terik — kurangi intensitas 5–10%, perbanyak minum & elektrolit'); }
  else if (e.feel >= 31) tips.push('Cukup panas — tambah 1 bidon & pakai sunblock');
  if (e.wind >= 25) { lvl = lvl === 'bad' ? 'bad' : 'warn'; tips.push('Angin kencang — rute terlindung, speed wajar lebih rendah'); }
  const label = { ok: 'Cocok buat gowes', warn: 'Perlu antisipasi', bad: 'Kurang ideal' }[lvl];
  const color = { ok: 'var(--ok)', warn: 'var(--yellowD)', bad: 'var(--red)' }[lvl];
  return { lvl, label, color, tips };
}
// cari jendela jam terbaik (skor terendah) untuk durasi sesi
function bestWindow(d, durMin) {
  if (!wxHasDay(d)) return null;
  const n = Math.max(1, Math.ceil(durMin / 60)), day = WX.days[d] || { sunrise: '05:30', sunset: '17:50' };
  const sr = +day.sunrise.slice(0, 2), ss = +day.sunset.slice(0, 2);
  const nowH = d === today() ? new Date().getHours() + 1 : 0;
  let best = null;
  for (let h = Math.max(sr, nowH, 5); h + n <= Math.min(ss + 1, 20); h++) {
    let sc = 0;
    for (let k = 0; k < n; k++) {
      const e = wxAt(d, `${pad(h + k)}:00`); if (!e) { sc = 1e9; break; }
      sc += e.pop * 1.2 + e.rain * 15 + Math.max(0, e.feel - 29) * 7 + Math.max(0, 22 - e.temp) * 2 + Math.max(0, e.wind - 18) * 1.5;
    }
    if (!best || sc < best.sc) best = { sc, from: `${pad(h)}:00`, to: `${pad(h + n)}:00` };
  }
  return best;
}

const wxIco = (code, isDay = true) => (!isDay && code <= 2 ? ['🌙', code === 0 ? 'Cerah (malam)' : 'Cerah berawan (malam)'] : WMO(code));
const PIN_SVG = '<svg viewBox="0 0 24 24"><path d="M12 21s-7-6.2-7-11a7 7 0 0 1 14 0c0 4.8-7 11-7 11z"/><circle cx="12" cy="10" r="2.5"/></svg>';
function wxHeadHtml(extra = '') {
  const L = S.settings.loc;
  return `<div class="wx-top"><div class="mono muted">📍 ${esc(L.name)}${L.auto ? ' · otomatis' : ''}${extra}</div><button class="icon-btn" id="wxSet" aria-label="Lokasi" style="color:var(--muted);width:34px;height:34px">${PIN_SVG}</button></div>`;
}
function weatherCardHtml(d) {
  const p = adjustedFor(d);
  if (!S.settings.loc) return `<div class="card wx-card"><div class="card-head"><div><div class="mono muted">Cuaca latihan</div><h2>Atur lokasi cuaca</h2></div><div style="font-size:30px">🌤️</div></div>
    <div class="small muted">Cuaca real-time di lokasi lo, peringatan hujan/panas & jam terbaik buat gowes.</div><button class="btn primary block" style="margin-top:10px" id="wxSet">📍 Aktifkan lokasi</button></div>`;
  if (!wxHasDay(d)) return `<div class="card wx-card">${wxHeadHtml()}<div class="small muted" style="margin-top:6px">${wxLoading || !WX ? 'Memuat cuaca…' : 'Prakiraan hanya tersedia 7 hari ke depan.'}</div></div>`;
  const tt = S.settings.trainTime, isToday = d === today();

  // ---- hari lain: prakiraan di jam latihan ----
  if (!isToday || !WX.current) {
    const e = wxAt(d, tt) || wxAt(d, '06:00'), v = wxVerdict(e), [ico, txt] = WMO(e.code);
    const bw = p && p.type !== 'REST' ? bestWindow(d, p.dur || 60) : null;
    return `<div class="card wx-card">${wxHeadHtml(` · ${fmtDateShort(d)} jam ${tt}`)}
      <h2 style="margin:2px 0 10px">${ico} ${Math.round(e.temp)}°C <span class="small muted" style="font-weight:600">${txt} · terasa ${Math.round(e.feel)}°</span></h2>
      <div class="sbox-row"><div class="sbox"><div class="l">Hujan</div><div class="v">${Math.round(e.pop)}%</div></div><div class="sbox"><div class="l">Angin</div><div class="v">${Math.round(e.wind)} km/j</div></div><div class="sbox"><div class="l">Status</div><div class="v" style="color:${v.color};font-size:13px">${v.label}</div></div></div>
      ${bw ? `<div class="note" style="margin-top:10px">⏰ Jam terbaik buat sesi ini: <b>${bw.from}–${bw.to}</b></div>` : ''}
      ${v.tips.length ? `<ul class="wx-tips">${v.tips.map((x) => `<li>${esc(x)}</li>`).join('')}</ul>` : ''}</div>`;
  }

  // ---- hari ini: real-time ----
  const c = WX.current, [cIco, cTxt] = wxIco(c.code, c.isDay);
  const nowKey = `${today()}T${pad(new Date().getHours())}:00`;
  const idx = Math.max(0, WX.hours.findIndex((h) => h.t === nowKey));
  const next = WX.hours.slice(idx, idx + 9);
  const curPop = next[0]?.pop ?? 0;
  const strip = next.map((h, i) => { const [ic] = wxIco(h.code, +h.t.slice(11, 13) >= 6 && +h.t.slice(11, 13) < 18); const isTrain = h.t.slice(11, 13) === tt.slice(0, 2);
    return `<div class="wx-h ${isTrain ? 'train' : ''}"><div class="t">${i === 0 ? 'Skrg' : h.t.slice(11, 16)}</div><div class="i">${i === 0 ? cIco : ic}</div><div class="v">${Math.round(i === 0 ? c.temp : h.temp)}°</div><div class="p" style="${h.pop >= 50 ? 'color:#3B82F6;font-weight:700' : ''}">${Math.round(h.pop)}%</div></div>`; }).join('');
  // sesi berikutnya: jam latihan hari ini kalau belum lewat, kalau sudah → besok
  const later = nowHM() < tt;
  const sd = later ? d : ymd(addDays(new Date(), 1)), sp = adjustedFor(sd);
  const se = wxAt(sd, tt), sv = se ? wxVerdict(se) : null;
  const bw = sp && sp.type !== 'REST' ? bestWindow(sd, sp.dur || 60) : null;
  const nowV = wxVerdict({ ...c, pop: curPop });
  const tips = [...new Set([...(sv?.tips || []), ...(!later ? [] : []), ...nowV.tips.filter(() => !sv)])];
  const upd = new Date(WX.at);
  return `<div class="card wx-card">${wxHeadHtml()}
    <div class="wx-now"><div class="wx-big">${cIco}<b>${Math.round(c.temp)}°</b></div>
      <div style="min-width:0"><div class="wx-desc">${cTxt}</div><div class="small muted">Terasa ${Math.round(c.feel)}° · lembap ${Math.round(c.hum)}% · angin ${Math.round(c.wind)} km/j${c.rain ? ` · hujan ${fmtNum(c.rain, 1)} mm` : ''}</div>
      <div class="wx-clock">🕒 Sekarang <b id="wxClock">${nowHM()}</b></div></div></div>
    <div class="wx-strip">${strip}</div>
    ${sp && sp.type !== 'REST' && se ? `<div class="wx-sess" style="border-color:${sv.color}"><div><div class="small muted">${later ? 'Latihan hari ini' : 'Latihan besok'} · jam ${tt}</div><b>${sp.ico} ${esc(sp.name)}</b></div>
      <div style="text-align:right"><div>${WMO(se.code)[0]} ${Math.round(se.temp)}° · ${Math.round(se.pop)}%</div><div class="small" style="color:${sv.color};font-weight:700">${sv.label}</div></div></div>` : sp && sp.type === 'REST' ? `<div class="note" style="margin-top:10px">😴 ${later ? 'Hari ini' : 'Besok'} rest day — santai dulu.</div>` : ''}
    ${bw ? `<div class="note" style="margin-top:10px">⏰ Jam terbaik ${later ? 'hari ini' : 'besok'}: <b>${bw.from}–${bw.to}</b>${bw.from.slice(0, 2) === tt.slice(0, 2) ? ' (pas dengan jadwal lo)' : ''}</div>` : ''}
    ${tips.length ? `<ul class="wx-tips">${tips.map((x) => `<li>${esc(x)}</li>`).join('')}</ul>` : ''}
    <div class="wx-foot"><span>Diperbarui ${pad(upd.getHours())}:${pad(upd.getMinutes())} · Open-Meteo</span><button class="link" id="wxRefresh">↻ Perbarui</button></div></div>`;
}
function bindWeatherCard(root) {
  const b = $('#wxSet', root); if (b) b.onclick = openLocationSheet;
  const r = $('#wxRefresh', root); if (r) r.onclick = async () => { r.textContent = 'Memuat…'; lastLocTry = 0; await ensureWeather(true); render(); toast('Cuaca diperbarui'); };
}
// jam berjalan + auto-refresh tiap 15 menit saat Beranda terbuka
setInterval(() => {
  const el = document.getElementById('wxClock'); if (el) el.textContent = nowHM();
  if (typeof VIEW !== 'undefined' && VIEW === 'home' && document.visibilityState === 'visible' && S.settings.loc && (!WX || Date.now() - WX.at > WX_TTL)) ensureWeather().then((ch) => { if (ch && VIEW === 'home') renderHome(); });
}, 30000);
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible' && S.settings.loc) ensureWeather().then((ch) => { if (ch && typeof VIEW !== 'undefined' && VIEW === 'home') renderHome(); }); });

function openLocationSheet() {
  const L = S.settings.loc;
  openSheet(`<div class="sheet-pad"><h2 class="st">Lokasi cuaca</h2><div class="small muted">Cuaca real-time & prakiraan di jam latihan lo.</div></div>
    <div class="card" style="margin-top:12px"><button class="btn primary block" id="locGps">📍 Otomatis ikut lokasi HP</button>
    <div class="small muted" style="margin-top:6px">Lokasi diperbarui otomatis tiap app dibuka (maks. tiap 10 menit) — cocok kalau lo sering gowes di kota berbeda.</div>
    <label class="f">Atau pilih kota tetap<input id="locQ" placeholder="Contoh: Bogor, Cikampek, Bandung"></label>
    <div id="locRes"></div>${L ? `<div class="small muted" style="margin-top:10px">Sekarang: <b>${esc(L.name)}</b> ${L.auto ? '(otomatis)' : '(tetap)'}</div>` : ''}</div>`, (root) => {
    const setLoc = async (loc) => { S.settings.loc = loc; save(); closeSheet(); toast(`Lokasi cuaca: ${loc.name}${loc.auto ? ' (otomatis)' : ''}`); WX = null; lastLocTry = Date.now(); await ensureWeather(true); render(); };
    $('#locGps', root).onclick = () => {
      if (!navigator.geolocation) return toast('GPS tidak didukung');
      $('#locGps', root).textContent = 'Mencari lokasi…';
      navigator.geolocation.getCurrentPosition(async (pos) => {
        const lat = +pos.coords.latitude.toFixed(3), lon = +pos.coords.longitude.toFixed(3), nm = await reverseName(lat, lon);
        setLoc({ name: nm || 'Lokasi saya', named: !!nm, lat, lon, auto: true, at: Date.now() });
      }, () => { $('#locGps', root).textContent = '📍 Otomatis ikut lokasi HP'; toast('Izin lokasi ditolak — pilih kota saja'); }, { enableHighAccuracy: false, maximumAge: 5 * 60000, timeout: 15000 });
    };
    let t;
    $('#locQ', root).oninput = (ev) => {
      clearTimeout(t); const q = ev.target.value.trim(); if (q.length < 3) return;
      t = setTimeout(async () => {
        try {
          const r = await fetch(`https://geocoding-api.open-meteo.com/v1/search?${new URLSearchParams({ name: q, count: '6', language: 'id' })}`);
          const j = await r.json();
          $('#locRes', root).innerHTML = (j.results || []).map((x, i) => `<div class="kv loc-opt" data-i="${i}" style="cursor:pointer"><span>${esc(x.name)}</span><b>${esc([x.admin1, x.country].filter(Boolean).join(', '))}</b></div>`).join('') || '<div class="small muted" style="margin-top:8px">Tidak ketemu</div>';
          $$('.loc-opt', root).forEach((o) => (o.onclick = () => { const x = j.results[+o.dataset.i]; setLoc({ name: x.name, named: true, lat: +x.latitude.toFixed(3), lon: +x.longitude.toFixed(3), auto: false }); }));
        } catch { $('#locRes', root).innerHTML = '<div class="small muted" style="margin-top:8px">Gagal mencari — cek internet</div>'; }
      }, 400);
    };
  });
}

// ======================= PLANNER NUTRISI =======================
function fuelPlan(p) {
  if (!p || p.type === 'REST' || !p.dur) return null;
  const h = p.dur / 60, kg = S.profile.weight || 70;
  const e = wxHasDay(p.date) ? wxAt(p.date, S.settings.trainTime) : null;
  const temp = e ? e.feel : 30; // default iklim tropis
  const intense = ['INTERVAL', 'HILL', 'TEMPO'].includes(p.type);
  const cph = h < 1 ? 0 : h < 1.5 ? 30 : h < 2.5 ? (intense ? 60 : 45) : h < 4 ? 60 : 80;
  const fph = Math.min(1000, 500 + (temp >= 26 ? 150 : 0) + (temp >= 30 ? 150 : 0) + (temp >= 34 ? 100 : 0) + (intense ? 100 : 0));
  const naph = temp >= 30 ? 600 : temp >= 26 ? 450 : 300;
  const carbs = Math.round(cph * h), fluid = Math.round((fph * h) / 50) * 50, sodium = Math.round((naph * h) / 50) * 50;
  const bottles = Math.max(1, Math.ceil(fluid / 750));
  const refillKm = bottles > 2 && p.speed ? Math.round(((1500 / fph) * p.speed) / 5) * 5 : 0;
  return {
    h, cph, fph, naph, carbs, fluid, sodium, bottles, refillKm, temp: Math.round(temp), fromWx: !!e,
    gels: Math.ceil(carbs / 25), bananas: Math.ceil(carbs / 27),
    pre: Math.round((h >= 1.5 ? 1.5 : 1) * kg), post: { carb: Math.round(1.1 * kg), prot: Math.round(0.3 * kg) },
    eatEvery: cph ? (h > 3 ? 30 : 40) : 0,
  };
}
const fuelShort = (f) => (f ? `🧃 ${f.bottles} bidon${f.carbs ? ` · ${f.gels} gel (${f.cph} g karbo/jam)` : ' · tanpa karbo tambahan'}` : '');
function fuelCardHtml(p) {
  const f = fuelPlan(p); if (!f) return `<div class="card"><h2>Nutrisi</h2><div class="small">${esc(p.fuel || '-')}</div></div>`;
  return `<div class="card"><div class="card-head"><h2>🧃 Planner nutrisi & hidrasi</h2><span class="chip">${f.fromWx ? `terasa ${f.temp}°C` : 'asumsi 30°C'}</span></div>
    <div class="sbox-row"><div class="sbox"><div class="l">Cairan</div><div class="v">${fmtNum(f.fluid / 1000, 1)} L</div></div><div class="sbox spd"><div class="l">Karbo</div><div class="v">${f.carbs} g</div></div><div class="sbox elv"><div class="l">Sodium</div><div class="v">${f.sodium} mg</div></div></div>
    <div class="fuel-list">
      ${kv('Bawa', `${f.bottles} bidon 750 ml${f.carbs ? ` + ${f.gels} gel / ${f.bananas} pisang` : ''}`)}
      ${kv('Minum', `${f.fph} ml/jam · teguk tiap 15–20 menit`)}
      ${f.carbs ? kv('Makan', `${f.cph} g karbo/jam · tiap ${f.eatEvery} menit`) : kv('Makan', 'Tidak perlu (< 1 jam)')}
      ${kv('Elektrolit', `${f.naph} mg sodium/jam${f.temp >= 30 ? ' (tablet elektrolit)' : ''}`)}
      ${f.refillKm ? kv('Isi ulang', `± tiap ${f.refillKm} km (bawa 2 bidon)`) : ''}
      ${kv('Sebelum', `${f.pre} g karbo, 2–3 jam sebelum start`)}
      ${kv('Sesudah', `${f.post.carb} g karbo + ${f.post.prot} g protein dalam 1 jam`)}
    </div>
    <div class="small muted" style="margin-top:8px">1 gel ≈ 25 g · 1 pisang ≈ 27 g · 1 roti selai ≈ 30 g · 3 kurma ≈ 18 g karbo. Dihitung dari durasi ${fmtDur(p.dur)}, intensitas, berat ${fmtNum(S.profile.weight, 1)} kg & cuaca.</div>
    ${p.fuel ? `<div class="note">${esc(p.fuel)}</div>` : ''}</div>`;
}

// ======================= KARTU SHARE IG STORY =======================
function cssVar(n, fb) { const v = getComputedStyle(document.documentElement).getPropertyValue(n).trim(); return v || fb; }
function wrapText(ctx, text, maxW) {
  const words = String(text).split(/\s+/), lines = []; let cur = '';
  words.forEach((w) => { const t = cur ? cur + ' ' + w : w; if (ctx.measureText(t).width > maxW && cur) { lines.push(cur); cur = w; } else cur = t; });
  if (cur) lines.push(cur); return lines;
}
function rrect(ctx, x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }

let _logoImg = null;
function logoImage() {
  if (_logoImg) return Promise.resolve(_logoImg);
  const svg = document.querySelector('.brand-logo svg');
  if (!svg) return Promise.resolve(null);
  return new Promise((res) => { const im = new Image(); im.onload = () => { _logoImg = im; res(im); }; im.onerror = () => res(null);
    im.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg.outerHTML.replace('<svg ', '<svg width="232" height="232" ')); });
}
async function renderShareCard(a, style = 'dark') {
  try { await document.fonts.ready; } catch {}
  const W = 1080, H = 1920, cv = document.createElement('canvas'); cv.width = W; cv.height = H;
  const ctx = cv.getContext('2d');
  const A1 = cssVar('--teal', '#FF5A1F'), A2 = cssVar('--accent2', A1);
  const FU = cssVar('--f-ui', 'sans-serif'), FN = cssVar('--f-num', FU);
  const clear = style === 'clear';
  // latar
  if (!clear) {
    ctx.fillStyle = '#0E0F12'; ctx.fillRect(0, 0, W, H);
    let g = ctx.createRadialGradient(W, 0, 0, W, 0, 1100); g.addColorStop(0, A1 + 'CC'); g.addColorStop(1, 'transparent'); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    g = ctx.createRadialGradient(0, H, 0, 0, H, 1000); g.addColorStop(0, A2 + '99'); g.addColorStop(1, 'transparent'); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  }
  ctx.shadowColor = clear ? 'rgba(0,0,0,.55)' : 'transparent'; ctx.shadowBlur = clear ? 18 : 0;
  // brand: logo app asli + wordmark modern
  const logo = await logoImage();
  ctx.save(); rrect(ctx, 80, 104, 116, 116, 30); ctx.clip();
  if (logo) ctx.drawImage(logo, 80, 104, 116, 116); else { ctx.fillStyle = A1; ctx.fillRect(80, 104, 116, 116); }
  ctx.restore();
  ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
  try { ctx.letterSpacing = '3px'; } catch {}
  ctx.fillStyle = A1; ctx.font = `italic 900 46px ${FU}`; ctx.fillText('CYCLING COACH', 222, 160);
  try { ctx.letterSpacing = '0px'; } catch {}
  const sp = sportOf(a), d = actDate(a);
  ctx.font = `600 30px ${FU}`; ctx.fillStyle = 'rgba(255,255,255,.72)'; ctx.fillText(`${sp.ico} ${sp.label} · ${fmtDate(d)} · ${(a.start_date_local || '').slice(11, 16)}`, 222, 204);
  // judul
  ctx.fillStyle = '#fff'; ctx.font = `800 84px ${FU}`;
  const lines = wrapText(ctx, a.name, W - 160).slice(0, 2); lines.forEach((l, i) => ctx.fillText(l, 80, 360 + i * 96));
  // rute
  const top = 360 + lines.length * 96 - 20, boxH = 590;
  if (a.poly) {
    const pts = decodePolyline(a.poly);
    if (pts.length > 1) {
      const lats = pts.map((q) => q[0]), lngs = pts.map((q) => q[1]);
      const mnA = Math.min(...lats), mxA = Math.max(...lats), mnO = Math.min(...lngs), mxO = Math.max(...lngs);
      const k = Math.cos(((mnA + mxA) / 2) * Math.PI / 180), sx = (mxO - mnO) * k || 1e-6, sy = mxA - mnA || 1e-6;
      const sc = Math.min((W - 240) / sx, (boxH - 120) / sy), ox = (W - sx * sc) / 2, oy = top + (boxH - sy * sc) / 2;
      const P = (q) => [ox + (q[1] - mnO) * k * sc, oy + (mxA - q[0]) * sc];
      ctx.lineJoin = 'round'; ctx.lineCap = 'round';
      ctx.save(); ctx.shadowColor = A1; ctx.shadowBlur = 30; ctx.strokeStyle = A1; ctx.lineWidth = 14;
      ctx.beginPath(); pts.forEach((q, i) => { const [x, y] = P(q); i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); }); ctx.stroke(); ctx.restore();
      ctx.strokeStyle = '#fff'; ctx.lineWidth = 4; ctx.beginPath(); pts.forEach((q, i) => { const [x, y] = P(q); i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); }); ctx.stroke();
      [[pts[0], '#22C55E'], [pts[pts.length - 1], '#EF4444']].forEach(([q, c]) => { const [x, y] = P(q); ctx.fillStyle = c; ctx.beginPath(); ctx.arc(x, y, 18, 0, 7); ctx.fill(); ctx.strokeStyle = '#fff'; ctx.lineWidth = 6; ctx.stroke(); });
    }
  } else {
    ctx.font = `260px ${FU}`; ctx.textAlign = 'center'; ctx.fillText(sp.ico, W / 2, top + boxH / 2 + 90); ctx.textAlign = 'left';
  }
  // statistik
  const b = burnOfActivity(a), km = a.distance / 1000, mv = a.moving_time || a.elapsed_time;
  const stats = [];
  if (km) stats.push(['Jarak', fmtNum(km, km >= 100 ? 0 : 1), 'km']);
  stats.push(['Waktu', fmtDurSec(mv), '']);
  if (km) stats.push(sp.pace ? ['Pace', fmtPace(mv / km), '/km'] : ['Avg speed', fmtNum(a.avg_speed * 3.6, 1), 'km/j']);
  if (km) stats.push(['Elevasi', fmtNum(a.elev), 'm']);
  stats.push(['Kalori', fmtNum(b.kcal), 'kcal']);
  stats.push(['Lemak', fmtNum(b.fatG), 'g']);
  const sy0 = top + boxH + 40, colW = (W - 160) / 2;
  stats.slice(0, 6).forEach(([l, v, u], i) => {
    const x = 80 + (i % 2) * colW, y = sy0 + Math.floor(i / 2) * 190;
    ctx.fillStyle = 'rgba(255,255,255,.65)'; ctx.font = `600 34px ${FU}`; ctx.fillText(l.toUpperCase(), x, y);
    ctx.fillStyle = '#fff'; ctx.font = `700 104px ${FN}`; ctx.fillText(v, x, y + 108);
    if (u) { const w = ctx.measureText(v).width; ctx.font = `600 38px ${FU}`; ctx.fillStyle = 'rgba(255,255,255,.72)'; ctx.fillText(u, x + w + 12, y + 108); }
  });
  // badge program + footer
  const p = adjustedFor(d), cm = completionFor(d);
  let fy = H - 120;
  if (isRide(a) && p && p.type !== 'REST' && cm && cm.acts?.[0]?.id === a.id) {
    const txt = `✓ ${p.name} · ${cm.score}% target`;
    ctx.font = `700 34px ${FU}`; const tw = ctx.measureText(txt).width + 60;
    ctx.fillStyle = 'rgba(34,197,94,.22)'; rrect(ctx, 80, fy - 150, tw, 70, 35); ctx.fill();
    ctx.fillStyle = '#4ADE80'; ctx.fillText(txt, 110, fy - 103);
  }
  ctx.fillStyle = 'rgba(255,255,255,.75)'; ctx.font = `600 32px ${FU}`;
  if (S.goal) ctx.fillText(`🎯 Menuju ${S.goal.title} · ${monthsToGoal()} bulan lagi`, 80, fy);
  ctx.fillStyle = A1; rrect(ctx, 80, fy + 28, 6, 30, 3); ctx.fill();
  try { ctx.letterSpacing = '4px'; } catch {}
  ctx.fillStyle = 'rgba(255,255,255,.55)'; ctx.font = `800 24px ${FU}`; ctx.fillText('TRAIN SMART · RIDE FAR · FINISH STRONG', 100, fy + 52);
  try { ctx.letterSpacing = '0px'; } catch {}
  return cv;
}

async function openShareSheet(a) {
  let style = 'dark';
  openSheet(`<div class="sheet-pad"><h2 class="st">Bagikan ke Story</h2><div class="small muted">Gambar 1080×1920 siap upload ke Instagram / WhatsApp Story.</div>
    <div class="seg" style="margin:12px 0"><button data-st="dark" class="on">Gelap</button><button data-st="clear">Transparan (stiker)</button></div>
    <div class="share-prev" id="shPrev"><div class="small muted">Membuat gambar…</div></div>
    <div class="btn-row"><button class="btn primary" id="shShare">Bagikan</button><button class="btn ghost" id="shSave">Simpan gambar</button></div></div>`, async (root) => {
    let blob = null;
    const draw = async () => {
      const cv = await renderShareCard(a, style);
      blob = await new Promise((r) => cv.toBlob(r, 'image/png'));
      $('#shPrev', root).innerHTML = ''; const img = new Image(); img.src = URL.createObjectURL(blob); img.className = style === 'clear' ? 'clear' : ''; $('#shPrev', root).appendChild(img);
    };
    $$('[data-st]', root).forEach((b) => (b.onclick = () => { style = b.dataset.st; $$('[data-st]', root).forEach((x) => x.classList.toggle('on', x === b)); draw(); }));
    const fname = () => `${(a.name || 'aktivitas').replace(/[^\w\- ]+/g, '').trim() || 'aktivitas'}-story.png`;
    $('#shShare', root).onclick = async () => {
      if (!blob) return;
      const file = new File([blob], fname(), { type: 'image/png' });
      try {
        if (navigator.canShare && navigator.canShare({ files: [file] })) { await navigator.share({ files: [file], title: a.name }); return; }
      } catch (e) { if (e && e.name === 'AbortError') return; }
      toast('Browser ini belum bisa share langsung — gambar disimpan, upload manual ya'); download();
    };
    const download = () => { if (!blob) return; const u = URL.createObjectURL(blob), l = document.createElement('a'); l.href = u; l.download = fname(); document.body.appendChild(l); l.click(); l.remove(); setTimeout(() => URL.revokeObjectURL(u), 3000); };
    $('#shSave', root).onclick = download;
    draw();
  });
}
